package rd;

import java.util.*;

/** İşyeri (birim) kaydı: İSG-KATİP sözleşme listesinden gelen bilgiler ve birimin risk değerlendirmesi ekibi. */
public class Isyeri {
    public String ad = "", detsis = "", calisanSayisi = "", tehlikeSinifi = "Az Tehlikeli",
            adres = "", telefon = "", eposta = "", ekipYazisi = "";
    public final List<String[]> ekip = new ArrayList<String[]>();

    public String toString() { return ad; }

    public boolean ekipVar() {
        for (String[] e : ekip) if (e[1] != null && !e[1].trim().isEmpty()) return true;
        return false;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("ad", ad); m.put("detsis", detsis); m.put("calisanSayisi", calisanSayisi); m.put("tehlikeSinifi", tehlikeSinifi);
        m.put("adres", adres); m.put("telefon", telefon); m.put("eposta", eposta); m.put("ekipYazisi", ekipYazisi);
        List<Object> l = new ArrayList<Object>();
        for (String[] e : ekip) {
            Map<String, Object> x = new LinkedHashMap<String, Object>();
            x.put("unvan", e[0]); x.put("ad", e[1]);
            l.add(x);
        }
        m.put("ekip", l);
        return m;
    }

    public static Isyeri fromMap(Map<?, ?> m) {
        Isyeri i = new Isyeri();
        i.ad = Kayit.str(m, "ad"); i.detsis = Kayit.str(m, "detsis"); i.calisanSayisi = Kayit.str(m, "calisanSayisi");
        String t = Kayit.str(m, "tehlikeSinifi"); if (!t.isEmpty()) i.tehlikeSinifi = t;
        i.adres = Kayit.str(m, "adres"); i.telefon = Kayit.str(m, "telefon"); i.eposta = Kayit.str(m, "eposta");
        i.ekipYazisi = Kayit.str(m, "ekipYazisi");
        if (m.get("ekip") instanceof List) {
            for (Object x : (List<?>) m.get("ekip"))
                if (x instanceof Map) i.ekip.add(new String[]{Kayit.str((Map<?, ?>) x, "unvan"), Kayit.str((Map<?, ?>) x, "ad")});
        }
        return i;
    }

    /** İşyeri bilgilerini rapora uygular. Boş alanlar rapordaki mevcut değeri ezmez; ekip yalnızca işyerinde kayıtlıysa değiştirilir. */
    public void rapora(Rapor r) {
        r.bilgi.put("birim", ad);
        if (!detsis.isEmpty()) r.bilgi.put("detsis", detsis);
        if (!calisanSayisi.isEmpty()) r.bilgi.put("calisanSayisi", calisanSayisi);
        if (!tehlikeSinifi.isEmpty()) r.bilgi.put("tehlikeSinifi", tehlikeSinifi);
        if (!adres.isEmpty()) r.bilgi.put("adres", adres);
        if (!telefon.isEmpty()) r.bilgi.put("telefon", telefon);
        if (!eposta.isEmpty()) r.bilgi.put("eposta", eposta);
        r.bilgi.put("ekipYazisi", ekipYazisi);
        String g = Rapor.gecerlilikHesapla(r.b("tarih"), r.b("tehlikeSinifi"));
        if (!g.isEmpty()) r.bilgi.put("gecerlilik", g);
        if (ekipVar()) {
            r.ekip.clear();
            for (String[] e : ekip) r.ekip.add(new String[]{e[0], e[1]});
        }
        r.sabitleriUygula();
    }

    /** Rapordaki birim bilgilerini ve ekibi işyeri kaydına aktarır. */
    public void raporDan(Rapor r) {
        ad = r.b("birim").trim();
        detsis = r.b("detsis"); calisanSayisi = r.b("calisanSayisi"); tehlikeSinifi = r.b("tehlikeSinifi");
        adres = r.b("adres"); telefon = r.b("telefon"); eposta = r.b("eposta"); ekipYazisi = r.b("ekipYazisi");
        ekip.clear();
        for (String[] e : r.ekip) ekip.add(new String[]{e[0], e[1]});
    }

    public static Isyeri bul(List<Isyeri> l, String ad) {
        if (ad == null) return null;
        String n = Kayit.norm(ad);
        for (Isyeri i : l) if (Kayit.norm(i.ad).equals(n)) return i;
        return null;
    }
}
