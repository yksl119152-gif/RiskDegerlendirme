package rd;

import java.text.SimpleDateFormat;
import java.util.*;

/** Bir birimin risk değerlendirme raporu. */
public class Rapor {
    public final Map<String, String> bilgi = new LinkedHashMap<String, String>();
    public final List<String[]> ekip = new ArrayList<String[]>();
    public final List<Kayit> kalemler = new ArrayList<Kayit>();

    public static final String[][] ALANLAR = {
        {"kurum", "Kurum"},
        {"birim", "Birim (işyeri) adı"},
        {"detsis", "SGK / DETSİS no"},
        {"adres", "Faaliyet adresi"},
        {"telefon", "Telefon"},
        {"eposta", "E-posta"},
        {"faaliyet", "Faaliyet alanı"},
        {"tehlikeSinifi", "Tehlike sınıfı"},
        {"calisanSayisi", "Çalışan sayısı"},
        {"alan", "Toplam kullanım alanı (m²)"},
        {"yontem", "Risk değerlendirme yöntemi"},
        {"tarih", "Rapor (yayınlanma) tarihi"},
        {"gecerlilik", "Geçerlilik tarihi"},
        {"uzmanAd", "İş güvenliği uzmanı"},
        {"uzmanSinif", "Uzmanlık belge sınıfı"},
        {"uzmanBelgeNo", "Belge no"},
        {"uzmanBelgeTarih", "Belge tarihi"},
        {"hekimAd", "İşyeri hekimi"},
        {"ekipYazisi", "Ekip görevlendirme yazısı"},
        {"dokumanNo", "Doküman no"},
        {"revizyon", "Revizyon no / tarihi"},
    };

    // Kurumun İSG profesyonelleri: her raporda ve her ekipte sabit olarak bulunur
    public static final String UZMAN_AD = "Serkan YÜKSEL", UZMAN_SINIF = "B", UZMAN_BELGE_NO = "İGU-413794", UZMAN_BELGE_TARIH = "13.06.2025",
            HEKIM_AD = "Prof. Dr. Tijen ACAR";
    public static final String UZMAN_GOREV = "İş Güvenliği Uzmanı", HEKIM_GOREV = "İşyeri Hekimi";

    /**
     * İş güvenliği uzmanı ve işyeri hekimi bilgilerini doldurur ve ekipte bulunmalarını sağlar.
     * Elle girilmiş bir ad varsa korunur; yalnızca boş alanlar doldurulur, eksik satırlar eklenir.
     */
    public void sabitleriUygula() {
        if (b("uzmanAd").trim().isEmpty()) bilgi.put("uzmanAd", UZMAN_AD);
        if (b("uzmanSinif").trim().isEmpty()) bilgi.put("uzmanSinif", UZMAN_SINIF);
        if (b("uzmanBelgeNo").trim().isEmpty()) bilgi.put("uzmanBelgeNo", UZMAN_BELGE_NO);
        if (b("uzmanBelgeTarih").trim().isEmpty()) bilgi.put("uzmanBelgeTarih", UZMAN_BELGE_TARIH);
        if (b("hekimAd").trim().isEmpty()) bilgi.put("hekimAd", HEKIM_AD);
        int u = sabitSatir("güvenliği uzmanı", UZMAN_GOREV, b("uzmanAd"), -1);
        sabitSatir("hekim", HEKIM_GOREV, b("hekimAd"), u);
    }

    /** Görev adında 'anahtar' geçen satırı bulur (adı boşsa doldurur) ya da 'sonra' satırının arkasına ekler. Satır indeksini döndürür. */
    int sabitSatir(String anahtar, String gorev, String ad, int sonra) {
        Locale tr = new Locale("tr");
        for (int i = 0; i < ekip.size(); i++) {
            if (ekip.get(i)[0].toLowerCase(tr).contains(anahtar)) {
                if (ekip.get(i)[1].trim().isEmpty()) ekip.get(i)[1] = ad;
                return i;
            }
        }
        int yer = sonra >= 0 ? sonra + 1 : Math.min(1, ekip.size());
        ekip.add(yer, new String[]{gorev, ad});
        return yer;
    }

    public static Rapor yeni() {
        Rapor r = new Rapor();
        r.bilgi.put("kurum", "DÜZCE ÜNİVERSİTESİ");
        r.bilgi.put("birim", "");
        r.bilgi.put("detsis", "");
        r.bilgi.put("adres", "Düzce Üniversitesi Konuralp Yerleşkesi, Merkez / DÜZCE");
        r.bilgi.put("telefon", "");
        r.bilgi.put("eposta", "");
        r.bilgi.put("faaliyet", "Eğitim / Hizmet");
        r.bilgi.put("tehlikeSinifi", "Az Tehlikeli");
        r.bilgi.put("calisanSayisi", "");
        r.bilgi.put("alan", "");
        r.bilgi.put("yontem", Yontem.FK);
        r.bilgi.put("tarih", Depo.bugun());
        r.bilgi.put("gecerlilik", gecerlilikHesapla(Depo.bugun(), "Az Tehlikeli"));
        r.bilgi.put("uzmanAd", UZMAN_AD);
        r.bilgi.put("uzmanSinif", UZMAN_SINIF);
        r.bilgi.put("uzmanBelgeNo", UZMAN_BELGE_NO);
        r.bilgi.put("uzmanBelgeTarih", UZMAN_BELGE_TARIH);
        r.bilgi.put("hekimAd", HEKIM_AD);
        r.bilgi.put("ekipYazisi", "");
        r.bilgi.put("dokumanNo", "");
        r.bilgi.put("revizyon", "00");
        r.ekip.add(new String[]{"İşveren Vekili (Birim Amiri)", ""});
        r.ekip.add(new String[]{"İşyeri Koordinatörü (Birim Sekreteri)", ""});
        r.ekip.add(new String[]{UZMAN_GOREV, UZMAN_AD});
        r.ekip.add(new String[]{HEKIM_GOREV, HEKIM_AD});
        r.ekip.add(new String[]{"Çalışan Temsilcisi", ""});
        r.ekip.add(new String[]{"Destek Elemanı", ""});
        return r;
    }

    public static int yil(String sinif) {
        if (sinif == null) return 6;
        if (sinif.startsWith("Çok")) return 2;
        if (sinif.startsWith("Tehlikeli")) return 4;
        return 6;
    }

    public static String gecerlilikHesapla(String tarih, String sinif) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("dd.MM.yyyy");
            f.setLenient(false);
            Calendar c = Calendar.getInstance();
            c.setTime(f.parse(tarih));
            c.add(Calendar.YEAR, yil(sinif));
            return f.format(c.getTime());
        } catch (Exception e) {
            return "";
        }
    }

    public String yontem() { return Yontem.ad(b("yontem")); }

    public String b(String k) {
        String v = bilgi.get(k);
        return v == null ? "" : v;
    }

    public String ekipKisi(String unvanParcasi) {
        for (String[] e : ekip) if (e[0].toLowerCase(new Locale("tr")).contains(unvanParcasi)) return e[1];
        return "";
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("tur", "DUZCE_RISK_DEGERLENDIRME_RAPORU");
        m.put("surum", 1);
        m.put("bilgi", new LinkedHashMap<String, Object>(bilgi));
        List<Object> e = new ArrayList<Object>();
        for (String[] x : ekip) {
            Map<String, Object> mm = new LinkedHashMap<String, Object>();
            mm.put("unvan", x[0]); mm.put("ad", x[1]);
            e.add(mm);
        }
        m.put("ekip", e);
        List<Object> k = new ArrayList<Object>();
        for (Kayit x : kalemler) k.add(x.toMap());
        m.put("kalemler", k);
        return m;
    }

    /** Taşınabilir rapor dosyası (.rdr): DÖF fotoğrafları dosyanın içine gömülür. */
    public Map<String, Object> toMapFotolu() {
        Map<String, Object> m = toMap();
        Map<String, Object> v = new LinkedHashMap<String, Object>();
        for (Kayit x : kalemler) {
            for (List<String> l : Arrays.asList(x.fotoOnce, x.fotoSonra)) {
                for (String ad : l) {
                    if (v.containsKey(ad)) continue;
                    try {
                        java.io.File f = Depo.foto(ad);
                        if (f.exists()) v.put(ad, B64.kodla(Depo.baytOku(f)));
                    } catch (Exception ignored) {}
                }
            }
        }
        if (!v.isEmpty()) m.put("fotoVeri", v);
        return m;
    }

    public static Rapor fromJson(String json) {
        Object o = Json.parse(json);
        if (!(o instanceof Map)) throw new RuntimeException("Geçerli bir rapor dosyası değil.");
        Map<?, ?> m = (Map<?, ?>) o;
        Rapor r = yeni();
        r.ekip.clear();
        if (m.get("bilgi") instanceof Map) {
            for (Map.Entry<?, ?> en : ((Map<?, ?>) m.get("bilgi")).entrySet())
                r.bilgi.put(String.valueOf(en.getKey()), en.getValue() == null ? "" : en.getValue().toString());
        }
        if (m.get("ekip") instanceof List) {
            for (Object x : (List<?>) m.get("ekip")) {
                if (x instanceof Map) r.ekip.add(new String[]{Kayit.str((Map<?, ?>) x, "unvan"), Kayit.str((Map<?, ?>) x, "ad")});
            }
        }
        if (m.get("kalemler") instanceof List) {
            for (Object x : (List<?>) m.get("kalemler")) if (x instanceof Map) r.kalemler.add(Kayit.fromMap((Map<?, ?>) x));
        }
        // Gömülü fotoğrafları (varsa) fotoğraf klasörüne çıkar
        if (m.get("fotoVeri") instanceof Map) {
            for (Map.Entry<?, ?> en : ((Map<?, ?>) m.get("fotoVeri")).entrySet()) {
                try {
                    String ad = String.valueOf(en.getKey()).replaceAll("[\\\\/:]", "_");
                    java.io.File f = Depo.foto(ad);
                    if (!f.exists()) Depo.baytYaz(f, B64.coz(String.valueOf(en.getValue())));
                } catch (Exception ignored) {}
            }
        }
        r.sabitleriUygula();
        return r;
    }

    /** DÖF numarası önerisi: DÖF-yıl-sıra */
    public String dofNoOner(Kayit k) {
        String t = b("tarih");
        String yil = t.length() >= 4 ? t.substring(t.length() - 4) : "";
        return "DÖF-" + yil + "-" + String.format("%03d", kalemler.indexOf(k) + 1);
    }
}
