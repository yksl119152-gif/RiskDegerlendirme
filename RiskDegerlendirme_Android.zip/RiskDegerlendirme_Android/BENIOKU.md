# Düzce Üniversitesi – İSG Risk Değerlendirme (Android)

Masaüstü programın (Duzce_Risk_Degerlendirme.jar) Android sürümü. Aynı risk arşivi (108 risk), aynı Fine-Kinney hesabı, aynı rapor şablonu.
Arşiv (JSON) ve rapor (.rdr) dosyaları iki sürüm arasında taşınabilir.

## APK'yı GitHub'da bulutta derleme

1. github.com'a girin → sağ üstte **+** → **New repository**.
   Ad: `RiskDegerlendirme` → **Public** veya **Private** → **Create repository**.
2. Açılan sayfada **uploading an existing file** bağlantısına dokunun.
3. Bu zip'i açın ve içindeki **app** klasörü ile şu dosyaları sürükleyip bırakın:
   `settings.gradle`, `build.gradle`, `gradle.properties`, `.gitignore`, `BENIOKU.md` → **Commit changes**.
   (Tablette klasör yüklenemiyorsa bilgisayardan yükleyin; klasör yapısı korunmalıdır: `app/src/main/...`)
4. Derleme dosyası gizli klasörde olduğu için ayrıca ekleyin:
   **Add file → Create new file** → dosya adı kutusuna tam olarak `.github/workflows/apk.yml` yazın →
   bu zip'teki `.github/workflows/apk.yml` dosyasının içeriğini yapıştırın → **Commit changes**.
5. Üstteki **Actions** sekmesine gidin. "APK Derle" çalışmaya başlar (yaklaşık 3–5 dakika).
   Yeşil ✓ olunca çalışmaya tıklayın → en altta **Artifacts** → **Duzce_Risk_Degerlendirme_APK** indirin.
6. İnen zip'in içindeki `Duzce_Risk_Degerlendirme.apk` dosyasını tablet/telefona açın ve kurun.
   ("Bilinmeyen kaynaklardan yüklemeye izin ver" sorulursa izin verin.)

Derleme kırmızı ✗ ile biterse: çalışmaya tıklayın → "APK oluştur" adımını açın → hata metnini Claude'a gönderin.

## Kullanım

- **Bilgiler:** Birim adı, adres, tehlike sınıfı, ekip. Geçerlilik tarihi otomatik.
- **Risk Arşivi:** Arayın, filtreleyin, kutuları işaretleyip **Rapora ekle**. Satıra dokunun: ayrıntı / düzenle / sil.
- **Rapor:** Satıra dokunun: mevcut durum, termin, sorumlu, uygulama sonrası puan. Basılı tutun: taşı / çıkar.
- **⋮ menüsü:** Önizle / Yazdır (PDF), Word'e aktar, Excel'e aktar, raporu kaydet / aç, arşive içe aktar (JSON, CSV, .rdr), arşivi dışa aktar.

PDF çıktısı iki parçadır: rapor metni (dikey A4) ve risk tablosu (yatay A4). Tek parça düzenlenebilir belge için "Word'e aktar" kullanın.
