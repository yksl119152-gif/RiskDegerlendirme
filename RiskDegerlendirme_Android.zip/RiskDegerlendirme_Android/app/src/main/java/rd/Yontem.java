package rd;

/**
 * Risk değerlendirme yöntemleri: Fine-Kinney (R = O × F × Ş) ve 5×5 L tipi matris (R = O × Ş).
 * Her risk iki yöntemin değerlerini de taşır; L matris değeri girilmemişse Fine-Kinney değerlerinden yaklaşık türetilir.
 * Android ve masaüstü tarafından ortak kullanılır (AWT bağımlılığı yoktur).
 */
public final class Yontem {
    private Yontem() {}

    public static final String FK = "Fine-Kinney", LM = "5×5 L Matris";
    public static final String[] ADLAR = {FK, LM};

    public static boolean lm(String y) { return LM.equals(y); }

    public static String ad(String y) { return lm(y) ? LM : FK; }

    // ------------------------------------------------------------ L matris ölçekleri
    public static final String[] L_OLASILIK = {
        "1 – Çok küçük: hemen hemen hiç",
        "2 – Küçük: çok az (yılda bir)",
        "3 – Orta: az (yılda birkaç kez)",
        "4 – Yüksek: sıklıkla (ayda bir)",
        "5 – Çok yüksek: çok sıklıkla (haftada bir, her gün)"};
    public static final String[] L_SIDDET = {
        "1 – Çok hafif: iş saati kaybı yok, ilkyardım gerektiren",
        "2 – Hafif: iş günü kaybı yok, kalıcı etkisi olmayan ayakta tedavi",
        "3 – Orta: hafif yaralanma, yatarak tedavi gerektiren",
        "4 – Ciddi: ciddi yaralanma, uzun süreli tedavi, meslek hastalığı",
        "5 – Çok ciddi: ölüm, sürekli iş göremezlik"};

    public static final String L_TOLERE = "TOLERE EDİLEMEZ RİSK", L_YUKSEK = "YÜKSEK RİSK", L_ORTA = "ORTA RİSK",
            L_DUSUK = "DÜŞÜK RİSK", L_ONEMSIZ = "ÖNEMSİZ RİSK";
    public static final String[] L_SEVIYELER = {L_TOLERE, L_YUKSEK, L_ORTA, L_DUSUK, L_ONEMSIZ};

    public static String[] seviyeler(String y) { return lm(y) ? L_SEVIYELER : Kinney.SEVIYELER; }

    public static String seviye(String y, double r) {
        if (!lm(y)) return Kinney.seviye(r);
        if (r >= 20) return L_TOLERE;
        if (r >= 15) return L_YUKSEK;
        if (r >= 8) return L_ORTA;
        if (r >= 2) return L_DUSUK;
        return L_ONEMSIZ;
    }

    public static String termin(String y, String sev) {
        if (!lm(y)) return Kinney.termin(sev);
        if (L_TOLERE.equals(sev)) return "Hemen";
        if (L_YUKSEK.equals(sev)) return "1 ay içinde";
        if (L_ORTA.equals(sev)) return "3 ay içinde";
        if (L_DUSUK.equals(sev)) return "1 yıl içinde";
        return "Sürekli kontrol";
    }

    public static String hex(String y, String sev) {
        if (!lm(y)) return Kinney.hex(sev);
        if (L_TOLERE.equals(sev)) return "#e53935";
        if (L_YUKSEK.equals(sev)) return "#fb8c00";
        if (L_ORTA.equals(sev)) return "#fff176";
        if (L_DUSUK.equals(sev)) return "#b3d4f5";
        return "#c8e6c9";
    }

    public static int argb(String y, String sev) {
        return 0xFF000000 | Integer.parseInt(hex(y, sev).substring(1), 16);
    }

    /** Seviye adını kısaltır: "ÇOK YÜKSEK RİSK" → "ÇOK YÜKSEK" */
    public static String kisa(String sev) { return sev.replace(" RİSK", ""); }

    // ------------------------------------------------------------ dönüşümler (yaklaşık)
    /** Fine-Kinney olasılığından L matris olasılığı */
    public static int lOlasilik(double o) {
        if (o <= 0.5) return 1;
        if (o <= 1) return 2;
        if (o <= 3) return 3;
        if (o <= 6) return 4;
        return 5;
    }

    /** Fine-Kinney şiddetinden L matris şiddeti */
    public static int lSiddet(double s) {
        if (s <= 1) return 1;
        if (s <= 3) return 2;
        if (s <= 15) return 3;
        if (s <= 40) return 4;
        return 5;
    }

    /** L matris olasılığından Fine-Kinney olasılığı */
    public static double kOlasilik(double lo) {
        int i = (int) Math.round(lo);
        return i <= 1 ? 0.5 : i == 2 ? 1 : i == 3 ? 3 : i == 4 ? 6 : 10;
    }

    /** L matris şiddetinden Fine-Kinney şiddeti */
    public static double kSiddet(double ls) {
        int i = (int) Math.round(ls);
        return i <= 1 ? 1 : i == 2 ? 3 : i == 3 ? 7 : i == 4 ? 40 : 100;
    }

    // ------------------------------------------------------------ bir kaydın değerleri
    public static double lo(Kayit k) { return k.lo != null ? k.lo : lOlasilik(k.o); }
    public static double ls(Kayit k) { return k.ls != null ? k.ls : lSiddet(k.s); }

    /** Uygulama sonrası L değerleri: girilmemişse uygulama sonrası Fine-Kinney değerlerinden türetilir; o da yoksa null. */
    public static Double lo2(Kayit k) { return k.lo2 != null ? k.lo2 : (k.o2 != null && k.s2 != null && k.f2 != null ? Double.valueOf(lOlasilik(k.o2)) : null); }
    public static Double ls2(Kayit k) { return k.ls2 != null ? k.ls2 : (k.o2 != null && k.s2 != null && k.f2 != null ? Double.valueOf(lSiddet(k.s2)) : null); }

    public static boolean lTuretilmis(Kayit k) { return k.lo == null || k.ls == null; }

    public static double puan(Kayit k, String y) { return lm(y) ? lo(k) * ls(k) : k.puan(); }

    public static Double puan2(Kayit k, String y) {
        if (!lm(y)) return k.puan2();
        Double a = lo2(k), b = ls2(k);
        return a == null || b == null ? null : a * b;
    }

    public static String seviye(Kayit k, String y) { return seviye(y, puan(k, y)); }

    public static String seviye2(Kayit k, String y) {
        Double p = puan2(k, y);
        return p == null ? null : seviye(y, p);
    }

    /** "3 – Orta" gibi bir seçenekten sayıyı okur. */
    public static Double oku(Object secim) { return Kinney.oku(secim); }
}
