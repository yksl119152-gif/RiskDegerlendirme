package rd;

/** Android (API 24) ve Java 8 üzerinde aynı şekilde çalışan küçük Base64 kodlayıcı/çözücü. */
public final class B64 {
    private B64() {}

    private static final char[] A = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
    private static final int[] R = new int[128];

    static {
        java.util.Arrays.fill(R, -1);
        for (int i = 0; i < A.length; i++) R[A[i]] = i;
    }

    public static String kodla(byte[] b) { return kodla(b, 0); }

    /** satir > 0 ise her 'satir' karakterde bir CRLF eklenir (MIME için 76). */
    public static String kodla(byte[] b, int satir) {
        StringBuilder s = new StringBuilder((b.length + 2) / 3 * 4 + 16);
        int col = 0;
        for (int i = 0; i < b.length; i += 3) {
            int n = (b[i] & 0xff) << 16 | (i + 1 < b.length ? (b[i + 1] & 0xff) << 8 : 0) | (i + 2 < b.length ? b[i + 2] & 0xff : 0);
            s.append(A[n >> 18 & 63]).append(A[n >> 12 & 63]);
            s.append(i + 1 < b.length ? A[n >> 6 & 63] : '=');
            s.append(i + 2 < b.length ? A[n & 63] : '=');
            if (satir > 0 && (col += 4) >= satir) { s.append("\r\n"); col = 0; }
        }
        return s.toString();
    }

    public static byte[] coz(String t) {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(t.length() * 3 / 4);
        int buf = 0, n = 0;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c == '=') break;
            if (c >= 128 || R[c] < 0) continue;
            buf = buf << 6 | R[c];
            n += 6;
            if (n >= 8) { n -= 8; o.write(buf >> n & 0xff); }
        }
        return o.toByteArray();
    }
}
