package rd;

import java.text.SimpleDateFormat;
import java.util.*;

/** Bir birimin risk değerlendirme raporu. */
public class Rapor {
    public final Map<String, String> bilgi = new LinkedHashMap<String, String>();
    public final List<String[]> ekip = new ArrayList<String[]>();
    public final List<Kayit> kalemler = new ArrayList<Kayit>();

    public static final String[][] ALANLAR = {
        {"kurum", "Kurum"},
        {"birim", "Birim (işyeri) adı"},
        {"detsis", "SGK / DETSİS no"},
        {"adres", "Faaliyet adresi"},
        {"telefon", "Telefon"},
        {"eposta", "E-posta"},
        {"faaliyet", "Faaliyet alanı"},
        {"tehlikeSinifi", "Tehlike sınıfı"},
        {"calisanSayisi", "Çalışan sayısı"},
        {"alan", "Toplam kullanım alanı (m²)"},
        {"yontem", "Risk değerlendirme yöntemi"},
        {"tarih", "Rapor (yayınlanma) tarihi"},
        {"gecerlilik", "Geçerlilik tarihi"},
        {"uzmanAd", "İş güvenliği uzmanı"},
        {"uzmanSinif", "Uzmanlık belge sınıfı"},
        {"uzmanBelgeNo", "Belge no"},
        {"uzmanBelgeTarih", "Belge tarihi"},
        {"hekimAd", "İşyeri hekimi"},
        {"ekipYazisi", "Ekip görevlendirme yazısı"},
        {"dokumanNo", "Doküman no"},
        {"revizyon", "Revizyon no / tarihi"},
    };

    public static Rapor yeni() {
        Rapor r = new Rapor();
        r.bilgi.put("kurum", "DÜZCE ÜNİVERSİTESİ");
        r.bilgi.put("birim", "");
        r.bilgi.put("detsis", "");
        r.bilgi.put("adres", "Düzce Üniversitesi Konuralp Yerleşkesi, Merkez / DÜZCE");
        r.bilgi.put("telefon", "");
        r.bilgi.put("eposta", "");
        r.bilgi.put("faaliyet", "Eğitim / Hizmet");
        r.bilgi.put("tehlikeSinifi", "Az Tehlikeli");
        r.bilgi.put("calisanSayisi", "");
        r.bilgi.put("alan", "");
        r.bilgi.put("yontem", Yontem.FK);
        r.bilgi.put("tarih", Depo.bugun());
        r.bilgi.put("gecerlilik", gecerlilikHesapla(Depo.bugun(), "Az Tehlikeli"));
        r.bilgi.put("uzmanAd", "Serkan YÜKSEL");
        r.bilgi.put("uzmanSinif", "B");
        r.bilgi.put("uzmanBelgeNo", "İGU-413794");
        r.bilgi.put("uzmanBelgeTarih", "13.06.2025");
        r.bilgi.put("hekimAd", "");
        r.bilgi.put("ekipYazisi", "");
        r.bilgi.put("dokumanNo", "");
        r.bilgi.put("revizyon", "00");
        r.ekip.add(new String[]{"İşveren Vekili (Birim Amiri)", ""});
        r.ekip.add(new String[]{"İşyeri Koordinatörü (Birim Sekreteri)", ""});
        r.ekip.add(new String[]{"İş Güvenliği Uzmanı", "Serkan YÜKSEL"});
        r.ekip.add(new String[]{"İşyeri Hekimi", ""});
        r.ekip.add(new String[]{"Çalışan Temsilcisi", ""});
        r.ekip.add(new String[]{"Destek Elemanı", ""});
        return r;
    }

    public static int yil(String sinif) {
        if (sinif == null) return 6;
        if (sinif.startsWith("Çok")) return 2;
        if (sinif.startsWith("Tehlikeli")) return 4;
        return 6;
    }

    public static String gecerlilikHesapla(String tarih, String sinif) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("dd.MM.yyyy");
            f.setLenient(false);
            Calendar c = Calendar.getInstance();
            c.setTime(f.parse(tarih));
            c.add(Calendar.YEAR, yil(sinif));
            return f.format(c.getTime());
        } catch (Exception e) {
            return "";
        }
    }

    public String yontem() { return Yontem.ad(b("yontem")); }

    public String b(String k) {
        String v = bilgi.get(k);
        return v == null ? "" : v;
    }

    public String ekipKisi(String unvanParcasi) {
        for (String[] e : ekip) if (e[0].toLowerCase(new Locale("tr")).contains(unvanParcasi)) return e[1];
        return "";
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("tur", "DUZCE_RISK_DEGERLENDIRME_RAPORU");
        m.put("surum", 1);
        m.put("bilgi", new LinkedHashMap<String, Object>(bilgi));
        List<Object> e = new ArrayList<Object>();
        for (String[] x : ekip) {
            Map<String, Object> mm = new LinkedHashMap<String, Object>();
            mm.put("unvan", x[0]); mm.put("ad", x[1]);
            e.add(mm);
        }
        m.put("ekip", e);
        List<Object> k = new ArrayList<Object>();
        for (Kayit x : kalemler) k.add(x.toMap());
        m.put("kalemler", k);
        return m;
    }

    /** Taşınabilir rapor dosyası (.rdr): DÖF fotoğrafları dosyanın içine gömülür. */
    public Map<String, Object> toMapFotolu() {
        Map<String, Object> m = toMap();
        Map<String, Object> v = new LinkedHashMap<String, Object>();
        for (Kayit x : kalemler) {
            for (List<String> l : Arrays.asList(x.fotoOnce, x.fotoSonra)) {
                for (String ad : l) {
                    if (v.containsKey(ad)) continue;
                    try {
                        java.io.File f = Depo.foto(ad);
                        if (f.exists()) v.put(ad, B64.kodla(Depo.baytOku(f)));
                    } catch (Exception ignored) {}
                }
            }
        }
        if (!v.isEmpty()) m.put("fotoVeri", v);
        return m;
    }

    public static Rapor fromJson(String json) {
        Object o = Json.parse(json);
        if (!(o instanceof Map)) throw new RuntimeException("Geçerli bir rapor dosyası değil.");
        Map<?, ?> m = (Map<?, ?>) o;
        Rapor r = yeni();
        r.ekip.clear();
        if (m.get("bilgi") instanceof Map) {
            for (Map.Entry<?, ?> en : ((Map<?, ?>) m.get("bilgi")).entrySet())
                r.bilgi.put(String.valueOf(en.getKey()), en.getValue() == null ? "" : en.getValue().toString());
        }
        if (m.get("ekip") instanceof List) {
            for (Object x : (List<?>) m.get("ekip")) {
                if (x instanceof Map) r.ekip.add(new String[]{Kayit.str((Map<?, ?>) x, "unvan"), Kayit.str((Map<?, ?>) x, "ad")});
            }
        }
        if (m.get("kalemler") instanceof List) {
            for (Object x : (List<?>) m.get("kalemler")) if (x instanceof Map) r.kalemler.add(Kayit.fromMap((Map<?, ?>) x));
        }
        // Gömülü fotoğrafları (varsa) fotoğraf klasörüne çıkar
        if (m.get("fotoVeri") instanceof Map) {
            for (Map.Entry<?, ?> en : ((Map<?, ?>) m.get("fotoVeri")).entrySet()) {
                try {
                    String ad = String.valueOf(en.getKey()).replaceAll("[\\\\/:]", "_");
                    java.io.File f = Depo.foto(ad);
                    if (!f.exists()) Depo.baytYaz(f, B64.coz(String.valueOf(en.getValue())));
                } catch (Exception ignored) {}
            }
        }
        return r;
    }

    /** DÖF numarası önerisi: DÖF-yıl-sıra */
    public String dofNoOner(Kayit k) {
        String t = b("tarih");
        String yil = t.length() >= 4 ? t.substring(t.length() - 4) : "";
        return "DÖF-" + yil + "-" + String.format("%03d", kalemler.indexOf(k) + 1);
    }
}
