package rd;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/** Fine-Kinney yöntemi sabitleri ve sınıflandırma. R = Olasılık x Frekans x Şiddet */
public final class Kinney {
    private Kinney() {}

    public static final String[] OLASILIK = {
        "0.2 – Pratik olarak imkânsız, beklenmez",
        "0.5 – Çok düşük ihtimal",
        "1 – Düşük ihtimal",
        "3 – Nadir, fakat olabilir",
        "6 – Olabilir, mümkün",
        "10 – Çok kuvvetli ihtimal"};
    public static final String[] FREKANS = {
        "0.5 – Çok seyrek (yılda bir veya daha az)",
        "1 – Seyrek (yılda birkaç defa)",
        "2 – Sık değil (ayda bir veya birkaç defa)",
        "3 – Ara sıra (haftada bir veya birkaç defa)",
        "6 – Sık (günde bir veya birkaç defa)",
        "10 – Hemen hemen sürekli (saatte birkaç defa)"};
    public static final String[] SIDDET = {
        "1 – Zararsız, ucuz atlatma, çevresel zarar yok",
        "3 – Hafif yaralanma, ilkyardım, en fazla 1 gün",
        "7 – Orta şiddetli yaralanma, en fazla 2 gün iş günü kaybı",
        "15 – Ciddi zarar, dış tedavi, en fazla 20 gün iş günü kaybı",
        "40 – Çok ciddi, sakatlık, uzuv kaybı, kalıcı hasar, meslek hastalığı",
        "100 – Felaket, ölümlü kaza, çevresel felaket"};

    public static final String KABUL = "KABUL EDİLEBİLİR RİSK", OLASI = "OLASI RİSK", ONEMLI = "ÖNEMLİ RİSK",
            YUKSEK = "YÜKSEK RİSK", COK_YUKSEK = "ÇOK YÜKSEK RİSK", TOLERE = "TOLERE EDİLEMEZ RİSK";
    public static final String[] SEVIYELER = {TOLERE, COK_YUKSEK, YUKSEK, ONEMLI, OLASI, KABUL};

    public static String seviye(double r) {
        if (r <= 20) return KABUL;
        if (r <= 70) return OLASI;
        if (r <= 200) return ONEMLI;
        if (r <= 400) return YUKSEK;
        if (r <= 1800) return COK_YUKSEK;
        return TOLERE;
    }

    public static String termin(String sev) {
        if (TOLERE.equals(sev)) return "Hemen / 1 haftadan kısa";
        if (COK_YUKSEK.equals(sev)) return "1 aydan kısa";
        if (YUKSEK.equals(sev)) return "1-3 ay içinde";
        if (ONEMLI.equals(sev)) return "6 ay içinde";
        if (OLASI.equals(sev)) return "1 yıl içinde";
        return "Sürekli kontrol";
    }

    public static String hex(String sev) {
        if (TOLERE.equals(sev)) return "#e53935";
        if (COK_YUKSEK.equals(sev)) return "#fb8c00";
        if (YUKSEK.equals(sev)) return "#ffd54f";
        if (ONEMLI.equals(sev)) return "#fff176";
        if (OLASI.equals(sev)) return "#b3d4f5";
        return "#c8e6c9";
    }

    /** Android ARGB renk değeri */
    public static int renk(String sev) {
        return 0xFF000000 | Integer.parseInt(hex(sev).substring(1), 16);
    }

    public static String kisa(String sev) {
        return sev.replace(" RİSK", "");
    }

    private static final DecimalFormat DF = new DecimalFormat("0.##", new DecimalFormatSymbols(new Locale("tr")));

    public static String fmt(Double d) {
        return d == null ? "" : DF.format(d);
    }

    /** "40 – Çok ciddi..." gibi bir seçenekten sayıyı çıkarır. */
    public static Double oku(Object secim) {
        if (secim == null) return null;
        String t = secim.toString().trim();
        if (t.isEmpty() || t.startsWith("—")) return null;
        int sp = t.indexOf(' ');
        if (sp > 0) t = t.substring(0, sp);
        try { return Double.valueOf(t.replace(',', '.')); } catch (Exception e) { return null; }
    }

    /** Değere karşılık gelen seçenek metni (listede yoksa sayının kendisi). */
    public static String secenek(String[] liste, Double v) {
        if (v == null) return "—";
        for (String x : liste) {
            Double d = oku(x);
            if (d != null && Math.abs(d - v) < 1e-9) return x;
        }
        return fmt(v);
    }
}
