package rd;

import java.util.*;

/** Harici kütüphane gerektirmeyen küçük JSON okuyucu/yazıcı. */
public final class Json {
    private final String s;
    private int i;

    private Json(String s) { this.s = s; }

    public static Object parse(String text) {
        Json p = new Json(text);
        p.ws();
        Object v = p.value();
        p.ws();
        return v;
    }

    private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }

    private Object value() {
        ws();
        if (i >= s.length()) throw new RuntimeException("JSON beklenmedik son");
        char c = s.charAt(i);
        if (c == '{') return obj();
        if (c == '[') return arr();
        if (c == '"') return str();
        if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
        if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
        if (s.startsWith("null", i)) { i += 4; return null; }
        return num();
    }

    private Map<String, Object> obj() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        i++; ws();
        if (s.charAt(i) == '}') { i++; return m; }
        while (true) {
            ws(); String k = str(); ws();
            if (s.charAt(i) != ':') throw new RuntimeException("JSON ':' bekleniyordu, konum " + i);
            i++;
            m.put(k, value()); ws();
            char c = s.charAt(i++);
            if (c == '}') return m;
            if (c != ',') throw new RuntimeException("JSON ',' bekleniyordu, konum " + i);
        }
    }

    private List<Object> arr() {
        List<Object> l = new ArrayList<Object>();
        i++; ws();
        if (s.charAt(i) == ']') { i++; return l; }
        while (true) {
            l.add(value()); ws();
            char c = s.charAt(i++);
            if (c == ']') return l;
            if (c != ',') throw new RuntimeException("JSON ',' bekleniyordu, konum " + i);
        }
    }

    private String str() {
        StringBuilder b = new StringBuilder();
        i++;
        while (true) {
            char c = s.charAt(i++);
            if (c == '"') return b.toString();
            if (c == '\\') {
                char e = s.charAt(i++);
                switch (e) {
                    case 'n': b.append('\n'); break;
                    case 't': b.append('\t'); break;
                    case 'r': b.append('\r'); break;
                    case 'b': b.append('\b'); break;
                    case 'f': b.append('\f'); break;
                    case 'u': b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; break;
                    default: b.append(e);
                }
            } else b.append(c);
        }
    }

    private Double num() {
        int st = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        return Double.valueOf(s.substring(st, i));
    }

    // ---------------- yazıcı ----------------
    public static String write(Object o) {
        StringBuilder b = new StringBuilder();
        write(o, b, 0);
        return b.toString();
    }

    @SuppressWarnings("unchecked")
    private static void write(Object o, StringBuilder b, int ind) {
        if (o == null) b.append("null");
        else if (o instanceof String) quote((String) o, b);
        else if (o instanceof Number) {
            double d = ((Number) o).doubleValue();
            if (d == Math.rint(d) && Math.abs(d) < 1e15) b.append((long) d); else b.append(d);
        } else if (o instanceof Boolean) b.append(o.toString());
        else if (o instanceof Map) {
            Map<String, Object> m = (Map<String, Object>) o;
            b.append("{");
            boolean first = true;
            for (Map.Entry<String, Object> e : m.entrySet()) {
                if (!first) b.append(",");
                first = false;
                nl(b, ind + 1);
                quote(e.getKey(), b); b.append(": ");
                write(e.getValue(), b, ind + 1);
            }
            if (!m.isEmpty()) nl(b, ind);
            b.append("}");
        } else if (o instanceof List) {
            List<Object> l = (List<Object>) o;
            b.append("[");
            for (int k = 0; k < l.size(); k++) {
                if (k > 0) b.append(",");
                nl(b, ind + 1);
                write(l.get(k), b, ind + 1);
            }
            if (!l.isEmpty()) nl(b, ind);
            b.append("]");
        } else quote(o.toString(), b);
    }

    private static void nl(StringBuilder b, int ind) {
        b.append('\n');
        for (int k = 0; k < ind; k++) b.append(' ');
    }

    private static void quote(String v, StringBuilder b) {
        b.append('"');
        for (int k = 0; k < v.length(); k++) {
            char c = v.charAt(k);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c)); else b.append(c);
            }
        }
        b.append('"');
    }
}
