package rd;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Fotoğraflı DÖF formlarını gerçek bir Word (.docx) belgesi olarak üretir. Harici kütüphane gerektirmez (Android ve masaüstü). */
public final class DocxDof {
    private final StringBuilder b = new StringBuilder();
    private final List<String[]> medya = new ArrayList<String[]>(); // {rId, dosyaAdı}
    private int resimNo = 0;

    static final int GEN = 10466;                 // A4 kullanılabilir genişlik (twip), kenar boşlukları 1,27 cm
    static final int[] K4 = {2300, 2933, 2300, 2933};
    static final String LAC = "0B3A6F", ACIK = "EEF3F9";

    static String x(String t) {
        if (t == null) return "";
        return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    // -------------------------------------------------------------- yazı parçaları
    /** Metni (satır sonlarıyla) Word koşusuna çevirir. */
    static String r(String t, boolean kalin, int yarimPunto, String renk) {
        StringBuilder s = new StringBuilder();
        String[] satirlar = (t == null ? "" : t).split("\n", -1);
        for (int i = 0; i < satirlar.length; i++) {
            s.append("<w:r><w:rPr>");
            if (kalin) s.append("<w:b/>");
            if (renk != null) s.append("<w:color w:val=\"").append(renk).append("\"/>");
            if (yarimPunto > 0) s.append("<w:sz w:val=\"").append(yarimPunto).append("\"/><w:szCs w:val=\"").append(yarimPunto).append("\"/>");
            s.append("</w:rPr>");
            if (i > 0) s.append("<w:br/>");
            s.append("<w:t xml:space=\"preserve\">").append(x(satirlar[i])).append("</w:t></w:r>");
        }
        return s.toString();
    }

    static String p(String runs, String hiza) {
        return "<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\"/>" + (hiza != null ? "<w:jc w:val=\"" + hiza + "\"/>" : "") + "</w:pPr>" + runs + "</w:p>";
    }

    /** Hücre: genişlik (twip), birleştirme, dolgu rengi, içerik (paragraflar). */
    static String tc(int w, int span, String dolgu, String icerik) {
        StringBuilder s = new StringBuilder("<w:tc><w:tcPr><w:tcW w:w=\"").append(w).append("\" w:type=\"dxa\"/>");
        if (span > 1) s.append("<w:gridSpan w:val=\"").append(span).append("\"/>");
        if (dolgu != null) s.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(dolgu).append("\"/>");
        s.append("<w:vAlign w:val=\"center\"/></w:tcPr>").append(icerik.isEmpty() ? "<w:p/>" : icerik).append("</w:tc>");
        return s.toString();
    }

    static String tblBas(int[] kolonlar) {
        StringBuilder s = new StringBuilder("<w:tbl><w:tblPr><w:tblW w:w=\"").append(GEN).append("\" w:type=\"dxa\"/><w:tblLayout w:type=\"fixed\"/>")
                .append("<w:tblBorders>");
        for (String k : new String[]{"top", "left", "bottom", "right", "insideH", "insideV"})
            s.append("<w:").append(k).append(" w:val=\"single\" w:sz=\"6\" w:space=\"0\" w:color=\"444444\"/>");
        s.append("</w:tblBorders><w:tblCellMar><w:top w:w=\"28\" w:type=\"dxa\"/><w:left w:w=\"80\" w:type=\"dxa\"/><w:bottom w:w=\"28\" w:type=\"dxa\"/><w:right w:w=\"80\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr><w:tblGrid>");
        for (int k : kolonlar) s.append("<w:gridCol w:w=\"").append(k).append("\"/>");
        return s.append("</w:tblGrid>").toString();
    }

    static String tr(String hucreler) { return "<w:tr><w:trPr><w:cantSplit/></w:trPr>" + hucreler + "</w:tr>"; }

    static String bosluk() { return "<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"120\" w:lineRule=\"exact\"/></w:pPr></w:p>"; }

    static String bolum(String t, int span) {
        return tr(tc(GEN, span, LAC, p(r(t, true, 19, "FFFFFF"), null)));
    }

    static String etiket(String t, int w) { return tc(w, 1, ACIK, p(r(t, true, 19, null), null)); }

    static String deger(String t, int w, int span) { return tc(w, span, null, p(r(t, false, 19, null), null)); }

    static String kutu(boolean sec) { return sec ? "☒" : "☐"; }

    // -------------------------------------------------------------- fotoğraf
    String resim(String ad) {
        java.io.File f = Depo.foto(ad);
        if (!f.exists()) return p(r("(fotoğraf bulunamadı)", false, 16, "888888"), "center");
        int[] wh = DofUretici.boyut(ad); // 96 dpi piksel
        long cx = wh[0] * 9525L, cy = wh[1] * 9525L;
        resimNo++;
        String rid = "rIdImg" + resimNo;
        medya.add(new String[]{rid, ad});
        return "<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\"/><w:jc w:val=\"center\"/></w:pPr><w:r><w:drawing>"
                + "<wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"" + cx + "\" cy=\"" + cy + "\"/>"
                + "<wp:docPr id=\"" + resimNo + "\" name=\"Foto" + resimNo + "\"/>"
                + "<a:graphic xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\"><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">"
                + "<pic:pic xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:nvPicPr><pic:cNvPr id=\"" + resimNo + "\" name=\"" + x(ad) + "\"/><pic:cNvPicPr/></pic:nvPicPr>"
                + "<pic:blipFill><a:blip r:embed=\"" + rid + "\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>"
                + "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"" + cx + "\" cy=\"" + cy + "\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>"
                + "</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>";
    }

    // -------------------------------------------------------------- form
    void form(Rapor rp, Kayit k, int i, int n) {
        String y = rp.yontem();
        boolean L = Yontem.lm(y);
        String kurum = rp.b("kurum").isEmpty() ? "DÜZCE ÜNİVERSİTESİ" : rp.b("kurum");
        String sev = Yontem.seviye(k, y);
        Double p2 = Yontem.puan2(k, y);
        String no = k.dofNo.isEmpty() ? rp.dofNoOner(k) : k.dofNo;
        String puan = L ? "O " + Kinney.fmt(Yontem.lo(k)) + " × Ş " + Kinney.fmt(Yontem.ls(k)) + " = " + Kinney.fmt(Yontem.puan(k, y))
                        : "Ş " + Kinney.fmt(k.s) + " × O " + Kinney.fmt(k.o) + " × F " + Kinney.fmt(k.f) + " = " + Kinney.fmt(k.puan());
        String puan2 = p2 == null ? "" : (L ? "O " + Kinney.fmt(Yontem.lo2(k)) + " × Ş " + Kinney.fmt(Yontem.ls2(k)) + " = " + Kinney.fmt(p2)
                                            : "Ş " + Kinney.fmt(k.s2) + " × O " + Kinney.fmt(k.o2) + " × F " + Kinney.fmt(k.f2) + " = " + Kinney.fmt(p2))
                + "  (" + Yontem.seviye(y, p2) + ")";
        String tespitEden = rp.b("uzmanAd").isEmpty() ? rp.ekipKisi("güvenliği uzmanı") : rp.b("uzmanAd");
        String amir = rp.ekipKisi("işveren");
        String termin = k.termin.isEmpty() ? Yontem.termin(y, sev) : k.termin;

        if (i > 1) b.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>");
        // Başlık
        int[] u = {2700, 5066, 2700};
        b.append(tblBas(u)).append(tr(
                tc(u[0], 1, null, p(r("T.C.\n" + kurum, true, 20, LAC), "center") + p(r("İş Sağlığı ve Güvenliği Koordinatörlüğü", false, 16, LAC), "center"))
              + tc(u[1], 1, null, p(r("DÜZELTİCİ – ÖNLEYİCİ FAALİYET\n(DÖF) FORMU", true, 28, LAC), "center"))
              + tc(u[2], 1, null, p(r("DÖF No: ", true, 16, null) + r(no, false, 16, null), null) + p(r("Form tarihi: ", true, 16, null) + r(rp.b("tarih"), false, 16, null), null)
                    + p(r("Form: ", true, 16, null) + r(i + " / " + n, false, 16, null), null)))).append("</w:tbl>").append(bosluk());

        // 1. Genel bilgiler
        StringBuilder turS = new StringBuilder(), kayS = new StringBuilder();
        for (String t : DofUretici.TURLER) turS.append(kutu(t.equals(k.dofTuru))).append(" ").append(t).append("     ");
        for (String t : DofUretici.KAYNAKLAR) kayS.append(kutu(t.equals(k.dofKaynak))).append(" ").append(t).append("   ");
        b.append(tblBas(K4)).append(bolum("1. GENEL BİLGİLER", 4))
         .append(tr(etiket("Birim", K4[0]) + deger(rp.b("birim"), K4[1] + K4[2] + K4[3], 3)))
         .append(tr(etiket("Tespit tarihi", K4[0]) + deger(k.tespitTarihi.isEmpty() ? rp.b("tarih") : k.tespitTarihi, K4[1], 1)
                  + etiket("Tespit eden", K4[2]) + deger(tespitEden, K4[3], 1)))
         .append(tr(etiket("Faaliyet türü", K4[0]) + deger(turS.toString().trim(), K4[1] + K4[2] + K4[3], 3)))
         .append(tr(etiket("DÖF kaynağı", K4[0]) + deger(kayS.toString().trim(), K4[1] + K4[2] + K4[3], 3)))
         .append("</w:tbl>").append(bosluk());

        // 2. Uygunsuzluk
        int g3 = K4[1] + K4[2] + K4[3];
        b.append(tblBas(K4)).append(bolum("2. UYGUNSUZLUĞUN / TEHLİKENİN TANIMI", 4))
         .append(tr(etiket("Faaliyet / bölüm", K4[0]) + deger(k.faaliyet, g3, 3)))
         .append(tr(etiket("Tehlike", K4[0]) + deger(k.tehlike, g3, 3)))
         .append(tr(etiket("Risk / olası etkiler", K4[0]) + deger(k.risk, g3, 3)))
         .append(tr(etiket("Mevcut durum", K4[0]) + deger(k.mevcutDurum, g3, 3)))
         .append(tr(etiket("Risk puanı (" + y + ")", K4[0]) + deger(puan, K4[1], 1) + etiket("Risk seviyesi", K4[2])
                  + tc(K4[3], 1, Yontem.hex(y, sev).substring(1).toUpperCase(), p(r(sev, true, 18, null), "center"))))
         .append("</w:tbl>").append(bosluk());

        // 3. Kök neden ve planlanan faaliyet
        b.append(tblBas(K4)).append(bolum("3. KÖK NEDEN VE PLANLANAN FAALİYET", 4))
         .append(tr(etiket("Kök neden", K4[0]) + deger(k.kokNeden.isEmpty() ? "\n" : k.kokNeden, g3, 3)))
         .append(tr(etiket("Düzeltici – önleyici faaliyet", K4[0]) + deger(k.onlem, g3, 3)))
         .append(tr(etiket("Sorumlu", K4[0]) + deger(k.sorumlu, K4[1], 1) + etiket("Termin", K4[2]) + deger(termin, K4[3], 1)))
         .append(tr(etiket("İlgili mevzuat", K4[0]) + deger(k.mevzuat, g3, 3)))
         .append("</w:tbl>").append(bosluk());

        // 4. Uygulama ve etkinlik
        String etk = kutu(DofUretici.DURUMLAR[1].equals(k.dofDurum)) + " Etkin – DÖF kapatıldı     "
                + kutu(DofUretici.DURUMLAR[2].equals(k.dofDurum)) + " Etkin değil – yeni DÖF açıldı (No: "
                + (k.dofYeniNo.isEmpty() ? "................" : k.dofYeniNo) + ")\nKontrol tarihi: "
                + (k.dofKontrolTarihi.isEmpty() ? "....../....../.........." : k.dofKontrolTarihi);
        b.append(tblBas(K4)).append(bolum("4. UYGULAMA VE ETKİNLİK KONTROLÜ", 4))
         .append(tr(etiket("Yapılan faaliyet", K4[0]) + deger(k.dofYapilan.isEmpty() ? "\n" : k.dofYapilan, g3, 3)))
         .append(tr(etiket("Tamamlanma tarihi", K4[0]) + deger(k.dofTamamlanma, K4[1], 1) + etiket("Kalıntı risk", K4[2]) + deger(puan2, K4[3], 1)))
         .append(tr(etiket("Etkinlik sonucu", K4[0]) + deger(etk, g3, 3)))
         .append("</w:tbl>").append(bosluk());

        // 5. İmzalar
        int[] im = {3489, 3488, 3489};
        b.append(tblBas(im)).append(tr(
                tc(im[0], 1, ACIK, p(r("Tespit Eden\n(İş Güvenliği Uzmanı)", true, 17, null), "center"))
              + tc(im[1], 1, ACIK, p(r("Faaliyetten Sorumlu", true, 17, null), "center"))
              + tc(im[2], 1, ACIK, p(r("Onaylayan\n(İşveren Vekili)", true, 17, null), "center"))))
         .append(tr(tc(im[0], 1, null, p(r(tespitEden + "\n\n", false, 19, null) + r("İmza", false, 17, "888888"), "center"))
                  + tc(im[1], 1, null, p(r(k.sorumlu + "\n\n", false, 19, null) + r("İmza", false, 17, "888888"), "center"))
                  + tc(im[2], 1, null, p(r(amir + "\n\n", false, 19, null) + r("İmza", false, 17, "888888"), "center"))))
         .append("</w:tbl>").append(bosluk());

        // Ek: fotoğraflar
        List<String> a = DofUretici.mevcut(k.fotoOnce), s = DofUretici.mevcut(k.fotoSonra);
        int[] f2 = {5233, 5233};
        b.append(tblBas(f2))
         .append("<w:tr><w:trPr><w:tblHeader/></w:trPr>").append(tc(GEN, 2, LAC, p(r("EK – FOTOĞRAFLAR", true, 19, "FFFFFF"), null))).append("</w:tr>")
         .append("<w:tr><w:trPr><w:tblHeader/></w:trPr>").append(tc(f2[0], 1, "FBE4E4", p(r("Tespit (önce)", true, 19, null), "center")))
         .append(tc(f2[1], 1, "E3F3E6", p(r("Uygulama sonrası (sonra)", true, 19, null), "center"))).append("</w:tr>");
        int m = Math.max(1, Math.max(a.size(), s.size()));
        for (int j = 0; j < m; j++) {
            String sol = j < a.size() ? resim(a.get(j)) + p(r("Fotoğraf " + (j + 1), false, 15, "555555"), "center")
                    : (j == 0 ? p(r("\nTespit fotoğrafı eklenmedi\n", false, 17, "888888"), "center") : "");
            String sag = j < s.size() ? resim(s.get(j)) + p(r("Fotoğraf " + (j + 1), false, 15, "555555"), "center")
                    : (j == 0 ? p(r("\nUygulama sonrası fotoğraf eklenmedi\n", false, 17, "888888"), "center") : "");
            b.append(tr(tc(f2[0], 1, null, sol) + tc(f2[1], 1, null, sag)));
        }
        b.append("</w:tbl>");
    }

    // -------------------------------------------------------------- paket
    public static byte[] uret(Rapor rp, List<Kayit> liste) throws IOException {
        DocxDof d = new DocxDof();
        int i = 0;
        for (Kayit k : liste) d.form(rp, k, ++i, liste.size());
        String doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" "
                + "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" "
                + "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" "
                + "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>"
                + d.b + "<w:p/><w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>"
                + "<w:pgMar w:top=\"680\" w:right=\"720\" w:bottom=\"680\" w:left=\"720\" w:header=\"340\" w:footer=\"340\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>";
        StringBuilder rels = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rIdStil\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
        for (String[] m : d.medya)
            rels.append("<Relationship Id=\"").append(m[0]).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/")
                .append(x(m[0])).append(".jpg\"/>");
        rels.append("</Relationships>");
        String stil = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<w:styles xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:docDefaults><w:rPrDefault><w:rPr>"
                + "<w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\" w:eastAsia=\"Calibri\" w:cs=\"Calibri\"/><w:sz w:val=\"19\"/><w:szCs w:val=\"19\"/><w:lang w:val=\"tr-TR\"/>"
                + "</w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>"
                + "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/></w:style></w:styles>";
        String tipler = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>"
                + "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
                + "<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>"
                + "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/></Types>";
        String kokRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"
                + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/></Relationships>";
        String core = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\">"
                + "<dc:title>DÖF Formu – " + x(rp.b("birim")) + "</dc:title><dc:creator>Düzce Üniversitesi İSG Risk Değerlendirme Programı</dc:creator></cp:coreProperties>";

        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ZipOutputStream z = new ZipOutputStream(bo);
        ekle(z, "[Content_Types].xml", tipler.getBytes("UTF-8"));
        ekle(z, "_rels/.rels", kokRels.getBytes("UTF-8"));
        ekle(z, "docProps/core.xml", core.getBytes("UTF-8"));
        ekle(z, "word/document.xml", doc.getBytes("UTF-8"));
        ekle(z, "word/styles.xml", stil.getBytes("UTF-8"));
        ekle(z, "word/_rels/document.xml.rels", rels.toString().getBytes("UTF-8"));
        for (String[] m : d.medya) ekle(z, "word/media/" + m[0] + ".jpg", Depo.baytOku(Depo.foto(m[1])));
        z.close();
        return bo.toByteArray();
    }

    static void ekle(ZipOutputStream z, String ad, byte[] veri) throws IOException {
        z.putNextEntry(new ZipEntry(ad));
        z.write(veri);
        z.closeEntry();
    }
}
