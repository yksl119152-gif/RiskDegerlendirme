package rd;

import java.util.*;

/** Raporu yazdırılabilir HTML (tarayıcı / PDF), Word (.doc) ve Excel (.xls) olarak üretir. */
public final class RaporUretici {
    private RaporUretici() {}

    static String e(String t) {
        if (t == null) return "";
        return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
                .replace("\n", "<br>");
    }

    static String bosIse(String t, String vars) {
        return (t == null || t.trim().isEmpty()) ? vars : t;
    }

    public static String html(Rapor r, boolean word) { return html(r, word, 0); }

    /** kapsam: 0 = tüm rapor, 1 = yalnızca dikey bölümler (kapak–4. bölüm), 2 = yalnızca yatay risk tablosu */
    public static String html(Rapor r, boolean word, int kapsam) {
        String t = htmlTam(r, word);
        if (kapsam == 0) return t;
        int a = t.indexOf("<div class='WordSection1'>"), b = t.indexOf("<div class='WordSection2'>");
        String bas = t.substring(0, a);
        if (kapsam == 1) {
            String govde = t.substring(a, b);
            int br = govde.lastIndexOf("<br clear=all");
            if (br > 0 && br > govde.lastIndexOf("</div>")) govde = govde.substring(0, br);
            return bas + govde + "</body></html>";
        }
        return bas + t.substring(b);
    }

    static String htmlTam(Rapor r, boolean word) {
        String kurum = bosIse(r.b("kurum"), "DÜZCE ÜNİVERSİTESİ");
        String birim = bosIse(r.b("birim"), "…………………… Birimi");
        String tam = kurum + " " + birim;
        String adres = bosIse(r.b("adres"), "……………………");
        String sinif = bosIse(r.b("tehlikeSinifi"), "Az Tehlikeli");
        StringBuilder h = new StringBuilder();

        h.append("<html");
        if (word) h.append(" xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'");
        h.append("><head><meta charset='utf-8'><title>Risk Değerlendirme Raporu – ").append(e(birim)).append("</title>");
        if (word) h.append("<!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom></w:WordDocument></xml><![endif]-->");
        h.append("<style>")
         .append("@page WordSection1{size:595.3pt 841.9pt;margin:56pt 50pt 56pt 50pt;}")
         .append("@page WordSection2{size:841.9pt 595.3pt;mso-page-orientation:landscape;margin:28pt 24pt 28pt 24pt;}")
         .append("div.WordSection1{page:WordSection1;} div.WordSection2{page:WordSection2;}")
         .append("body{font-family:Calibri,'Segoe UI',Arial,sans-serif;font-size:11pt;color:#1a1a1a;}")
         .append("h1{font-size:26pt;color:#0b3a6f;text-align:center;margin:0;} h2{font-size:14pt;color:#0b3a6f;text-align:center;margin:18pt 0 2pt 0;}")
         .append("h3{font-size:12pt;color:#0b3a6f;border-bottom:1.5pt solid #0b3a6f;padding-bottom:2pt;margin:14pt 0 6pt 0;}")
         .append("p{margin:4pt 0;text-align:justify;line-height:1.35;} li{margin:2pt 0;text-align:justify;}")
         .append(".alt{font-size:12pt;text-align:center;color:#333;margin:0 0 10pt 0;}")
         .append("table{border-collapse:collapse;} td,th{border:0.75pt solid #555;padding:3pt 4pt;vertical-align:top;}")
         .append("table.bilgi td{font-size:10.5pt;} table.bilgi td.k{font-weight:bold;width:38%;background:#eef3f9;}")
         .append("table.kin th,table.kin td{font-size:8.5pt;} table.kin th{background:#0b3a6f;color:#fff;}")
         .append(".kapak{border:2pt solid #0b3a6f;padding:60pt 30pt 40pt 30pt;text-align:center;height:600pt;}")
         .append(".kapak .kurum{font-size:20pt;font-weight:bold;color:#0b3a6f;letter-spacing:1pt;} .kapak .birim{font-size:15pt;color:#0b3a6f;margin-top:6pt;}")
         .append(".kapak .tarih{font-size:13pt;font-weight:bold;color:#0b3a6f;margin-top:230pt;text-align:left;}")
         .append("table.rt{width:100%;table-layout:fixed;} table.rt td,table.rt th{font-size:6.6pt;padding:2pt;line-height:1.2;}")
         .append("table.rt th{background:#dfe8f3;text-align:center;vertical-align:middle;} table.rt td.c{text-align:center;vertical-align:middle;}")
         .append("table.rt thead{display:table-header-group;} table.rt tr{page-break-inside:avoid;}")
         .append("table.bas td{font-size:8pt;padding:2pt 4pt;} table.bas td.ust{background:#0b3a6f;color:#fff;font-weight:bold;text-align:center;font-size:11pt;}")
         .append(".sev{font-weight:bold;font-size:6pt;}")
         .append("table.imza td{text-align:center;font-size:8.5pt;height:42pt;} table.imza th{font-size:8.5pt;background:#eef3f9;}")
         .append(".sayfa{page-break-before:always;}")
         .append("@media screen{body{background:#e9edf2;} div.WordSection1,div.WordSection2{background:#fff;max-width:1100px;margin:16px auto;padding:28px;box-shadow:0 1px 6px rgba(0,0,0,.2);} .ipucu{display:block;}}")
         .append("@media print{.ipucu{display:none;}}")
         .append(".ipucu{display:none;max-width:1100px;margin:12px auto;background:#fff8d6;border:1px solid #e0c060;padding:10px 14px;font-size:10pt;}")
         .append("</style></head><body>");

        if (!word) h.append("<div class='ipucu'><b>Yazdırma / PDF:</b> Ctrl+P → Hedef: “PDF olarak kaydet” → Ayarlar: “Arka plan grafikleri” işaretli olsun. Risk tablosu sayfaları otomatik olarak yatay basılır.</div>");

        // ============ BÖLÜM: Dikey sayfalar ============
        h.append("<div class='WordSection1'>");
        // Kapak
        h.append("<div class='kapak'>")
         .append("<div class='kurum'>").append(e(kurum)).append("</div>")
         .append("<div class='birim'>").append(e(birim)).append("</div>")
         .append("<div style='height:110pt'></div><h1>RİSK DEĞERLENDİRME<br>RAPORU</h1>")
         .append("<p class='alt' style='margin-top:10pt'>").append(e(r.yontem())).append(" Yöntemi</p>")
         .append("<div class='tarih'>YAYINLANMA TARİHİ : ").append(e(r.b("tarih"))).append("<br>GEÇERLİLİK TARİHİ &nbsp;&nbsp;: ")
         .append(e(r.b("gecerlilik"))).append("</div>");
        if (!r.b("dokumanNo").isEmpty())
            h.append("<p style='text-align:left;margin-top:8pt'>Doküman No: ").append(e(r.b("dokumanNo"))).append(" &nbsp; Revizyon: ").append(e(r.b("revizyon"))).append("</p>");
        h.append("</div>");

        // İçindekiler + Önsöz + Ekip
        h.append(sayfaKir(word));
        h.append("<h3>İçindekiler</h3><table class='bilgi' style='width:100%'>")
         .append("<tr><td>Önsöz, Risk Değerlendirmesi Ekibi</td></tr>")
         .append("<tr><td>BİRİNCİ BÖLÜM – Amaç, Kapsam, Dayanak ve Tanımlar</td></tr>")
         .append("<tr><td>İKİNCİ BÖLÜM – Genel Bilgiler</td></tr>")
         .append("<tr><td>ÜÇÜNCÜ BÖLÜM – Risk Değerlendirme Aşamaları ve Yöntemi</td></tr>")
         .append("<tr><td>DÖRDÜNCÜ BÖLÜM – Sonuçların Değerlendirilmesi</td></tr>")
         .append("<tr><td>BEŞİNCİ BÖLÜM – Risk Değerlendirme Tablosu</td></tr></table>");

        h.append("<h3>Önsöz</h3>")
         .append("<p>Bu rapor, ").append(e(tam)).append(" için iş sağlığı ve güvenliği faaliyetleri kapsamında yapılan risk değerlendirmesi çalışmasını içermektedir. ")
         .append("Çalışmada mevzuat kapsamında teknik, pratik ve uygulamaya yönelik tüm aşamalar incelenmiş; saha gözetimleri sonucunda tespit edilen eksiklikler göz önüne alınarak hazırlanmıştır.</p>")
         .append("<p>Bu risk değerlendirme raporu, ").append(e(adres)).append(" adresinde faaliyet gösteren ").append(e(tam))
         .append(" için 6331 sayılı İş Sağlığı ve Güvenliği Kanunu ve İş Sağlığı ve Güvenliği Risk Değerlendirmesi Yönetmeliği kapsamında oluşturulan risk değerlendirmesi ekibi tarafından hazırlanmıştır.</p>")
         .append("<p>Kazasız ve sağlıklı bir çalışma ortamını birlikte sürdürmek dileğiyle…</p>")
         .append("<p style='text-align:right'><b>Risk Değerlendirmesi Ekibi</b></p>");

        // Birinci bölüm
        h.append(sayfaKir(word));
        h.append("<h2>BİRİNCİ BÖLÜM</h2><p class='alt'>Amaç, Kapsam, Dayanak ve Tanımlar</p>")
         .append("<h3>1. Amaç</h3><p>Bu çalışmanın amacı, ").append(e(tam))
         .append(" faaliyetleri sırasında fiziksel çevre, makine-ekipman, tesisat, insan ve organizasyon hatalarından kaynaklanan veya dışarıdan gelebilecek tehlikelerin ve bunlara ilişkin risklerin belirlenmesi; ")
         .append("risklerin kontrol altına alınmasına ilişkin yöntem ve esasların sistematik şekilde tanımlanması ve böylece iş kazaları ile meslek hastalıklarının en aza indirilmesidir.</p>")
         .append("<p>Risk değerlendirmesinin asıl amacı çalışanların sağlığını ve güvenliğini korumaktır. Bu bağlamda risk değerlendirmesi; verimliliğin artmasını, acil durumlara hazırlıklı olunmasını ve kurumun etkinliğinin korunmasını sağlar.</p>")
         .append("<h3>2. Kapsam</h3><p>Bu risk değerlendirmesi, ").append(e(tam))
         .append(" bünyesinde çalışan geçici ve/veya daimi personeli, öğrencileri, ziyaretçileri ve hizmet alımı yoluyla çalışan alt işveren personelini kapsamaktadır.</p>")
         .append("<h3>3. Dayanak</h3><p>Bu çalışma, 6331 sayılı İş Sağlığı ve Güvenliği Kanunu ve İş Sağlığı ve Güvenliği Risk Değerlendirmesi Yönetmeliği hükümlerine dayanılarak hazırlanmıştır.</p>")
         .append("<h3>4. Tanımlar</h3><ol type='a'>");
        String[][] tan = {
            {"İş güvenliği uzmanı", "İş sağlığı ve güvenliği alanında görev yapmak üzere Bakanlıkça yetkilendirilmiş, iş güvenliği uzmanlığı belgesine sahip kişidir."},
            {"İşyeri hekimi", "İş sağlığı ve güvenliği hizmetlerinde görevlendirilmek üzere Bakanlıkça belgelendirilmiş hekimdir."},
            {"Çalışan", "Kendi özel kanunlarındaki statülerine bakılmaksızın kamu veya özel işyerlerinde istihdam edilen gerçek kişidir."},
            {"Çalışan temsilcisi", "İş sağlığı ve güvenliği ile ilgili çalışmalara katılma, çalışmaları izleme, tedbir alınmasını isteme, tekliflerde bulunma ve benzeri konularda çalışanları temsil etmeye yetkili çalışandır."},
            {"Destek elemanı", "Asli görevinin yanında önleme, koruma, tahliye, yangınla mücadele, ilkyardım ve benzeri konularda özel olarak görevlendirilmiş, uygun donanım ve yeterli eğitime sahip kişidir."},
            {"Ramak kala olay", "İşyerinde meydana gelen; çalışan, işyeri ya da iş ekipmanını zarara uğratma potansiyeli olduğu halde zarara uğratmayan olaydır."},
            {"Tehlike", "İşyerinde var olan ya da dışarıdan gelebilecek, çalışanı veya işyerini etkileyebilecek zarar veya hasar verme potansiyelidir."},
            {"Risk", "Tehlikeden kaynaklanacak kayıp, yaralanma ya da başka zararlı sonuç meydana gelme ihtimalidir."},
            {"Kalıntı (bakiye) risk", "Koruyucu tedbirler alındıktan sonra geriye kalan risktir."},
            {"Risk değerlendirmesi", "İşyerinde var olan ya da dışarıdan gelebilecek tehlikelerin belirlenmesi, bu tehlikelerin riske dönüşmesine yol açan faktörler ile tehlikelerden kaynaklanan risklerin analiz edilerek derecelendirilmesi ve kontrol tedbirlerinin kararlaştırılması amacıyla yapılması gerekli çalışmalardır."},
            {"Düzeltici ve önleyici faaliyet (DÖF)", "İşlerin bütün safhalarında riskleri ortadan kaldırmak veya azaltmak için planlanan ve alınan tedbirlerin tümüdür."},
            {"İş kazası", "İşyerinde veya işin yürütümü nedeniyle meydana gelen, ölüme sebebiyet veren veya vücut bütünlüğünü ruhen ya da bedenen engelli hâle getiren olaydır."},
            {"Meslek hastalığı", "Mesleki risklere maruziyet sonucu ortaya çıkan hastalıktır."},
            {"Acil durum", "İşyerinin tamamında veya bir kısmında meydana gelebilecek yangın, patlama, tehlikeli kimyasal maddelerden kaynaklanan yayılım, doğal afet gibi acil müdahale, mücadele, ilkyardım veya tahliye gerektiren olaylardır."},
            {"Tehlike sınıfı", "Yapılan işin özelliği, kullanılan veya ortaya çıkan maddeler, iş ekipmanı, üretim yöntem ve şekilleri, çalışma ortam ve şartları dikkate alınarak işyeri için belirlenen tehlike grubudur."},
        };
        for (String[] t : tan) h.append("<li><b>").append(e(t[0])).append(":</b> ").append(e(t[1])).append("</li>");
        h.append("</ol>");

        // İkinci bölüm
        h.append(sayfaKir(word));
        h.append("<h2>İKİNCİ BÖLÜM</h2><p class='alt'>Genel Bilgiler</p>")
         .append("<h3>5. Kurum / Birim Bilgileri</h3><table class='bilgi' style='width:100%'>")
         .append(sat("Unvanı", tam)).append(sat("SGK / DETSİS no", r.b("detsis"))).append(sat("Faaliyet adresi", adres))
         .append(sat("Telefon", r.b("telefon"))).append(sat("E-posta", r.b("eposta")))
         .append(sat("Faaliyet alanı", r.b("faaliyet"))).append(sat("Tehlike sınıfı", sinif))
         .append(sat("Çalışan sayısı", r.b("calisanSayisi"))).append(sat("Toplam kullanım alanı (m²)", bosIse(r.b("alan"), "-")))
         .append(sat("Risk değerlendirmesi tarihi", r.b("tarih"))).append(sat("Geçerlilik tarihi", r.b("gecerlilik") + "  (" + Rapor.yil(sinif) + " yıl)"))
         .append("</table>")
         .append("<h3>6. İş Güvenliği Uzmanı Bilgileri</h3><table class='bilgi' style='width:100%'>")
         .append(sat("Adı soyadı", r.b("uzmanAd"))).append(sat("Belge sınıfı", r.b("uzmanSinif")))
         .append(sat("Belge tarihi", r.b("uzmanBelgeTarih"))).append(sat("Belge no", r.b("uzmanBelgeNo")))
         .append("</table>")
         .append("<h3>7. Risk Değerlendirmesi Ekibi</h3>")
         .append("<table class='bilgi' style='width:100%'><tr><td class='k'>Unvan</td><td class='k'>Adı Soyadı</td><td class='k' style='width:22%'>İmza</td></tr>");
        for (String[] x : r.ekip) h.append("<tr><td>").append(e(x[0])).append("</td><td>").append(e(x[1])).append("</td><td style='height:26pt'></td></tr>");
        h.append("</table>");
        if (!r.b("ekipYazisi").trim().isEmpty())
            h.append("<p style='font-size:10pt'>Risk değerlendirmesi ekibi, ").append(e(r.b("ekipYazisi").trim()))
             .append(" ile İş Sağlığı ve Güvenliği Risk Değerlendirmesi Yönetmeliği Madde 6 kapsamında görevlendirilmiştir.</p>");

        // Üçüncü bölüm
        final String y = r.yontem();
        final boolean L = Yontem.lm(y);
        h.append(sayfaKir(word));
        h.append("<h2>ÜÇÜNCÜ BÖLÜM</h2><p class='alt'>Risk Değerlendirme Aşamaları ve Yöntemi</p>")
         .append("<h3>8. Risk Değerlendirme Yöntemi</h3><p>Bu çalışmada risk değerlendirme yöntemi olarak kontrol listeleri ve ")
         .append(L ? "5×5 L tipi matris yöntemi kullanılmıştır: <b>Risk Değeri (R) = Olasılık × Şiddet</b></p>"
                   : "Fine-Kinney yöntemi kullanılmıştır: <b>Risk Değeri (R) = Olasılık × Frekans × Şiddet</b></p>")
         .append("<h3>9. Risk Değerlendirmesi Süreçleri</h3><ol type='a'>")
         .append("<li><b>Planlama:</b> Risk değerlendirmesi çalışmaları mevcut mevzuat ve işyeri koşulları çerçevesinde planlanır.</li>")
         .append("<li><b>Çalışmaların sınıflandırılması:</b> İşyerinde yürütülen faaliyetler; periyodik bakım-onarım işleri, işyeri içi ve dışı işler, planlı veya ani faaliyetler ve görev tanımları dikkate alınarak sınıflandırılır.</li>")
         .append("<li><b>Bilgi ve veri toplama:</b> Yürütülen işler, süre ve sıklıkları, yeri, işi yapanlar ve etkilenenler, alınan eğitimler, kullanılan makine-ekipman ve kimyasallar, mevcut korunma önlemleri ile daha önce meydana gelmiş kaza ve meslek hastalıkları dikkate alınır.</li>")
         .append("<li><b>Tehlikelerin tanımlanması:</b> Makine ve iş ekipmanları, cisim düşmesi, ergonomi, erişim ekipmanları, mutfak çalışmaları, yangın ve patlama, elle taşıma, elektrik, aydınlatma, termal konfor, toz, gürültü, bakım-onarım işleri ve işyerine özgü diğer tehlike kaynakları incelenir.</li>")
         .append("<li><b>Risk analizi:</b> Tehlikelerin verebileceği zararın şiddeti ve ortaya çıkma olasılığı")
         .append(L ? " belirlenir" : " ile maruziyet sıklığı belirlenir")
         .append("; maruz kalan kişi sayısı, maruziyet süresi, kişisel koruyucuların sağladığı koruma ve güvensiz davranışlar dikkate alınır.</li>");
        if (L)
            h.append("<li><b>Risk değerlendirmesi:</b> Risk değerleri hesaplanarak derecelendirme yapılır ve önlem gerekip gerekmediğine karar verilir. Risk değeri 1 olan riskler önemsiz risk olarak yorumlanır. ")
             .append("Ancak olasılık değeri düşük olsa bile <b>şiddet değeri 4 ve üzeri</b> olan durumlar risk puanına bakılmaksızın kontrol ve önlem faaliyetlerine dahil edilir. ")
             .append("Tolere edilemez, yüksek ve orta riskler ile yatırım ihtiyacı doğuran risklerin listesi yönetime sunulur.</li>");
        else
            h.append("<li><b>Risk değerlendirmesi:</b> Risk değerleri hesaplanarak derecelendirme yapılır ve önlem gerekip gerekmediğine karar verilir. Risk değeri 20 ve altında ise kabul edilebilir risk olarak yorumlanır. Ancak olasılık ve frekans değerleri düşük olsa bile <b>şiddet değeri 15 ve üzeri</b> olan durumlar risk puanına bakılmaksızın kontrol ve önlem faaliyetlerine dahil edilir. Tolere edilemez, çok yüksek, yüksek, önemli ve olası riskler ile yatırım ihtiyacı doğuran risklerin listesi yönetime sunulur.</li>");
        h.append("<li><b>Önlemlerin kapsamı:</b> Düzeltici ve önleyici faaliyetler şu öncelik sırasıyla belirlenir: eliminasyon (tehlikeyi ortadan kaldırmak), ikame (daha az tehlikeli olanla değiştirmek), izolasyon, toplu koruma ve örgütsel önlemler, kişisel koruyucu donanım, davranışa yönelik önlemler (eğitim, tatbikat, talimat).</li>")
         .append("<li><b>Denetim, izleme ve gözden geçirme:</b> Risk yönetiminin tüm aşamaları düzenli olarak denetlenir, izlenir ve aksayan yönler yeniden gözden geçirilir.</li>")
         .append("<li><b>Yenileme:</b> İş Sağlığı ve Güvenliği Risk Değerlendirmesi Yönetmeliği Madde 12 gereğince risk değerlendirmesi çok tehlikeli, tehlikeli ve az tehlikeli işyerlerinde sırasıyla en geç iki, dört ve altı yılda bir yenilenir. ")
         .append("Ayrıca işyerinin taşınması veya binalarda değişiklik yapılması; teknoloji, madde ve ekipmanlarda değişiklik; üretim yönteminde değişiklik; iş kazası, meslek hastalığı veya ramak kala olay meydana gelmesi; sınır değerlere ilişkin mevzuat değişikliği; ")
         .append("çalışma ortamı ölçümü ve sağlık gözetimi sonuçlarına göre gerekli görülmesi ve işyeri dışından kaynaklanan yeni bir tehlikenin ortaya çıkması hâllerinde tamamen veya kısmen yenilenir.</li></ol>");

        if (L) {
            h.append("<h3>10. Risk Analizi Yöntemi: 5×5 L Tipi Matris</h3>")
             .append("<table class='kin' style='width:100%'><tr><th>Değer</th><th>Olasılık (zararın gerçekleşme ihtimali)</th><th>Değer</th><th>Şiddet (zararın insan üzerindeki tahmini etkisi)</th></tr>");
            for (int i = 0; i < 5; i++) {
                String[] o = ayir(Yontem.L_OLASILIK[i]), s = ayir(Yontem.L_SIDDET[i]);
                h.append("<tr><td style='text-align:center'><b>").append(o[0]).append("</b></td><td>").append(e(o[1]))
                 .append("</td><td style='text-align:center'><b>").append(s[0]).append("</b></td><td>").append(e(s[1])).append("</td></tr>");
            }
            h.append("</table>");
            // Matris
            h.append("<p style='margin-top:8pt'><b>Risk Matrisi (R = O × Ş)</b></p><table class='kin' style='width:70%;margin:0 auto'><tr><th rowspan='2'>OLASILIK</th><th colspan='5'>ŞİDDET</th></tr><tr>");
            for (int s = 1; s <= 5; s++) h.append("<th>").append(s).append("</th>");
            h.append("</tr>");
            for (int o = 5; o >= 1; o--) {
                h.append("<tr><th>").append(o).append("</th>");
                for (int s = 1; s <= 5; s++)
                    h.append("<td style='text-align:center;font-weight:bold;background:").append(Yontem.hex(y, Yontem.seviye(y, o * s))).append("'>").append(o * s).append("</td>");
                h.append("</tr>");
            }
            h.append("</table>")
             .append("<p style='font-size:9pt'><b>Olasılık:</b> Tehlikenin zarara dönüşme ihtimali ve sıklığıdır; ilk değerlendirmede mevcut kontrol önlemleri dikkate alınmadan en kötü durum düşünülür. <b>Şiddet:</b> Tereddüt hâlinde yüksek puan verilir.</p>")
             .append("<table class='kin' style='width:100%;margin-top:6pt'><tr><th>Risk Değeri</th><th>Risk Sınıfı</th><th>Eylem</th><th>Termin</th></tr>")
             .append(kin(y, "1", Yontem.L_ONEMSIZ, "Ek kontrol önlemleri gerekmeyebilir; mevcut durum gözetim altında tutulur.", "Sürekli kontrol"))
             .append(kin(y, "2 – 6", Yontem.L_DUSUK, "Mevcut kontroller sürdürülür; ek kontrol önlemleri planlanabilir ve uygulamalar izlenir.", "1 yıl içinde"))
             .append(kin(y, "8 – 12", Yontem.L_ORTA, "Riski azaltmak için faaliyetler başlatılır; önlemler belirlenen süre içinde uygulanır.", "3 ay içinde"))
             .append(kin(y, "15 – 16", Yontem.L_YUKSEK, "Risk azaltılıncaya kadar iş başlatılmaz; sürmekte olan iş varsa acilen önlem alınır.", "1 ay içinde"))
             .append(kin(y, "20 – 25", Yontem.L_TOLERE, "Belirlenen risk kabul edilebilir seviyeye indirilinceye kadar iş başlatılmaz veya sürdürülen faaliyet derhal durdurulur.", "Hemen"))
             .append("</table>");
        } else {
            h.append("<h3>10. Risk Analizi Yöntemi: Fine-Kinney</h3>")
             .append("<table class='kin' style='width:100%'><tr><th>Değer</th><th>Olasılık (zararın gerçekleşme olasılığı)</th><th>Değer</th><th>Frekans (tehlikeye maruz kalma sıklığı)</th><th>Değer</th><th>Şiddet (insan ve/veya çevre üzerindeki tahmini zarar)</th></tr>");
            for (int i = 0; i < 6; i++) {
                String[] o = ayir(Kinney.OLASILIK[i]), f = ayir(Kinney.FREKANS[i]), s = ayir(Kinney.SIDDET[i]);
                h.append("<tr><td style='text-align:center'><b>").append(o[0]).append("</b></td><td>").append(e(o[1]))
                 .append("</td><td style='text-align:center'><b>").append(f[0]).append("</b></td><td>").append(e(f[1]))
                 .append("</td><td style='text-align:center'><b>").append(s[0]).append("</b></td><td>").append(e(s[1])).append("</td></tr>");
            }
            h.append("</table>")
             .append("<p style='font-size:9pt'><b>Olasılık:</b> İlk değerlendirmede mevcut kontrol önlemleri dikkate alınmadan en kötü olasılık düşünülür. <b>Frekans:</b> İşin yapılma sıklığı değil, işi yaparken tehlikeye maruz kalma sıklığıdır. <b>Şiddet:</b> Tereddüt hâlinde yüksek puan verilir; şiddet değeri tehlike tamamen ortadan kaldırılmadıkça değişmez kabul edilir.</p>")
             .append("<table class='kin' style='width:100%;margin-top:6pt'><tr><th>Risk Değeri</th><th>Risk Sınıfı</th><th>Eylem</th><th>Termin</th></tr>")
             .append(kin(y, "R ≤ 20", Kinney.KABUL, "Acil tedbir gerekmez; gözlem ve denetimlerle sürekli izlenir.", "Sürekli kontrol"))
             .append(kin(y, "20 < R ≤ 70", Kinney.OLASI, "Uzun vadede eylem planına alınmalıdır.", "1 yıl içinde"))
             .append(kin(y, "70 < R ≤ 200", Kinney.ONEMLI, "Orta vadede eylem planına alınmalıdır.", "6 ay içinde"))
             .append(kin(y, "200 < R ≤ 400", Kinney.YUKSEK, "Kısa dönemde iyileştirilmelidir.", "1-3 ay içinde"))
             .append(kin(y, "400 < R ≤ 1800", Kinney.COK_YUKSEK, "Önlem alınması için durum en kısa sürede işverene bildirilir.", "1 aydan kısa"))
             .append(kin(y, "R > 1800", Kinney.TOLERE, "Hemen önlem alınmalı; gerekirse faaliyet durdurulmalı veya bina/alan kapatılmalıdır.", "Hemen / 1 haftadan kısa"))
             .append("</table>");
        }

        // Dördüncü bölüm
        h.append(sayfaKir(word));
        h.append("<h2>DÖRDÜNCÜ BÖLÜM</h2><p class='alt'>Sonuçların Değerlendirilmesi</p>")
         .append("<p>Belirlenen öncelik derecesine ve işverenin ayırabileceği kaynaklara göre, öncelikli görülen tehlikelerin değerlendirilmesi aşağıdaki esaslara göre kararlaştırılır.</p>");
        if (L) {
            h.append(sonuc(y, "a) Tolere Edilemez Risk (R = 20 – 25)", Yontem.L_TOLERE, "Belirlenen risk kabul edilebilir seviyeye indirilinceye kadar iş başlatılmaz; faaliyet sürüyorsa <b>derhal</b> durdurulur. Gerekirse bina veya alan kapatılır. Kontrol için dokümante edilmiş prosedür ve talimatlar oluşturulur, uygulamalar periyodik olarak denetlenip yönetime raporlanır."))
             .append(sonuc(y, "b) Yüksek Risk (R = 15 – 16)", Yontem.L_YUKSEK, "Risk azaltılıncaya kadar iş başlatılmaz; sürmekte olan iş varsa acilen önlem alınır. Düzeltici ve önleyici faaliyetler <b>en geç bir ay içinde</b> uygulanır ve takip edilir."))
             .append(sonuc(y, "c) Orta Risk (R = 8 – 12)", Yontem.L_ORTA, "Riski azaltmak için faaliyetler başlatılır; prosedür ve talimatlar oluşturulur, kayıtlar tutulur. Düzeltici ve önleyici faaliyetler <b>en geç üç ay içinde</b> uygulanır ve takip edilir."))
             .append(sonuc(y, "d) Düşük Risk (R = 2 – 6)", Yontem.L_DUSUK, "Mevcut kontroller sürdürülür; ek kontrol önlemleri planlanır ve uygulama kontrolleri yapılır. Düzeltici ve önleyici faaliyetler <b>en geç bir yıl içinde</b> uygulanır."))
             .append(sonuc(y, "e) Önemsiz Risk (R = 1)", Yontem.L_ONEMSIZ, "Ek kontrol önlemi gerekmeyebilir. Gelecekte önemli bir tehlike oluşturmaması için incelenir, personele gerekli eğitimler verilir."));
        } else {
            h.append(sonuc(y, "a) Tolere Edilemez Risk (R > 1800)", Kinney.TOLERE, "İş hemen durdurulur; tehlike kontrol altına alınır, gerekirse bina veya alan kapatılır. Kontrol için dokümante edilmiş prosedür ve talimatlar oluşturulur, izleme ve ölçme planı yapılır. Düzeltici ve önleyici faaliyetler <b>hemen veya 1 haftadan kısa sürede</b> uygulanır ve takip edilir. Personele gerekli eğitimler verilir, uygulamalar periyodik olarak denetlenip yönetime raporlanır."))
             .append(sonuc(y, "b) Çok Yüksek Risk (400 < R ≤ 1800)", Kinney.COK_YUKSEK, "En kısa sürede tehlike kontrol altına alınır, prosedür ve talimatlar oluşturulur, kayıtlar tutulur. Düzeltici ve önleyici faaliyetler <b>bir aydan kısa sürede</b> uygulanır ve takip edilir. Hedef, riskin kabul edilebilir sınırlara indirilmesidir."))
             .append(sonuc(y, "c) Yüksek Risk (200 < R ≤ 400)", Kinney.YUKSEK, "Kısa sürede tehlike kontrol altına alınır, prosedür ve talimatlar oluşturulur, kayıtlar tutulur. Düzeltici ve önleyici faaliyetler <b>bir ile üç ay içinde</b> uygulanır ve takip edilir."))
             .append(sonuc(y, "d) Önemli Risk (70 < R ≤ 200)", Kinney.ONEMLI, "Tehlike kontrol altına alınır, prosedür ve talimatlar oluşturulur. Düzeltici ve önleyici faaliyetler <b>en geç altı ay içinde</b> uygulanır ve takip edilir."))
             .append(sonuc(y, "e) Olası Risk (20 < R ≤ 70)", Kinney.OLASI, "Faaliyetler gözetim altında sürdürülür, alınabilecek önlemler planlanır ve uygulama kontrolleri yapılır. Düzeltici ve önleyici faaliyetler <b>en geç bir yıl içinde</b> uygulanır ve takip edilir."))
             .append(sonuc(y, "f) Kabul Edilebilir Risk (R ≤ 20)", Kinney.KABUL, "Kabul edilebilir ve/veya önemsiz risklerdir. Gelecekte önemli bir tehlike oluşturmaması için incelenir, gerekirse önlemler planlanır ve personele gerekli eğitimler verilir."));
        }

        // Özet
        h.append("<h3>Risk Dağılımı Özeti</h3><table class='kin' style='width:100%'><tr><th>Risk Sınıfı</th><th>Uygulama Öncesi</th><th>Uygulama Sonrası</th></tr>");
        Map<String, Integer> once = new LinkedHashMap<String, Integer>(), sonra = new LinkedHashMap<String, Integer>();
        for (String s : Yontem.seviyeler(y)) { once.put(s, 0); sonra.put(s, 0); }
        int degerlenmemis = 0;
        for (Kayit k : r.kalemler) {
            String s1 = Yontem.seviye(k, y);
            once.put(s1, once.get(s1) + 1);
            String s2 = Yontem.seviye2(k, y);
            if (s2 == null) degerlenmemis++; else sonra.put(s2, sonra.get(s2) + 1);
        }
        for (String s : Yontem.seviyeler(y))
            h.append("<tr><td style='background:").append(Yontem.hex(y, s)).append("'><b>").append(s).append("</b></td><td style='text-align:center'>")
             .append(once.get(s)).append("</td><td style='text-align:center'>").append(sonra.get(s)).append("</td></tr>");
        h.append("<tr><td>Uygulama sonrası değerlendirilmemiş</td><td></td><td style='text-align:center'>").append(degerlenmemis).append("</td></tr>")
         .append("<tr><td><b>TOPLAM</b></td><td style='text-align:center'><b>").append(r.kalemler.size()).append("</b></td><td style='text-align:center'><b>").append(r.kalemler.size()).append("</b></td></tr></table>");
        h.append("</div>");

        // ============ BÖLÜM 5: Yatay risk tablosu ============
        h.append(word ? "<br clear=all style='page-break-before:always;mso-break-type:section-break'>" : "");
        h.append("<div class='WordSection2'>");
        h.append("<h2 style='margin-top:0'>BEŞİNCİ BÖLÜM – Risk Değerlendirme Tablosu</h2>");
        h.append("<table class='bas' style='width:100%;margin-bottom:4pt'><tr><td class='ust' colspan='4'>RİSK DEĞERLENDİRMESİ</td></tr>")
         .append("<tr><td><b>İŞYERİNİN ADI:</b> ").append(e(tam)).append("</td><td><b>TEL:</b> ").append(e(r.b("telefon"))).append("</td>")
         .append("<td><b>TARİH:</b> ").append(e(r.b("tarih"))).append("</td><td><b>RD YÖNTEMİ:</b> ").append(L ? "5×5 L MATRİS" : "FINE-KINNEY").append("</td></tr>")
         .append("<tr><td><b>ADRESİ:</b> ").append(e(adres)).append("</td><td><b>E-POSTA:</b> ").append(e(r.b("eposta"))).append("</td>")
         .append("<td><b>TEHLİKE SINIFI:</b> ").append(e(sinif)).append("</td><td><b>GEÇERLİLİK:</b> ").append(e(r.b("gecerlilik")))
         .append(" (").append(Rapor.yil(sinif)).append(" yıl)</td></tr></table>");

        int pc = L ? 4 : 5; // puan sütun sayısı (Ş O [F] R SEVİYE)
        h.append("<table class='rt'><colgroup>")
         .append(col(2.2)).append(col(6)).append(col(5)).append(col(7.5)).append(col(7));
        if (L) h.append(col(2.6)).append(col(2.6)).append(col(3)).append(col(4.4));
        else h.append(col(2.4)).append(col(2.4)).append(col(2.4)).append(col(3)).append(col(4));
        h.append(col(L ? 15.4 : 14)).append(col(8)).append(col(8)).append(col(4.2)).append(col(5));
        if (L) h.append(col(2.6)).append(col(2.6)).append(col(3)).append(col(4.4));
        else h.append(col(2.4)).append(col(2.4)).append(col(2.4)).append(col(3)).append(col(4));
        h.append(col(L ? 7.5 : 6.3))
         .append("</colgroup><thead><tr>")
         .append(th("SIRA NO", 2)).append(th("FAALİYET / PROSES", 2)).append(th("ETKİLENEN", 2)).append(th("TEHLİKE VE TEHLİKE KAYNAĞI", 2)).append(th("RİSK VE OLASI ETKİLER", 2))
         .append("<th colspan='").append(pc).append("'>UYGULAMA ÖNCESİ</th>")
         .append(th("DÜZELTİCİ – ÖNLEYİCİ FAALİYET", 2)).append(th("MEVCUT DURUM (YAPILDI / YAPILMADI)", 2)).append(th("FOTOĞRAF", 2)).append(th("TERMİN", 2)).append(th("SORUMLU", 2))
         .append("<th colspan='").append(pc).append("'>UYGULAMA SONRASI</th>").append(th("AÇIKLAMA / MEVZUAT", 2)).append("</tr><tr>");
        String ph = L ? "<th>O</th><th>Ş</th><th>R</th><th>SEVİYE</th>" : "<th>Ş</th><th>O</th><th>F</th><th>R</th><th>SEVİYE</th>";
        h.append(ph).append(ph).append("</tr></thead><tbody>");
        int no = 1;
        for (Kayit k : r.kalemler) {
            String sev = Yontem.seviye(k, y);
            Double p2 = Yontem.puan2(k, y);
            String sev2 = p2 == null ? null : Yontem.seviye(y, p2);
            String termin = k.termin.isEmpty() ? Yontem.termin(y, sev) : k.termin;
            h.append("<tr><td class='c'>").append(no++).append("</td><td><b>").append(e(k.faaliyet)).append("</b></td><td>").append(e(k.etkilenen))
             .append("</td><td>").append(e(k.tehlike)).append("</td><td>").append(e(k.risk)).append("</td>");
            if (L) h.append("<td class='c'>").append(Kinney.fmt(Yontem.lo(k))).append("</td><td class='c'>").append(Kinney.fmt(Yontem.ls(k))).append("</td>");
            else h.append("<td class='c'>").append(Kinney.fmt(k.s)).append("</td><td class='c'>").append(Kinney.fmt(k.o)).append("</td><td class='c'>").append(Kinney.fmt(k.f)).append("</td>");
            h.append("<td class='c'><b>").append(Kinney.fmt(Yontem.puan(k, y))).append("</b></td><td class='c sev' style='background:").append(Yontem.hex(y, sev)).append("'>").append(sev).append("</td>")
             .append("<td>").append(e(k.onlem)).append("</td><td>").append(e(k.mevcutDurum)).append("</td><td class='c'>").append(fotoHucre(k, word)).append("</td><td class='c'>").append(e(termin)).append("</td><td>").append(e(k.sorumlu)).append("</td>");
            if (p2 == null) for (int i = 0; i < pc; i++) h.append("<td></td>");
            else {
                if (L) h.append("<td class='c'>").append(Kinney.fmt(Yontem.lo2(k))).append("</td><td class='c'>").append(Kinney.fmt(Yontem.ls2(k))).append("</td>");
                else h.append("<td class='c'>").append(Kinney.fmt(k.s2)).append("</td><td class='c'>").append(Kinney.fmt(k.o2)).append("</td><td class='c'>").append(Kinney.fmt(k.f2)).append("</td>");
                h.append("<td class='c'><b>").append(Kinney.fmt(p2)).append("</b></td><td class='c sev' style='background:").append(Yontem.hex(y, sev2)).append("'>").append(sev2).append("</td>");
            }
            h.append("<td><i>").append(e(k.mevzuat)).append("</i></td></tr>");
        }
        if (r.kalemler.isEmpty()) h.append("<tr><td colspan='21' style='text-align:center;padding:12pt'>Rapora henüz risk eklenmedi.</td></tr>");
        h.append("</tbody></table>");

        // İmza tablosu
        h.append("<p style='margin-top:8pt'><b>RİSK DEĞERLENDİRMESİ EKİBİ</b></p><table class='imza' style='width:100%'><tr>");
        for (String[] x : r.ekip) h.append("<th>").append(e(x[0])).append("</th>");
        h.append("</tr><tr>");
        for (String[] x : r.ekip) h.append("<td>").append(e(x[1])).append("<br><br><span style='color:#888'>İmza</span></td>");
        h.append("</tr></table></div></body></html>");
        return h.toString();
    }

    /** Risk tablosundaki fotoğraf hücresi: önce / sonra küçük resimleri. */
    static String fotoHucre(Kayit k, boolean word) {
        List<String> a = DofUretici.mevcut(k.fotoOnce), b = DofUretici.mevcut(k.fotoSonra);
        if (a.isEmpty() && b.isEmpty()) return "";
        StringBuilder h = new StringBuilder();
        kucuk(h, a, "Önce", word);
        kucuk(h, b, "Sonra", word);
        return h.toString();
    }

    static void kucuk(StringBuilder h, List<String> l, String et, boolean word) {
        if (l.isEmpty()) return;
        h.append("<div style='font-size:5.5pt;color:#555;margin-top:1pt'>").append(et).append("</div>");
        int n = 0;
        for (String ad : l) {
            if (n++ == 2) { h.append("<div style='font-size:5.5pt;color:#555'>+").append(l.size() - 2).append(" foto</div>"); break; }
            int[] wh = DofUretici.boyut(ad);
            double o = Math.min(70.0 / wh[0], 52.0 / wh[1]);
            int w = (int) Math.round(wh[0] * o), hh = (int) Math.round(wh[1] * o);
            h.append("<img src='").append(DofUretici.src(ad, word)).append("' width='").append(w).append("' height='").append(hh)
             .append("' style='width:").append(w).append("px;height:").append(hh).append("px;margin:1pt 0'><br>");
        }
    }

    /** Raporda fotoğraf varsa Word için fotoğrafları gömülü MHTML (.doc) üretir; yoksa düz HTML. */
    public static String word(Rapor r) {
        Set<String> adlar = new LinkedHashSet<String>();
        for (Kayit k : r.kalemler) for (List<String> l : Arrays.asList(DofUretici.mevcut(k.fotoOnce), DofUretici.mevcut(k.fotoSonra)))
            for (int i = 0; i < Math.min(2, l.size()); i++) adlar.add(l.get(i));
        String html = html(r, true);
        if (adlar.isEmpty()) return html;
        String sinir = "----=_RD_" + Long.toHexString(System.currentTimeMillis());
        StringBuilder m = new StringBuilder();
        m.append("MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary=\"").append(sinir).append("\"; type=\"text/html\"\r\n\r\n")
         .append("--").append(sinir).append("\r\nContent-Type: text/html; charset=\"utf-8\"\r\nContent-Transfer-Encoding: base64\r\n")
         .append("Content-Location: file:///C:/dof.htm\r\n\r\n");
        try { m.append(B64.kodla(html.getBytes("UTF-8"), 76)).append("\r\n"); } catch (java.io.UnsupportedEncodingException ex) { throw new RuntimeException(ex); }
        for (String ad : adlar) {
            try {
                byte[] b = Depo.baytOku(Depo.foto(ad));
                m.append("\r\n--").append(sinir).append("\r\nContent-Type: image/jpeg\r\nContent-Transfer-Encoding: base64\r\n")
                 .append("Content-Location: file:///C:/dof_dosyalari/").append(ad).append("\r\n\r\n").append(B64.kodla(b, 76)).append("\r\n");
            } catch (Exception ignored) {}
        }
        return m.append("\r\n--").append(sinir).append("--\r\n").toString();
    }

    static String sayfaKir(boolean word) {
        return word ? "<br clear=all style='page-break-before:always'>" : "<div class='sayfa'></div>";
    }

    static String col(double pct) { return "<col style='width:" + pct + "%'>"; }

    static String th(String t, int rs) { return "<th rowspan='" + rs + "'>" + t + "</th>"; }

    static String sat(String k, String v) {
        return "<tr><td class='k'>" + e(k) + "</td><td>" + e(v) + "</td></tr>";
    }

    static String[] ayir(String s) {
        int i = s.indexOf(" – ");
        return new String[]{s.substring(0, i).replace('.', ','), s.substring(i + 3)};
    }

    static String kin(String y, String aralik, String sev, String eylem, String termin) {
        return "<tr><td style='text-align:center'><b>" + e(aralik) + "</b></td><td style='background:" + Yontem.hex(y, sev) + "'><b>" + sev
                + "</b></td><td>" + e(eylem) + "</td><td>" + e(termin) + "</td></tr>";
    }

    static String sonuc(String y, String baslik, String sev, String metin) {
        return "<p style='margin-top:10pt'><span style='background:" + Yontem.hex(y, sev) + ";padding:1pt 6pt;border:0.5pt solid #777'><b>" + e(baslik)
                + "</b></span></p><p>" + metin + "</p>";
    }

    /** Excel'in açabildiği HTML tablo (.xls). */
    public static String excel(Rapor r) {
        String y = r.yontem();
        boolean L = Yontem.lm(y);
        String ph = L ? "<th>O</th><th>Ş</th><th>R</th><th>Seviye</th>" : "<th>Ş</th><th>O</th><th>F</th><th>R</th><th>Seviye</th>";
        StringBuilder h = new StringBuilder();
        h.append("<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:x='urn:schemas-microsoft-com:office:excel'><head><meta charset='utf-8'>")
         .append("<style>td,th{border:0.5pt solid #777;vertical-align:top;mso-number-format:'\\@';font-family:Calibri;font-size:10pt;} th{background:#dfe8f3;} .n{mso-number-format:General;text-align:center;}</style></head><body>")
         .append("<table><tr><th colspan='20' style='font-size:14pt'>RİSK DEĞERLENDİRMESİ – ").append(e(r.b("kurum") + " " + r.b("birim"))).append("</th></tr>")
         .append("<tr><td colspan='20'>Adres: ").append(e(r.b("adres"))).append(" | Tehlike sınıfı: ").append(e(r.b("tehlikeSinifi")))
         .append(" | Tarih: ").append(e(r.b("tarih"))).append(" | Geçerlilik: ").append(e(r.b("gecerlilik"))).append(" | Yöntem: ").append(e(y)).append("</td></tr>")
         .append("<tr><th>Sıra</th><th>Faaliyet</th><th>Etkilenen</th><th>Tehlike</th><th>Risk</th>").append(ph)
         .append("<th>Düzeltici-Önleyici Faaliyet</th><th>Mevcut Durum</th><th>Fotoğraf</th><th>Termin</th><th>Sorumlu</th>").append(ph).append("<th>Mevzuat</th></tr>");
        int no = 1;
        for (Kayit k : r.kalemler) {
            String sev = Yontem.seviye(k, y);
            Double p2 = Yontem.puan2(k, y);
            h.append("<tr><td class='n'>").append(no++).append("</td><td>").append(e(k.faaliyet)).append("</td><td>").append(e(k.etkilenen))
             .append("</td><td>").append(e(k.tehlike)).append("</td><td>").append(e(k.risk)).append("</td>");
            if (L) h.append("<td class='n'>").append(Kinney.fmt(Yontem.lo(k))).append("</td><td class='n'>").append(Kinney.fmt(Yontem.ls(k))).append("</td>");
            else h.append("<td class='n'>").append(Kinney.fmt(k.s)).append("</td><td class='n'>").append(Kinney.fmt(k.o)).append("</td><td class='n'>").append(Kinney.fmt(k.f)).append("</td>");
            h.append("<td class='n'>").append(Kinney.fmt(Yontem.puan(k, y))).append("</td><td style='background:").append(Yontem.hex(y, sev)).append("'>").append(sev).append("</td><td>").append(e(k.onlem))
             .append("</td><td>").append(e(k.mevcutDurum)).append("</td><td>")
             .append(k.fotoSayisi() == 0 ? "" : e(k.fotoOnce.size() + " önce / " + k.fotoSonra.size() + " sonra" + (k.dofNo.isEmpty() ? "" : " (" + k.dofNo + ")")))
             .append("</td><td>").append(e(k.termin.isEmpty() ? Yontem.termin(y, sev) : k.termin)).append("</td><td>").append(e(k.sorumlu)).append("</td>");
            if (p2 == null) for (int i = 0; i < (L ? 4 : 5); i++) h.append("<td></td>");
            else {
                if (L) h.append("<td class='n'>").append(Kinney.fmt(Yontem.lo2(k))).append("</td><td class='n'>").append(Kinney.fmt(Yontem.ls2(k))).append("</td>");
                else h.append("<td class='n'>").append(Kinney.fmt(k.s2)).append("</td><td class='n'>").append(Kinney.fmt(k.o2)).append("</td><td class='n'>").append(Kinney.fmt(k.f2)).append("</td>");
                String s2 = Yontem.seviye(y, p2);
                h.append("<td class='n'>").append(Kinney.fmt(p2)).append("</td><td style='background:").append(Yontem.hex(y, s2)).append("'>").append(s2).append("</td>");
            }
            h.append("<td>").append(e(k.mevzuat)).append("</td></tr>");
        }
        h.append("</table></body></html>");
        return h.toString();
    }
}
