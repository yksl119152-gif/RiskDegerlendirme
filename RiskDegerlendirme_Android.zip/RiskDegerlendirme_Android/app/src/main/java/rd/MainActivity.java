package rd;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Consumer;

/**
 * Düzce Üniversitesi İSG Risk Değerlendirme – Android sürümü.
 * Masaüstü (JAR) sürümüyle aynı veri biçimini kullanır: risk_arsivi.json ve .rdr rapor dosyaları iki sürüm arasında taşınabilir.
 */
public class MainActivity extends Activity {
    static final int LACIVERT = 0xFF0B3A6F, MAVI = 0xFF1E6FB8, ACIK = 0xFFEEF3F9, GRI = 0xFF5F6B7A, YESIL = 0xFF2E7D32;
    static final int RQ_ICE_AKTAR = 11, RQ_RAPOR_AC = 12, RQ_KAYDET = 13, RQ_FOTO = 14;

    List<Kayit> arsiv;
    List<Isyeri> isyerleri;
    Rapor rapor;
    final Set<String> secili = new HashSet<String>();
    int sekme = 0;

    FrameLayout icerik;
    final Button[] sekmeDugme = new Button[3];
    TextView altBaslik;
    View bilgiGorunum, arsivGorunum, raporGorunum;

    // arşiv
    EditText ara;
    Spinner spKat, spSev;
    final List<Kayit> gorunen = new ArrayList<Kayit>();
    BaseAdapter arsivAdapter;
    TextView arsivSayac;
    Button raporaEkleDugme;

    // rapor
    BaseAdapter raporAdapter;
    TextView raporOzet;

    // kaydetme için bekleyen içerik
    byte[] bekleyenIcerik;
    String bekleyenMime;

    // =========================================================== yaşam döngüsü
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Depo.kok = getFilesDir();
        Depo.baslangicMetni = asset("arsiv_baslangic.json");
        Depo.isyeriMetni = asset("isyerleri.json");
        arsiv = Depo.arsivYukle();
        isyerleri = Depo.isyerleriYukle();
        rapor = sonRaporuYukle();
        try { getWindow().setStatusBarColor(LACIVERT); } catch (Throwable ignored) {}
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        setContentView(anaGorunum());
        sekmeSec(0);
        if (Depo.sonEklenenBaslangic > 0)
            bilgi("Risk arşivi güncellendi", "Diğer birimlerin risk değerlendirmelerinden " + Depo.sonEklenenBaslangic + " yeni risk arşivinize eklendi.");
    }

    String asset(String ad) {
        try {
            InputStream in = getAssets().open(ad);
            try { return Depo.okuAkis(in); } finally { in.close(); }
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        otomatikKaydet();
        arsivKaydet();
    }

    @Override
    public void onBackPressed() {
        if (sekme != 0) sekmeSec(0); else super.onBackPressed();
    }

    // =========================================================== yardımcılar
    int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    TextView yazi(String t, float sp, int renk, boolean kalin) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(renk);
        if (kalin) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    Button dugme(String t, int arka, int yaziRenk, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(yaziRenk);
        GradientDrawable g = new GradientDrawable();
        g.setColor(arka);
        g.setCornerRadius(dp(8));
        if (arka == Color.WHITE) g.setStroke(dp(1), 0xFFB8C4D3);
        b.setBackground(g);
        b.setPadding(dp(12), dp(6), dp(12), dp(6));
        b.setMinHeight(dp(42));
        b.setMinimumHeight(dp(42));
        b.setOnClickListener(l);
        return b;
    }

    static LinearLayout.LayoutParams agirlik(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
        return p;
    }

    LinearLayout.LayoutParams kenar(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    TextView rozet(String sev, String ust) {
        TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(11);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setTextColor(Color.BLACK);
        t.setPadding(dp(4), dp(4), dp(4), dp(4));
        rozetAyarla(t, sev, ust);
        return t;
    }

    String rozetYontem = null;

    /** Açık raporun yöntemi */
    String y() { return rapor == null ? Yontem.FK : rapor.yontem(); }

    void rozetAyarlaY(TextView t, String yontem, String sev, String ust) {
        rozetYontem = yontem;
        rozetAyarla(t, sev, ust);
        rozetYontem = null;
    }

    void rozetAyarla(TextView t, String sev, String ust) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(6));
        if (sev == null) {
            g.setColor(0xFFEEEEEE);
            t.setText(ust);
        } else {
            g.setColor(Yontem.argb(rozetYontem != null ? rozetYontem : y(), sev));
            t.setText(ust + "\n" + Yontem.kisa(sev));
        }
        t.setBackground(g);
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_LONG).show(); }

    void bilgi(String baslik, String m) {
        new AlertDialog.Builder(this).setTitle(baslik).setMessage(m).setPositiveButton("Tamam", null).show();
    }

    void onayla(String m, final Runnable r) {
        new AlertDialog.Builder(this).setMessage(m).setPositiveButton("Evet", (d, w) -> r.run()).setNegativeButton("Vazgeç", null).show();
    }

    static class Izle implements TextWatcher {
        final Consumer<String> c;
        Izle(Consumer<String> c) { this.c = c; }
        public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
        public void onTextChanged(CharSequence s, int a, int b, int d) {}
        public void afterTextChanged(Editable e) { c.accept(e.toString()); }
    }

    ArrayAdapter<String> spinnerAdapter(List<String> l) {
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, l);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return a;
    }

    // =========================================================== ana iskelet
    View anaGorunum() {
        LinearLayout kok = new LinearLayout(this);
        kok.setOrientation(LinearLayout.VERTICAL);
        kok.setBackgroundColor(0xFFF3F5F8);

        LinearLayout ust = new LinearLayout(this);
        ust.setOrientation(LinearLayout.HORIZONTAL);
        ust.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable ug = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{LACIVERT, MAVI});
        ust.setBackground(ug);
        ust.setPadding(dp(14), dp(10), dp(6), dp(10));
        LinearLayout bs = new LinearLayout(this);
        bs.setOrientation(LinearLayout.VERTICAL);
        bs.addView(yazi("DÜZCE ÜNİVERSİTESİ · İSG Risk Değerlendirme", 16, Color.WHITE, true));
        altBaslik = yazi("", 12, 0xFFD6E6F7, false);
        altBaslik.setSingleLine(true);
        altBaslik.setEllipsize(TextUtils.TruncateAt.END);
        bs.addView(altBaslik);
        ust.addView(bs, agirlik(1));
        final Button menu = new Button(this);
        menu.setText("⋮");
        menu.setTextSize(24);
        menu.setTextColor(Color.WHITE);
        menu.setBackgroundColor(Color.TRANSPARENT);
        menu.setOnClickListener(v -> menuGoster(menu));
        ust.addView(menu, new LinearLayout.LayoutParams(dp(52), dp(52)));
        kok.addView(ust);

        LinearLayout sekmeler = new LinearLayout(this);
        sekmeler.setOrientation(LinearLayout.HORIZONTAL);
        sekmeler.setPadding(dp(6), dp(6), dp(6), dp(2));
        String[] ad = {"Bilgiler", "Risk Arşivi", "Rapor"};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            Button b = dugme(ad[i], Color.WHITE, LACIVERT, v -> sekmeSec(k));
            LinearLayout.LayoutParams p = agirlik(1);
            p.setMargins(dp(3), 0, dp(3), 0);
            sekmeler.addView(b, p);
            sekmeDugme[i] = b;
        }
        kok.addView(sekmeler);

        icerik = new FrameLayout(this);
        kok.addView(icerik, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        baslikGuncelle();
        return kok;
    }

    void sekmeSec(int i) {
        sekme = i;
        for (int k = 0; k < 3; k++) {
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(8));
            g.setColor(k == i ? LACIVERT : Color.WHITE);
            if (k != i) g.setStroke(dp(1), 0xFFB8C4D3);
            sekmeDugme[k].setBackground(g);
            sekmeDugme[k].setTextColor(k == i ? Color.WHITE : LACIVERT);
            sekmeDugme[k].setTypeface(Typeface.DEFAULT, k == i ? Typeface.BOLD : Typeface.NORMAL);
        }
        sekmeDugme[2].setText("Rapor (" + rapor.kalemler.size() + ")");
        icerik.removeAllViews();
        if (i == 0) { if (bilgiGorunum == null) bilgiGorunum = bilgiSekmesi(); icerik.addView(bilgiGorunum); }
        else if (i == 1) { if (arsivGorunum == null) arsivGorunum = arsivSekmesi(); icerik.addView(arsivGorunum); arsivYenile(); }
        else { if (raporGorunum == null) raporGorunum = raporSekmesi(); icerik.addView(raporGorunum); raporYenile(); }
    }

    void baslikGuncelle() {
        String b = rapor.b("birim").trim();
        if (altBaslik != null) altBaslik.setText("Açık rapor: " + (b.isEmpty() ? "(birim adı girilmedi)" : b) + " · " + rapor.kalemler.size() + " risk");
    }

    void menuGoster(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        String[] m = {"Önizle / Yazdır (PDF)", "Word'e aktar (.doc)", "Excel'e aktar (.xls)", "Raporu dosyaya kaydet (.rdr, fotoğraflar dahil)", "Rapor dosyası aç",
                "Yeni rapor", "Arşive içe aktar (JSON / CSV / .rdr)", "Arşivi dışa aktar (JSON)", "Excel için CSV şablonu kaydet",
                "Başlangıç arşivini yeniden birleştir", "Yardım", "DÖF formları (toplu)"};
        for (int i = 0; i < m.length; i++) pm.getMenu().add(0, i, i, m[i]);
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 0: onizle(); break;
                case 1: kaydetSor(dosyaAdi("RD") + ".doc", "application/msword", RaporUretici.word(rapor)); break;
                case 2: kaydetSor(dosyaAdi("RD_Tablo") + ".xls", "application/vnd.ms-excel", RaporUretici.excel(rapor)); break;
                case 3: kaydetSor(dosyaAdi("RD") + ".rdr", "application/octet-stream", Json.write(rapor.toMapFotolu())); break;
                case 4: dosyaSec(RQ_RAPOR_AC, false); break;
                case 5: yeniRapor(); break;
                case 6: dosyaSec(RQ_ICE_AKTAR, true); break;
                case 7: {
                    List<Object> o = new ArrayList<Object>();
                    for (Kayit k : arsiv) o.add(Depo.arsivMap(k));
                    kaydetSor("risk_arsivi_" + Depo.bugun().replace(".", "") + ".json", "application/json", Json.write(o));
                    break;
                }
                case 8: kaydetSor("risk_sablonu.csv", "text/csv", Depo.csvSablon()); break;
                case 9: {
                    int n = birlestir(Depo.baslangicArsivi());
                    arsivKaydet();
                    arsivYenileTam();
                    toast(n == 0 ? "Başlangıç arşivindeki riskler zaten arşivde." : n + " risk geri eklendi.");
                    break;
                }
                case 11: dofToplu(); break;
                default: yardim();
            }
            return true;
        });
        pm.show();
    }

    // =========================================================== 1) Bilgiler
    View bilgiSekmesi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(8), dp(14), dp(24));
        sv.addView(l);
        l.addView(bolumBaslik("Kurum / birim bilgileri"));
        final EditText[] gecerlilik = new EditText[1];
        for (String[] a : Rapor.ALANLAR) {
            final String key = a[0];
            if (key.equals("uzmanAd")) l.addView(bolumBaslik("İSG profesyonelleri ve doküman"));
            l.addView(yazi(a[1], 13, GRI, false), kenar(0, 8, 0, 0));
            if (key.equals("tehlikeSinifi") || key.equals("uzmanSinif") || key.equals("yontem")) {
                final List<String> sec = key.equals("tehlikeSinifi") ? Arrays.asList("Az Tehlikeli", "Tehlikeli", "Çok Tehlikeli")
                        : key.equals("yontem") ? Arrays.asList(Yontem.ADLAR) : Arrays.asList("", "A", "B", "C");
                Spinner sp = new Spinner(this);
                sp.setAdapter(spinnerAdapter(new ArrayList<String>(sec)));
                int i = sec.indexOf(rapor.b(key));
                sp.setSelection(Math.max(0, i), false);
                sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                        if (sec.get(pos).equals(rapor.b(key))) return;
                        String eskiY = y();
                        rapor.bilgi.put(key, sec.get(pos));
                        if (key.equals("yontem")) yontemDegisti(eskiY);
                        if (key.equals("tehlikeSinifi")) gecerlilikGuncelle(gecerlilik[0]);
                        degis();
                    }
                    public void onNothingSelected(AdapterView<?> p) {}
                });
                l.addView(sp);
                continue;
            }
            if (key.equals("birim")) {
                LinearLayout sat = new LinearLayout(this);
                sat.setOrientation(LinearLayout.HORIZONTAL);
                sat.setGravity(Gravity.CENTER_VERTICAL);
                final EditText be = new EditText(this);
                be.setSingleLine(true);
                be.setText(rapor.b(key));
                be.setTextSize(15);
                be.setHint("Listeden seçin veya yazın");
                final TextView durum = yazi("", 12, GRI, false);
                be.addTextChangedListener(new Izle(t -> {
                    if (t.equals(rapor.b("birim"))) return;
                    rapor.bilgi.put("birim", t);
                    baslikGuncelle();
                    isyeriDurum(durum);
                    degis();
                }));
                sat.addView(be, agirlik(1));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(dp(6), 0, 0, 0);
                sat.addView(dugme("▼ İşyeri listesi", LACIVERT, Color.WHITE, v -> isyeriSec()), lp);
                l.addView(sat);
                isyeriDurum(durum);
                l.addView(durum);
                continue;
            }
            EditText e = new EditText(this);
            e.setSingleLine(!key.equals("adres") && !key.equals("ekipYazisi"));
            if (key.equals("ekipYazisi")) e.setHint("Örn. Turizm Fakültesi Dekanlığının 30.10.2026 tarihli ve … sayılı yazısı");
            e.setText(rapor.b(key));
            e.setTextSize(15);
            if (key.equals("calisanSayisi") || key.equals("alan")) e.setInputType(InputType.TYPE_CLASS_TEXT);
            if (key.equals("eposta")) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            if (key.equals("tarih") || key.equals("gecerlilik") || key.equals("uzmanBelgeTarih")) e.setHint("gg.aa.yyyy");
            if (key.equals("gecerlilik")) gecerlilik[0] = e;
            e.addTextChangedListener(new Izle(s -> {
                if (s.equals(rapor.b(key))) return;
                rapor.bilgi.put(key, s);
                if (key.equals("tarih")) gecerlilikGuncelle(gecerlilik[0]);
                if (key.equals("birim")) baslikGuncelle();
                degis();
            }));
            l.addView(e);
        }
        TextView not = yazi("Geçerlilik tarihi tehlike sınıfına göre otomatik hesaplanır (Az Tehlikeli 6, Tehlikeli 4, Çok Tehlikeli 2 yıl).", 12, GRI, false);
        l.addView(not, kenar(0, 4, 0, 0));

        l.addView(bolumBaslik("Risk değerlendirmesi ekibi"));
        final LinearLayout ekipKutu = new LinearLayout(this);
        ekipKutu.setOrientation(LinearLayout.VERTICAL);
        l.addView(ekipKutu);
        ekipCiz(ekipKutu);
        l.addView(dugme("+ Ekip üyesi ekle", Color.WHITE, LACIVERT, v -> {
            rapor.ekip.add(new String[]{"", ""});
            ekipCiz(ekipKutu);
            degis();
        }), kenar(0, 8, 0, 0));
        l.addView(dugme("Bilgileri ve ekibi işyeri kaydına kaydet", YESIL, Color.WHITE, v -> isyeriKaydet()), kenar(0, 8, 0, 0));
        TextView ip = yazi("Kaydettiğiniz ekip, bu birim listeden bir dahaki seçilişinde otomatik gelir.", 12, GRI, false);
        l.addView(ip, kenar(0, 4, 0, 0));
        return sv;
    }

    /** Yöntem değişince terminler, filtreler ve listeler güncellenir. */
    void yontemDegisti(String eski) {
        String yeni = y();
        int n = 0, yak = 0;
        for (Kayit k : rapor.kalemler) {
            if (k.termin.isEmpty() || k.termin.equals(Yontem.termin(eski, Yontem.seviye(k, eski)))) {
                k.termin = Yontem.termin(yeni, Yontem.seviye(k, yeni));
                n++;
            }
            if (Yontem.lm(yeni) && Yontem.lTuretilmis(k)) yak++;
        }
        filtreleriDoldur();
        arsivYenile();
        raporYenile();
        toast("Yöntem: " + yeni + ". " + n + " riskin termini güncellendi."
                + (yak > 0 ? " " + yak + " riskin L değeri Fine-Kinney'den yaklaşık (≈); kontrol ediniz." : ""));
    }

    // =========================================================== işyerleri
    void isyeriDurum(TextView t) {
        int ekipli = 0;
        for (Isyeri i : isyerleri) if (i.ekipVar()) ekipli++;
        Isyeri s = Isyeri.bul(isyerleri, rapor.b("birim"));
        String d = "İşyeri listesi: " + isyerleri.size() + " birim, ekibi kayıtlı: " + ekipli;
        if (s != null) d += s.ekipVar() ? " · bu birimin ekibi kayıtlı" : " · bu birimin ekibi henüz kayıtlı değil";
        else if (!rapor.b("birim").trim().isEmpty()) d += " · bu birim listede yok";
        t.setText(d);
    }

    void isyeriSec() {
        final String[] ad = new String[isyerleri.size()];
        for (int i = 0; i < ad.length; i++) ad[i] = isyerleri.get(i).ad + (isyerleri.get(i).ekipVar() ? "  ✓ ekip" : "");
        new AlertDialog.Builder(this).setTitle("İşyeri seçin").setItems(ad, (d, w) -> {
            Isyeri i = isyerleri.get(w);
            i.rapora(rapor);
            raporYukle();
            toast(i.ad + " bilgileri uygulandı" + (i.ekipVar() ? " (kayıtlı ekip yüklendi)." : "."));
        }).setNegativeButton("Vazgeç", null).show();
    }

    void isyeriKaydet() {
        final String ad = rapor.b("birim").trim();
        if (ad.isEmpty()) { toast("Önce birim (işyeri) adını yazın veya listeden seçin."); return; }
        final Isyeri var = Isyeri.bul(isyerleri, ad);
        Runnable kaydet = () -> {
            Isyeri i = var;
            if (i == null) { i = new Isyeri(); isyerleri.add(i); }
            i.raporDan(rapor);
            Depo.isyeriSirala(isyerleri);
            try { Depo.isyerleriKaydet(isyerleri); } catch (Exception e) { toast("Kaydedilemedi: " + e.getMessage()); return; }
            toast((var == null ? "Yeni işyeri eklendi: " : "İşyeri kaydı güncellendi: ") + ad);
            bilgiGorunum = null;
            sekmeSec(0);
        };
        if (var == null) onayla("“" + ad + "” işyeri listesinde yok. Yeni işyeri olarak eklensin mi?", kaydet);
        else kaydet.run();
    }

    void gecerlilikGuncelle(EditText e) {
        String g = Rapor.gecerlilikHesapla(rapor.b("tarih"), rapor.b("tehlikeSinifi"));
        if (g.isEmpty()) return;
        rapor.bilgi.put("gecerlilik", g);
        if (e != null && !e.getText().toString().equals(g)) e.setText(g);
    }

    TextView bolumBaslik(String t) {
        TextView v = yazi(t, 16, LACIVERT, true);
        v.setPadding(0, dp(18), 0, dp(4));
        return v;
    }

    void ekipCiz(final LinearLayout kutu) {
        kutu.removeAllViews();
        for (int i = 0; i < rapor.ekip.size(); i++) {
            final String[] e = rapor.ekip.get(i);
            LinearLayout s = new LinearLayout(this);
            s.setOrientation(LinearLayout.HORIZONTAL);
            s.setGravity(Gravity.CENTER_VERTICAL);
            EditText u = new EditText(this), a = new EditText(this);
            u.setHint("Unvan / görev"); a.setHint("Adı soyadı");
            u.setText(e[0]); a.setText(e[1]);
            u.setTextSize(14); a.setTextSize(14);
            u.addTextChangedListener(new Izle(t -> { if (!t.equals(e[0])) { e[0] = t; degis(); } }));
            a.addTextChangedListener(new Izle(t -> { if (!t.equals(e[1])) { e[1] = t; degis(); } }));
            s.addView(u, agirlik(1.1f));
            s.addView(a, agirlik(1));
            Button sil = new Button(this);
            sil.setText("✕");
            sil.setBackgroundColor(Color.TRANSPARENT);
            sil.setTextColor(0xFFC62828);
            sil.setOnClickListener(v -> onayla("“" + (e[0].isEmpty() ? "Bu satır" : e[0]) + "” ekipten çıkarılsın mı?", () -> {
                rapor.ekip.remove(e);
                ekipCiz(kutu);
                degis();
            }));
            s.addView(sil, new LinearLayout.LayoutParams(dp(44), dp(44)));
            kutu.addView(s);
        }
    }

    // =========================================================== 2) Arşiv
    View arsivSekmesi() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(8), dp(4), dp(8), dp(6));
        ara = new EditText(this);
        ara.setHint("Ara: faaliyet, tehlike, önlem, mevzuat…");
        ara.setSingleLine(true);
        ara.addTextChangedListener(new Izle(s -> arsivYenile()));
        l.addView(ara);
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.HORIZONTAL);
        spKat = new Spinner(this);
        spSev = new Spinner(this);
        AdapterView.OnItemSelectedListener sl = new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { arsivYenile(); }
            public void onNothingSelected(AdapterView<?> p) {}
        };
        filtreleriDoldur();
        spKat.setOnItemSelectedListener(sl);
        spSev.setOnItemSelectedListener(sl);
        f.addView(spKat, agirlik(1));
        f.addView(spSev, agirlik(1));
        l.addView(f);
        arsivSayac = yazi("", 12, GRI, false);
        arsivSayac.setPadding(dp(4), dp(2), dp(4), dp(4));
        l.addView(arsivSayac);

        ListView lv = new ListView(this);
        lv.setDividerHeight(dp(1));
        arsivAdapter = new BaseAdapter() {
            public int getCount() { return gorunen.size(); }
            public Object getItem(int i) { return gorunen.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View cv, ViewGroup par) { return arsivSatiri(gorunen.get(i), cv); }
        };
        lv.setAdapter(arsivAdapter);
        lv.setOnItemClickListener((p, v, pos, id) -> arsivDetay(gorunen.get(pos)));
        l.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout alt = new LinearLayout(this);
        alt.setOrientation(LinearLayout.HORIZONTAL);
        alt.setPadding(0, dp(6), 0, 0);
        Button yeni = dugme("+ Yeni risk", Color.WHITE, LACIVERT, v -> arsivYeni());
        Button tum = dugme("Tümü ✓", Color.WHITE, LACIVERT, v -> {
            boolean hepsi = true;
            for (Kayit k : gorunen) if (!secili.contains(k.id)) hepsi = false;
            for (Kayit k : gorunen) { if (hepsi) secili.remove(k.id); else secili.add(k.id); }
            arsivAdapter.notifyDataSetChanged();
            sayacGuncelle();
        });
        raporaEkleDugme = dugme("Rapora ekle", YESIL, Color.WHITE, v -> rapora());
        raporaEkleDugme.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams p1 = agirlik(1), p2 = agirlik(1), p3 = agirlik(1.6f);
        p1.setMargins(0, 0, dp(4), 0); p2.setMargins(dp(2), 0, dp(4), 0);
        alt.addView(yeni, p1);
        alt.addView(tum, p2);
        alt.addView(raporaEkleDugme, p3);
        l.addView(alt);
        return l;
    }

    static class ArsivTutucu {
        CheckBox cb; TextView baslik, tehlike, alt, rozet; Kayit k;
    }

    View arsivSatiri(final Kayit k, View cv) {
        ArsivTutucu h;
        if (cv == null) {
            h = new ArsivTutucu();
            LinearLayout s = new LinearLayout(this);
            s.setOrientation(LinearLayout.HORIZONTAL);
            s.setGravity(Gravity.CENTER_VERTICAL);
            s.setPadding(dp(2), dp(8), dp(6), dp(8));
            s.setBackgroundColor(Color.WHITE);
            h.cb = new CheckBox(this);
            h.cb.setFocusable(false);
            s.addView(h.cb);
            LinearLayout m = new LinearLayout(this);
            m.setOrientation(LinearLayout.VERTICAL);
            h.baslik = yazi("", 15, 0xFF1A1A1A, true);
            h.tehlike = yazi("", 13, 0xFF333333, false);
            h.tehlike.setMaxLines(2);
            h.tehlike.setEllipsize(TextUtils.TruncateAt.END);
            h.alt = yazi("", 11, GRI, false);
            h.alt.setSingleLine(true);
            h.alt.setEllipsize(TextUtils.TruncateAt.END);
            m.addView(h.baslik); m.addView(h.tehlike); m.addView(h.alt);
            s.addView(m, agirlik(1));
            h.rozet = rozet(Kinney.KABUL, "");
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT);
            rp.setMargins(dp(6), 0, 0, 0);
            s.addView(h.rozet, rp);
            s.setTag(h);
            cv = s;
            final ArsivTutucu hh = h;
            h.cb.setOnClickListener(v -> {
                if (hh.cb.isChecked()) secili.add(hh.k.id); else secili.remove(hh.k.id);
                sayacGuncelle();
            });
        }
        h = (ArsivTutucu) cv.getTag();
        h.k = k;
        h.cb.setChecked(secili.contains(k.id));
        h.baslik.setText(k.faaliyet);
        h.tehlike.setText(k.tehlike);
        h.alt.setText(k.id + " · " + k.kategori + (k.kaynak.isEmpty() ? "" : " · " + k.kaynak));
        rozetAyarla(h.rozet, Yontem.seviye(k, y()), "R = " + Kinney.fmt(Yontem.puan(k, y())) + (Yontem.lm(y()) && Yontem.lTuretilmis(k) ? " ≈" : ""));
        return cv;
    }

    void filtreleriDoldur() {
        if (spKat == null) return;
        Object eskiK = spKat.getSelectedItem(), eskiS = spSev.getSelectedItem();
        List<String> k = new ArrayList<String>();
        k.add("Tüm kategoriler");
        k.addAll(kategoriler());
        spKat.setAdapter(spinnerAdapter(k));
        List<String> s = new ArrayList<String>();
        s.add("Tüm seviyeler");
        s.addAll(Arrays.asList(Yontem.seviyeler(y())));
        spSev.setAdapter(spinnerAdapter(s));
        if (eskiK != null && k.contains(eskiK)) spKat.setSelection(k.indexOf(eskiK), false);
        if (eskiS != null && s.contains(eskiS)) spSev.setSelection(s.indexOf(eskiS), false);
    }

    List<String> kategoriler() {
        TreeSet<String> t = new TreeSet<String>(java.text.Collator.getInstance(new Locale("tr")));
        for (Kayit x : arsiv) if (!x.kategori.isEmpty()) t.add(x.kategori);
        return new ArrayList<String>(t);
    }

    void arsivYenile() {
        if (arsivAdapter == null) return;
        gorunen.clear();
        String q = Kayit.norm(ara.getText().toString());
        int ki = spKat.getSelectedItemPosition(), si = spSev.getSelectedItemPosition();
        String kat = ki > 0 ? (String) spKat.getSelectedItem() : null;
        String sev = si > 0 ? (String) spSev.getSelectedItem() : null;
        for (Kayit k : arsiv) {
            if (kat != null && !kat.equals(k.kategori)) continue;
            if (sev != null && !sev.equals(Yontem.seviye(k, y()))) continue;
            if (!q.isEmpty() && !Kayit.norm(k.kategori + k.faaliyet + k.tehlike + k.risk + k.onlem + k.mevzuat + k.kaynak).contains(q)) continue;
            gorunen.add(k);
        }
        arsivAdapter.notifyDataSetChanged();
        sayacGuncelle();
    }

    void arsivYenileTam() {
        filtreleriDoldur();
        arsivYenile();
    }

    void sayacGuncelle() {
        if (arsivSayac == null) return;
        arsivSayac.setText("Görünen " + gorunen.size() + " / " + arsiv.size() + " risk · İşaretli: " + secili.size()
                + "   (satıra dokunun: ayrıntı / düzenle)");
        raporaEkleDugme.setText(secili.isEmpty() ? "Rapora ekle" : "Rapora ekle (" + secili.size() + ")");
    }

    void arsivDetay(final Kayit k) {
        String m = "Fine-Kinney: " + Kinney.fmt(k.s) + " × " + Kinney.fmt(k.o) + " × " + Kinney.fmt(k.f) + " = " + Kinney.fmt(k.puan()) + "  (" + Yontem.seviye(k, Yontem.FK) + ")\n"
                + "5×5 L Matris: " + Kinney.fmt(Yontem.lo(k)) + " × " + Kinney.fmt(Yontem.ls(k)) + " = " + Kinney.fmt(Yontem.puan(k, Yontem.LM)) + "  (" + Yontem.seviye(k, Yontem.LM) + ")"
                + (Yontem.lTuretilmis(k) ? " – Fine-Kinney'den yaklaşık" : "") + "\n\n"
                + "TEHLİKE: " + k.tehlike + "\n\nRİSK: " + k.risk + "\n\nETKİLENEN: " + k.etkilenen
                + "\n\nDÜZELTİCİ-ÖNLEYİCİ FAALİYET:\n" + k.onlem + "\n\nMEVZUAT: " + k.mevzuat + "\n\nKAYNAK: " + k.kaynak + "\nKATEGORİ: " + k.kategori
                + (k.notlar.isEmpty() ? "" : "\n\nNOT: " + k.notlar);
        new AlertDialog.Builder(this).setTitle(k.id + " · " + k.faaliyet).setMessage(m)
                .setPositiveButton("Rapora ekle", (d, w) -> { secili.clear(); secili.add(k.id); rapora(); })
                .setNeutralButton("Düzenle", (d, w) -> arsivDuzenle(k))
                .setNegativeButton("Sil", (d, w) -> onayla(k.faaliyet + " arşivden silinsin mi?\n(Raporlardaki kopyalar etkilenmez.)", () -> {
                    arsiv.remove(k);
                    secili.remove(k.id);
                    arsivKaydet();
                    arsivYenileTam();
                }))
                .show();
    }

    void arsivYeni() {
        final Kayit k = new Kayit();
        if (spKat != null && spKat.getSelectedItemPosition() > 0) k.kategori = (String) spKat.getSelectedItem();
        k.kaynak = (rapor.b("kurum") + " " + rapor.b("birim")).trim();
        riskDuzenle("Arşive yeni risk", k, false, null, () -> {
            k.id = Depo.yeniId(arsiv);
            arsiv.add(k);
            arsivKaydet();
            arsivYenileTam();
            toast("Arşive eklendi: " + k.id);
        });
    }

    void arsivDuzenle(final Kayit k) {
        final Kayit c = k.kopya();
        riskDuzenle("Düzenle – " + k.id, c, false, null, () -> {
            c.id = k.id;
            arsiv.set(arsiv.indexOf(k), c);
            arsivKaydet();
            arsivYenileTam();
        });
    }

    void rapora() {
        if (secili.isEmpty()) { toast("Rapora eklemek istediğiniz risklerin kutusunu işaretleyin."); return; }
        Set<String> mevcut = new HashSet<String>();
        for (Kayit k : rapor.kalemler) mevcut.add(k.anahtar());
        int eklenen = 0, atlanan = 0;
        for (Kayit k : arsiv) {
            if (!secili.contains(k.id)) continue;
            if (mevcut.contains(k.anahtar())) { atlanan++; continue; }
            Kayit c = k.kopya();
            c.termin = Yontem.termin(y(), Yontem.seviye(c, y()));
            rapor.kalemler.add(c);
            mevcut.add(c.anahtar());
            eklenen++;
        }
        secili.clear();
        if (arsivAdapter != null) arsivAdapter.notifyDataSetChanged();
        sayacGuncelle();
        degis();
        sekmeDugme[2].setText("Rapor (" + rapor.kalemler.size() + ")");
        String m = eklenen + " risk rapora eklendi." + (atlanan > 0 ? "\n" + atlanan + " tanesi raporda zaten olduğu için atlandı." : "");
        new AlertDialog.Builder(this).setMessage(m).setPositiveButton("Rapora git", (d, w) -> sekmeSec(2)).setNegativeButton("Arşivde kal", null).show();
    }

    int birlestir(List<Kayit> gelen) { return Depo.birlestir(arsiv, gelen); }


    void arsivKaydet() {
        try { Depo.arsivKaydet(arsiv); } catch (Exception e) { toast("Arşiv kaydedilemedi: " + e.getMessage()); }
    }

    // =========================================================== 3) Rapor
    View raporSekmesi() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(8), dp(4), dp(8), dp(6));
        TextView ip = yazi("Satıra dokunun: mevcut durum, termin, sorumlu ve uygulama sonrası puanı girin. Basılı tutun: taşı / çıkar / DÖF formu ve fotoğraflar.", 12, GRI, false);
        ip.setPadding(dp(4), dp(2), dp(4), dp(4));
        l.addView(ip);
        ListView lv = new ListView(this);
        lv.setDividerHeight(dp(1));
        raporAdapter = new BaseAdapter() {
            public int getCount() { return rapor.kalemler.size(); }
            public Object getItem(int i) { return rapor.kalemler.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View cv, ViewGroup par) { return raporSatiri(i, cv); }
        };
        lv.setAdapter(raporAdapter);
        lv.setOnItemClickListener((p, v, pos, id) -> raporDuzenle(pos));
        lv.setOnItemLongClickListener((p, v, pos, id) -> { raporSatirMenu(pos); return true; });
        l.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        raporOzet = yazi("", 12, 0xFF1A1A1A, false);
        raporOzet.setPadding(dp(4), dp(6), dp(4), dp(2));
        l.addView(raporOzet);
        LinearLayout alt = new LinearLayout(this);
        alt.setOrientation(LinearLayout.HORIZONTAL);
        alt.setPadding(0, dp(6), 0, 0);
        Button sirala = dugme("Sırala", Color.WHITE, LACIVERT, v -> raporSirala());
        Button yeni = dugme("+ Yeni risk", Color.WHITE, LACIVERT, v -> raporaYeni());
        Button yaz = dugme("Önizle / PDF", LACIVERT, Color.WHITE, v -> onizle());
        yaz.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams p1 = agirlik(1), p2 = agirlik(1), p3 = agirlik(1.4f);
        p1.setMargins(0, 0, dp(4), 0); p2.setMargins(dp(2), 0, dp(4), 0);
        Button dofB = dugme("DÖF", Color.WHITE, LACIVERT, v -> dofToplu());
        LinearLayout.LayoutParams p4 = agirlik(0.8f);
        p4.setMargins(dp(2), 0, dp(4), 0);
        alt.addView(sirala, p1); alt.addView(dofB, p4); alt.addView(yeni, p2); alt.addView(yaz, p3);
        l.addView(alt);
        return l;
    }

    static class RaporTutucu {
        TextView no, baslik, tehlike, durum, once, sonra;
    }

    View raporSatiri(int i, View cv) {
        RaporTutucu h;
        if (cv == null) {
            h = new RaporTutucu();
            LinearLayout s = new LinearLayout(this);
            s.setOrientation(LinearLayout.HORIZONTAL);
            s.setGravity(Gravity.CENTER_VERTICAL);
            s.setPadding(dp(6), dp(8), dp(6), dp(8));
            s.setBackgroundColor(Color.WHITE);
            h.no = yazi("", 15, LACIVERT, true);
            h.no.setGravity(Gravity.CENTER);
            s.addView(h.no, new LinearLayout.LayoutParams(dp(30), ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout m = new LinearLayout(this);
            m.setOrientation(LinearLayout.VERTICAL);
            h.baslik = yazi("", 15, 0xFF1A1A1A, true);
            h.tehlike = yazi("", 13, 0xFF333333, false);
            h.tehlike.setMaxLines(2);
            h.tehlike.setEllipsize(TextUtils.TruncateAt.END);
            h.durum = yazi("", 11, GRI, false);
            h.durum.setMaxLines(2);
            h.durum.setEllipsize(TextUtils.TruncateAt.END);
            m.addView(h.baslik); m.addView(h.tehlike); m.addView(h.durum);
            s.addView(m, agirlik(1));
            h.once = rozet(Kinney.KABUL, "");
            h.sonra = rozet(null, "");
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(86), ViewGroup.LayoutParams.WRAP_CONTENT);
            rp.setMargins(dp(4), 0, 0, 0);
            s.addView(h.once, rp);
            TextView ok = yazi("→", 14, GRI, true);
            s.addView(ok);
            LinearLayout.LayoutParams rp2 = new LinearLayout.LayoutParams(dp(86), ViewGroup.LayoutParams.WRAP_CONTENT);
            s.addView(h.sonra, rp2);
            s.setTag(h);
            cv = s;
        }
        h = (RaporTutucu) cv.getTag();
        Kayit k = rapor.kalemler.get(i);
        h.no.setText(String.valueOf(i + 1));
        h.baslik.setText(k.faaliyet);
        h.tehlike.setText(k.tehlike);
        String d = (k.dofVar() ? "DÖF" + (k.dofDurum.startsWith("Etkin –") ? " kapandı" : k.dofDurum.startsWith("Etkin değil") ? " etkin değil" : " açık")
                + (k.fotoSayisi() > 0 ? " · " + k.fotoSayisi() + " foto" : "") + " · " : "")
                + (k.mevcutDurum.isEmpty() ? "Mevcut durum girilmedi" : "Mevcut: " + k.mevcutDurum)
                + " · Termin: " + (k.termin.isEmpty() ? "-" : k.termin) + (k.sorumlu.isEmpty() ? "" : " · " + k.sorumlu);
        h.durum.setText(d);
        rozetAyarla(h.once, Yontem.seviye(k, y()), "R = " + Kinney.fmt(Yontem.puan(k, y())) + (Yontem.lm(y()) && Yontem.lTuretilmis(k) ? " ≈" : ""));
        Double p2 = Yontem.puan2(k, y());
        if (p2 == null) rozetAyarla(h.sonra, null, "Sonra\n—");
        else rozetAyarla(h.sonra, Yontem.seviye(y(), p2), "R = " + Kinney.fmt(p2));
        return cv;
    }

    void raporYenile() {
        if (raporAdapter != null) raporAdapter.notifyDataSetChanged();
        ozetGuncelle();
    }

    void ozetGuncelle() {
        if (raporOzet == null) return;
        Map<String, Integer> say = new LinkedHashMap<String, Integer>();
        for (String s : Yontem.seviyeler(y())) say.put(s, 0);
        for (Kayit k : rapor.kalemler) { String s = Yontem.seviye(k, y()); say.put(s, say.get(s) + 1); }
        SpannableStringBuilder sb = new SpannableStringBuilder();
        String b = "Raporda " + rapor.kalemler.size() + " risk  ";
        sb.append(b);
        sb.setSpan(new StyleSpan(Typeface.BOLD), 0, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        for (String s : Yontem.seviyeler(y())) {
            if (say.get(s) == 0) continue;
            int st = sb.length();
            sb.append(" ").append(Yontem.kisa(s)).append(": ").append(String.valueOf(say.get(s))).append(" ");
            sb.setSpan(new BackgroundColorSpan(Yontem.argb(y(), s)), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append("  ");
        }
        raporOzet.setText(sb);
        sekmeDugme[2].setText("Rapor (" + rapor.kalemler.size() + ")");
        baslikGuncelle();
    }

    void raporDuzenle(final int i) {
        final Kayit c = rapor.kalemler.get(i).kopya();
        riskDuzenle((i + 1) + ". risk – " + c.faaliyet, c, true, y(), () -> {
            rapor.kalemler.set(i, c);
            raporYenile();
            degis();
        });
    }

    void raporSatirMenu(final int i) {
        final Kayit k = rapor.kalemler.get(i);
        String[] m = {"Düzenle", "Yukarı taşı", "Aşağı taşı", "En başa taşı", "Rapordan çıkar", "Bu hâliyle arşive ekle", "Fotoğraf ekle / DÖF formu"};
        new AlertDialog.Builder(this).setTitle((i + 1) + ". " + k.faaliyet).setItems(m, (d, w) -> {
            switch (w) {
                case 0: raporDuzenle(i); break;
                case 1: if (i > 0) { Collections.swap(rapor.kalemler, i, i - 1); raporYenile(); degis(); } break;
                case 2: if (i < rapor.kalemler.size() - 1) { Collections.swap(rapor.kalemler, i, i + 1); raporYenile(); degis(); } break;
                case 3: rapor.kalemler.remove(i); rapor.kalemler.add(0, k); raporYenile(); degis(); break;
                case 4: onayla("“" + k.faaliyet + "” rapordan çıkarılsın mı? (Arşivde kalır.)", () -> { rapor.kalemler.remove(k); raporYenile(); degis(); }); break;
                case 6: dofDuzenle(i); break;
                default: {
                    int n = birlestir(Collections.singletonList(k.kopya()));
                    arsivKaydet();
                    arsivYenileTam();
                    toast(n > 0 ? "Arşive eklendi." : "Bu risk (aynı faaliyet ve tehlike) arşivde zaten var.");
                }
            }
        }).show();
    }

    void raporSirala() {
        final java.text.Collator col = java.text.Collator.getInstance(new Locale("tr"));
        new AlertDialog.Builder(this).setTitle("Rapordaki riskleri sırala").setItems(new String[]{"Kategoriye göre", "Risk puanına göre (yüksekten düşüğe)"}, (d, w) -> {
            if (w == 0) Collections.sort(rapor.kalemler, (a, b) -> { int c = col.compare(a.kategori, b.kategori); return c != 0 ? c : col.compare(a.faaliyet, b.faaliyet); });
            else Collections.sort(rapor.kalemler, (a, b) -> Double.compare(Yontem.puan(b, y()), Yontem.puan(a, y())));
            raporYenile();
            degis();
        }).show();
    }

    void raporaYeni() {
        final Kayit k = new Kayit();
        k.kaynak = (rapor.b("kurum") + " " + rapor.b("birim")).trim();
        riskDuzenle("Yeni risk (rapora ve arşive)", k, true, y(), () -> {
            rapor.kalemler.add(k);
            if (birlestir(Collections.singletonList(k.kopya())) > 0) { arsivKaydet(); arsivYenileTam(); }
            raporYenile();
            degis();
        });
    }

    // =========================================================== risk düzenleme penceresi
    /** yontem: null = arşiv modu (iki yöntem birlikte), aksi hâlde raporun yöntemi. */
    void riskDuzenle(String baslik, final Kayit k, final boolean raporModu, final String yontem, final Runnable kaydedildi) {
        final boolean fk = yontem == null || !Yontem.lm(yontem), lm = yontem == null || Yontem.lm(yontem);
        ScrollView sv = new ScrollView(this);
        final LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(6), dp(18), dp(10));
        sv.addView(l);

        final AutoCompleteTextView kat = new AutoCompleteTextView(this);
        kat.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, kategoriler()));
        kat.setThreshold(1);
        kat.setSingleLine(true);
        kat.setOnFocusChangeListener((v, f) -> { if (f) kat.showDropDown(); });
        kat.setOnClickListener(v -> kat.showDropDown());
        etiketle(l, "Kategori", kat, k.kategori);
        final EditText faaliyet = alan(l, "Faaliyet / proses", k.faaliyet, 1);
        final EditText etkilenen = alan(l, "Etkilenen", k.etkilenen, 1);
        final EditText tehlike = alan(l, "Tehlike ve tehlike kaynağı", k.tehlike, 3);
        final EditText risk = alan(l, "Risk ve olası etkiler", k.risk, 3);

        Spinner ss = null, so = null, sf = null, lo = null, ls = null;
        final TextView sonuc = rozet(Kinney.KABUL, ""), lsonuc = rozet(Kinney.KABUL, "");
        if (fk) {
            l.addView(bolumBaslik("Uygulama öncesi – Fine-Kinney (R = O × F × Ş)"));
            ss = kinneySpinner(l, "Şiddet (Ş)", Kinney.SIDDET, k.s, false);
            so = kinneySpinner(l, "Olasılık (O)", Kinney.OLASILIK, k.o, false);
            sf = kinneySpinner(l, "Frekans (F)", Kinney.FREKANS, k.f, false);
            sonuc.setTextSize(15);
            l.addView(sonuc, kenar(0, 6, 0, 4));
        }
        if (lm) {
            l.addView(bolumBaslik("Uygulama öncesi – 5×5 L Matris (R = O × Ş)"));
            lo = kinneySpinner(l, "Olasılık (O)", Yontem.L_OLASILIK, Yontem.lo(k), false);
            ls = kinneySpinner(l, "Şiddet (Ş)", Yontem.L_SIDDET, Yontem.ls(k), false);
            if (Yontem.lTuretilmis(k)) {
                TextView n = yazi("≈ Fine-Kinney değerlerinden yaklaşık hesaplandı; değiştirirseniz bu değerler saklanır.", 12, 0xFF8A5A00, false);
                l.addView(n, kenar(0, 4, 0, 0));
            }
            lsonuc.setTextSize(15);
            l.addView(lsonuc, kenar(0, 6, 0, 4));
        }
        final Spinner fS = ss, fO = so, fF = sf, fLo = lo, fLs = ls;
        final int lo0 = lo == null ? -1 : lo.getSelectedItemPosition(), ls0 = ls == null ? -1 : ls.getSelectedItemPosition();

        final EditText onlem = alan(l, "Düzeltici – önleyici faaliyet", k.onlem, 5);
        final EditText mevzuat = alan(l, "Açıklama / mevzuat", k.mevzuat, 2);
        final EditText kaynak = alan(l, "Kaynak (hangi rapordan)", k.kaynak, 1);
        final EditText notE = alan(l, "Not (rapora basılmaz)", k.notlar, 2);

        final EditText[] rap = new EditText[3];
        final Spinner[] sonra = new Spinner[3];
        final TextView sonuc2 = rozet(null, "");
        if (raporModu) {
            l.addView(bolumBaslik("Birime özgü"));
            rap[0] = alan(l, "Mevcut durum (yapıldı / yapılmadı)", k.mevcutDurum, 3);
            rap[1] = alan(l, "Termin", k.termin, 1);
            rap[2] = alan(l, "Sorumlu", k.sorumlu, 1);
            l.addView(dugme("Termini risk seviyesine göre öner", Color.WHITE, LACIVERT, v -> {
                double r = Yontem.lm(yontem) ? deger(fLo) * deger(fLs) : deger(fS) * deger(fO) * deger(fF);
                rap[1].setText(Yontem.termin(yontem, Yontem.seviye(yontem, r)));
            }), kenar(0, 6, 0, 0));
            l.addView(bolumBaslik("Uygulama sonrası (kalıntı risk) – boş bırakılabilir"));
            if (Yontem.lm(yontem)) {
                sonra[0] = kinneySpinner(l, "Olasılık (O)", Yontem.L_OLASILIK, Yontem.lo2(k), true);
                sonra[1] = kinneySpinner(l, "Şiddet (Ş)", Yontem.L_SIDDET, Yontem.ls2(k), true);
            } else {
                sonra[0] = kinneySpinner(l, "Şiddet (Ş)", Kinney.SIDDET, k.s2, true);
                sonra[1] = kinneySpinner(l, "Olasılık (O)", Kinney.OLASILIK, k.o2, true);
                sonra[2] = kinneySpinner(l, "Frekans (F)", Kinney.FREKANS, k.f2, true);
            }
            sonuc2.setTextSize(15);
            l.addView(sonuc2, kenar(0, 6, 0, 4));
        }

        final Runnable hesapla = () -> {
            if (fk) {
                double r = deger(fS) * deger(fO) * deger(fF);
                rozetAyarlaY(sonuc, Yontem.FK, Yontem.seviye(Yontem.FK, r), "R = " + Kinney.fmt(r));
            }
            if (lm) {
                double r = deger(fLo) * deger(fLs);
                rozetAyarlaY(lsonuc, Yontem.LM, Yontem.seviye(Yontem.LM, r), "R = " + Kinney.fmt(r));
            }
            if (raporModu) {
                boolean L = Yontem.lm(yontem);
                Double a = degerN(sonra[0]), b = degerN(sonra[1]), c = L ? Double.valueOf(1) : degerN(sonra[2]);
                if (a == null || b == null || c == null) rozetAyarla(sonuc2, null, "Uygulama sonrası değerlendirilmedi");
                else rozetAyarlaY(sonuc2, yontem, Yontem.seviye(yontem, a * b * c), "R = " + Kinney.fmt(a * b * c));
            }
        };
        AdapterView.OnItemSelectedListener sl = new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { hesapla.run(); }
            public void onNothingSelected(AdapterView<?> p) {}
        };
        for (Spinner s : new Spinner[]{ss, so, sf, lo, ls, sonra[0], sonra[1], sonra[2]}) if (s != null) s.setOnItemSelectedListener(sl);
        hesapla.run();

        final AlertDialog d = new AlertDialog.Builder(this).setTitle(baslik).setView(sv)
                .setPositiveButton("Kaydet", null).setNegativeButton("Vazgeç", null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (faaliyet.getText().toString().trim().isEmpty() && tehlike.getText().toString().trim().isEmpty()) {
                toast("En azından Faaliyet veya Tehlike alanını doldurun.");
                return;
            }
            k.kategori = kat.getText().toString().trim();
            k.faaliyet = faaliyet.getText().toString().trim();
            k.etkilenen = etkilenen.getText().toString().trim();
            k.tehlike = tehlike.getText().toString().trim();
            k.risk = risk.getText().toString().trim();
            k.onlem = onlem.getText().toString().trim();
            k.mevzuat = mevzuat.getText().toString().trim();
            k.kaynak = kaynak.getText().toString().trim();
            k.notlar = notE.getText().toString().trim();
            if (fk) { k.s = deger(fS); k.o = deger(fO); k.f = deger(fF); }
            if (lm && (!Yontem.lTuretilmis(k) || fLo.getSelectedItemPosition() != lo0 || fLs.getSelectedItemPosition() != ls0)) {
                k.lo = deger(fLo); k.ls = deger(fLs);
            }
            if (raporModu) {
                k.mevcutDurum = rap[0].getText().toString().trim();
                k.termin = rap[1].getText().toString().trim();
                k.sorumlu = rap[2].getText().toString().trim();
                if (Yontem.lm(yontem)) { k.lo2 = degerN(sonra[0]); k.ls2 = degerN(sonra[1]); }
                else { k.s2 = degerN(sonra[0]); k.o2 = degerN(sonra[1]); k.f2 = degerN(sonra[2]); }
            }
            d.dismiss();
            kaydedildi.run();
        }));
        d.show();
        try { d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); } catch (Exception ignored) {}
    }

    void etiketle(LinearLayout l, String et, View v, String deger) {
        l.addView(yazi(et, 13, GRI, false), kenar(0, 8, 0, 0));
        if (v instanceof EditText) ((EditText) v).setText(deger);
        l.addView(v);
    }

    EditText alan(LinearLayout l, String et, String deger, int satir) {
        EditText e = new EditText(this);
        e.setTextSize(15);
        if (satir <= 1) e.setSingleLine(true);
        else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            e.setMinLines(satir);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        etiketle(l, et, e, deger);
        return e;
    }

    Spinner kinneySpinner(LinearLayout l, String et, String[] liste, Double deger, boolean bosOlabilir) {
        List<String> sec = new ArrayList<String>();
        if (bosOlabilir) sec.add("— (değerlendirilmedi)");
        sec.addAll(Arrays.asList(liste));
        String hedef = Kinney.secenek(liste, deger);
        if (deger != null && !sec.contains(hedef)) sec.add(hedef);
        Spinner sp = new Spinner(this);
        sp.setAdapter(spinnerAdapter(sec));
        sp.setSelection(deger == null ? 0 : Math.max(0, sec.indexOf(hedef)), false);
        l.addView(yazi(et, 13, GRI, false), kenar(0, 6, 0, 0));
        l.addView(sp);
        return sp;
    }

    static double deger(Spinner s) {
        Double d = Kinney.oku(s.getSelectedItem());
        return d == null ? 0 : d;
    }

    static Double degerN(Spinner s) { return Kinney.oku(s.getSelectedItem()); }

    // =========================================================== önizleme ve yazdırma
    void onizle() {
        if (rapor.kalemler.isEmpty()) toast("Raporda henüz risk yok.");
        final Dialog d = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        LinearLayout ust = new LinearLayout(this);
        ust.setOrientation(LinearLayout.HORIZONTAL);
        ust.setBackgroundColor(LACIVERT);
        ust.setPadding(dp(6), dp(6), dp(6), dp(6));
        final WebView w = new WebView(this);
        w.getSettings().setBuiltInZoomControls(true);
        w.getSettings().setDisplayZoomControls(false);
        w.getSettings().setUseWideViewPort(true);
        w.getSettings().setLoadWithOverviewMode(true);
        w.setWebViewClient(new WebViewClient());
        Button kapat = dugme("✕ Kapat", LACIVERT, Color.WHITE, v -> d.dismiss());
        Button dikey = dugme("PDF: Rapor metni", Color.WHITE, LACIVERT, v -> yazdir(1));
        Button yatay = dugme("PDF: Risk tablosu (yatay)", Color.WHITE, LACIVERT, v -> yazdir(2));
        ust.addView(kapat, agirlik(0.8f));
        LinearLayout.LayoutParams p = agirlik(1.2f);
        p.setMargins(dp(4), 0, dp(4), 0);
        ust.addView(dikey, p);
        ust.addView(yatay, agirlik(1.4f));
        l.addView(ust);
        TextView not = yazi("Rapor iki PDF olarak kaydedilir: dikey sayfalar (kapak – 4. bölüm) ve yatay risk tablosu. Tek parça düzenlenebilir dosya için menüden “Word'e aktar”ı kullanın.", 12, GRI, false);
        not.setPadding(dp(10), dp(6), dp(10), dp(6));
        not.setBackgroundColor(0xFFFFF8D6);
        l.addView(not);
        l.addView(w, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        d.setContentView(l);
        w.loadDataWithBaseURL(null, ipucuGizle(RaporUretici.html(rapor, false)), "text/html", "utf-8", null);
        d.show();
    }

    static String ipucuGizle(String h) {
        return h.replace("<div class='ipucu'>", "<div class='ipucu' style='display:none'>");
    }

    /** kapsam 1 = dikey bölümler, 2 = yatay risk tablosu. Yazdırma için ayrı bir WebView kullanılır. */
    WebView yazdirmaWeb;

    void yazdir(final int kapsam) {
        final String ad = dosyaAdi(kapsam == 1 ? "RD_Rapor" : "RD_Risk_Tablosu");
        yazdirmaWeb = new WebView(this);
        yazdirmaWeb.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                PrintAttributes.MediaSize ms = kapsam == 2 ? PrintAttributes.MediaSize.ISO_A4.asLandscape() : PrintAttributes.MediaSize.ISO_A4;
                PrintAttributes at = new PrintAttributes.Builder().setMediaSize(ms)
                        .setMinMargins(new PrintAttributes.Margins(400, 400, 400, 400)).build();
                pm.print(ad, view.createPrintDocumentAdapter(ad), at);
            }
        });
        String html = ipucuGizle(RaporUretici.html(rapor, false, kapsam))
                .replace("@media screen{", "@media screen_devre_disi{"); // yazdırmada ekran gölgeleri olmasın
        yazdirmaWeb.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    // =========================================================== DÖF (fotoğraflı düzeltici-önleyici faaliyet formu)
    List<String> fotoHedef;            // fotoğraf seçici dönünce eklenecek liste
    Runnable fotoYenile;               // fotoğraf şeridini yeniden çizer

    void dofDuzenle(final int i) {
        final Kayit k = rapor.kalemler.get(i);
        final Kayit c = k.kopya();
        ScrollView sv = new ScrollView(this);
        final LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(6), dp(18), dp(10));
        sv.addView(l);
        String sev = Yontem.seviye(c, y());
        TextView bilgi = yazi(c.faaliyet + " — " + c.tehlike + "\nR = " + Kinney.fmt(Yontem.puan(c, y())) + " (" + sev + ") · Termin: "
                + (c.termin.isEmpty() ? "-" : c.termin) + " · Sorumlu: " + (c.sorumlu.isEmpty() ? "-" : c.sorumlu)
                + "\nÖnlem, mevcut durum, sorumlu, termin ve kalıntı risk “Düzenle” ekranından girilir.", 12, GRI, false);
        bilgi.setBackgroundColor(ACIK);
        bilgi.setPadding(dp(8), dp(6), dp(8), dp(6));
        l.addView(bilgi);

        final EditText no = alan(l, "DÖF no", c.dofNo.isEmpty() ? rapor.dofNoOner(k) : c.dofNo, 1);
        final EditText tespit = alan(l, "Tespit tarihi (gg.aa.yyyy)", c.tespitTarihi.isEmpty() ? rapor.b("tarih") : c.tespitTarihi, 1);
        final Spinner tur = secimSpinner(l, "Faaliyet türü", DofUretici.TURLER, c.dofTuru);
        final Spinner kaynak = secimSpinner(l, "DÖF kaynağı", DofUretici.KAYNAKLAR, c.dofKaynak);
        final EditText kok = alan(l, "Kök neden", c.kokNeden, 3);
        fotoSeridi(l, "Tespit fotoğrafları (önce)", c.fotoOnce);
        final EditText yapilan = alan(l, "Yapılan faaliyet", c.dofYapilan, 3);
        final EditText tamam = alan(l, "Tamamlanma tarihi", c.dofTamamlanma, 1);
        fotoSeridi(l, "Uygulama sonrası fotoğraflar (sonra)", c.fotoSonra);
        final Spinner durum = secimSpinner(l, "Etkinlik sonucu", DofUretici.DURUMLAR, c.dofDurum);
        final EditText kontrol = alan(l, "Kontrol tarihi", c.dofKontrolTarihi, 1);
        final EditText yeniNo = alan(l, "Yeni DÖF no (etkin değilse)", c.dofYeniNo, 1);

        final Runnable al = () -> {
            c.dofNo = no.getText().toString().trim(); c.tespitTarihi = tespit.getText().toString().trim();
            c.dofTuru = (String) tur.getSelectedItem(); c.dofKaynak = (String) kaynak.getSelectedItem();
            c.kokNeden = kok.getText().toString().trim(); c.dofYapilan = yapilan.getText().toString().trim();
            c.dofTamamlanma = tamam.getText().toString().trim(); c.dofDurum = (String) durum.getSelectedItem();
            c.dofKontrolTarihi = kontrol.getText().toString().trim(); c.dofYeniNo = yeniNo.getText().toString().trim();
        };
        final AlertDialog d = new AlertDialog.Builder(this).setTitle("DÖF formu – " + (i + 1) + ". risk").setView(sv)
                .setPositiveButton("Kaydet", null).setNeutralButton("PDF / Word", null).setNegativeButton("Vazgeç", null).create();
        d.setOnShowListener(x -> {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                al.run();
                k.dofNo = c.dofNo; k.tespitTarihi = c.tespitTarihi; k.dofTuru = c.dofTuru; k.dofKaynak = c.dofKaynak; k.kokNeden = c.kokNeden;
                k.dofYapilan = c.dofYapilan; k.dofTamamlanma = c.dofTamamlanma; k.dofDurum = c.dofDurum;
                k.dofKontrolTarihi = c.dofKontrolTarihi; k.dofYeniNo = c.dofYeniNo;
                k.fotoOnce.clear(); k.fotoOnce.addAll(c.fotoOnce);
                k.fotoSonra.clear(); k.fotoSonra.addAll(c.fotoSonra);
                d.dismiss();
                raporYenile();
                degis();
                toast("DÖF kaydedildi (" + k.fotoSayisi() + " fotoğraf).");
            });
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                al.run();
                dofCiktiSor(Collections.singletonList(c));
            });
        });
        d.show();
        try { d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); } catch (Exception ignored) {}
    }

    Spinner secimSpinner(LinearLayout l, String et, String[] liste, String deger) {
        Spinner sp = new Spinner(this);
        sp.setAdapter(spinnerAdapter(new ArrayList<String>(Arrays.asList(liste))));
        int i = Arrays.asList(liste).indexOf(deger);
        sp.setSelection(Math.max(0, i), false);
        l.addView(yazi(et, 13, GRI, false), kenar(0, 6, 0, 0));
        l.addView(sp);
        return sp;
    }

    /** Başlık + yatay kaydırılabilir küçük resimler + "Fotoğraf ekle" düğmesi */
    void fotoSeridi(LinearLayout l, String baslik, final List<String> liste) {
        l.addView(bolumBaslik(baslik));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        final LinearLayout serit = new LinearLayout(this);
        serit.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(serit);
        l.addView(hs);
        final Runnable[] ciz = new Runnable[1];
        ciz[0] = () -> {
            serit.removeAllViews();
            if (liste.isEmpty()) serit.addView(yazi("Henüz fotoğraf yok", 13, GRI, false));
            for (final String ad : new ArrayList<String>(liste)) {
                LinearLayout kutu = new LinearLayout(this);
                kutu.setOrientation(LinearLayout.VERTICAL);
                kutu.setPadding(dp(3), dp(3), dp(3), dp(3));
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                android.graphics.Bitmap bm = kucukResim(Depo.foto(ad), dp(150));
                if (bm != null) iv.setImageBitmap(bm);
                iv.setBackgroundColor(0xFFDDE3EA);
                iv.setOnClickListener(v -> buyukGoster(ad));
                kutu.addView(iv, new LinearLayout.LayoutParams(dp(150), dp(112)));
                LinearLayout bt = new LinearLayout(this);
                bt.setOrientation(LinearLayout.HORIZONTAL);
                Button sol = kucukDugme("◀", v -> { int j = liste.indexOf(ad); if (j > 0) { Collections.swap(liste, j, j - 1); ciz[0].run(); } });
                Button sil = kucukDugme("Sil", v -> onayla("Fotoğraf formdan çıkarılsın mı?", () -> { liste.remove(ad); ciz[0].run(); }));
                Button sag = kucukDugme("▶", v -> { int j = liste.indexOf(ad); if (j >= 0 && j < liste.size() - 1) { Collections.swap(liste, j, j + 1); ciz[0].run(); } });
                bt.addView(sol, agirlik(1)); bt.addView(sil, agirlik(1.3f)); bt.addView(sag, agirlik(1));
                kutu.addView(bt, new LinearLayout.LayoutParams(dp(150), ViewGroup.LayoutParams.WRAP_CONTENT));
                serit.addView(kutu);
            }
        };
        ciz[0].run();
        l.addView(dugme("+ Fotoğraf ekle (galeri / dosyalar)", Color.WHITE, LACIVERT, v -> {
            fotoHedef = liste;
            fotoYenile = ciz[0];
            Intent in = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            in.addCategory(Intent.CATEGORY_OPENABLE);
            in.setType("image/*");
            in.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            try { startActivityForResult(in, RQ_FOTO); } catch (Exception e) { toast("Galeri açılamadı: " + e.getMessage()); }
        }), kenar(0, 4, 0, 0));
    }

    Button kucukDugme(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding(0, dp(2), 0, dp(2));
        b.setOnClickListener(l);
        return b;
    }

    android.graphics.Bitmap kucukResim(java.io.File f, int en) {
        try {
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(f.getPath(), o);
            int s = 1;
            while (o.outWidth / (s * 2) >= en) s *= 2;
            o = new android.graphics.BitmapFactory.Options();
            o.inSampleSize = s;
            return android.graphics.BitmapFactory.decodeFile(f.getPath(), o);
        } catch (Exception e) {
            return null;
        }
    }

    void buyukGoster(String ad) {
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setImageBitmap(kucukResim(Depo.foto(ad), getResources().getDisplayMetrics().widthPixels));
        new AlertDialog.Builder(this).setView(iv).setPositiveButton("Kapat", null).show();
    }

    /** Seçilen fotoğrafı EXIF yönüne göre döndürüp en uzun kenarı 1600 piksel JPEG olarak uygulama klasörüne kopyalar. */
    String fotoKopyala(Uri u) throws Exception {
        android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in = getContentResolver().openInputStream(u);
        android.graphics.BitmapFactory.decodeStream(in, null, o);
        in.close();
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 1600) s *= 2;
        o = new android.graphics.BitmapFactory.Options();
        o.inSampleSize = s;
        in = getContentResolver().openInputStream(u);
        android.graphics.Bitmap bm = android.graphics.BitmapFactory.decodeStream(in, null, o);
        in.close();
        if (bm == null) throw new Exception("resim okunamadı");
        int yon = android.media.ExifInterface.ORIENTATION_NORMAL;
        try {
            in = getContentResolver().openInputStream(u);
            yon = new android.media.ExifInterface(in).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL);
            in.close();
        } catch (Exception ignored) {}
        float aci = yon == android.media.ExifInterface.ORIENTATION_ROTATE_90 ? 90 : yon == android.media.ExifInterface.ORIENTATION_ROTATE_180 ? 180
                : yon == android.media.ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
        float olcek = Math.min(1f, 1600f / Math.max(bm.getWidth(), bm.getHeight()));
        if (aci != 0 || olcek < 1f) {
            android.graphics.Matrix m = new android.graphics.Matrix();
            m.postScale(olcek, olcek);
            m.postRotate(aci);
            android.graphics.Bitmap yeni = android.graphics.Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            if (yeni != bm) bm.recycle();
            bm = yeni;
        }
        String ad = Depo.yeniFotoAdi();
        java.io.FileOutputStream fo = new java.io.FileOutputStream(Depo.foto(ad));
        bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, fo);
        fo.close();
        bm.recycle();
        return ad;
    }

    void dofToplu() {
        if (rapor.kalemler.isEmpty()) { toast("Raporda risk yok."); return; }
        String[] sev = Yontem.seviyeler(y());
        final String enDusuk = sev[sev.length - 1];
        final List<Kayit> dofOlan = new ArrayList<Kayit>(), onlemli = new ArrayList<Kayit>();
        for (Kayit k : rapor.kalemler) {
            if (k.dofVar()) dofOlan.add(k);
            if (!enDusuk.equals(Yontem.seviye(k, y()))) onlemli.add(k);
        }
        String[] s = {"DÖF bilgisi veya fotoğrafı girilmiş riskler (" + dofOlan.size() + ")",
                "Önlem gerektiren tüm riskler (" + onlemli.size() + ")", "Rapordaki tüm riskler (" + rapor.kalemler.size() + ")"};
        new AlertDialog.Builder(this).setTitle("Toplu DÖF formları (her risk ayrı form)").setItems(s, (d, w) -> {
            List<Kayit> l = w == 0 ? dofOlan : w == 1 ? onlemli : rapor.kalemler;
            if (l.isEmpty()) toast("Seçilen kapsamda risk yok.");
            else dofCiktiSor(l);
        }).show();
    }

    void dofCiktiSor(final List<Kayit> l) {
        new AlertDialog.Builder(this).setTitle(l.size() + " DÖF formu").setItems(new String[]{"PDF olarak kaydet / yazdır", "Word (.docx, fotoğraflar gömülü)"}, (d, w) -> {
            String ad = dosyaAdi(l.size() == 1 ? "DOF" : "DOF_Formlari");
            if (w == 0) {
                yazdirHtml(ad, DofUretici.html(rapor, l, false), false);
            } else {
                try {
                    kaydetSorBayt(ad + ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", DocxDof.uret(rapor, l));
                } catch (Exception e) { toast("Word dosyası oluşturulamadı: " + e.getMessage()); }
            }
        }).show();
    }

    void yazdirHtml(final String ad, String html, final boolean yatay) {
        yazdirmaWeb = new WebView(this);
        yazdirmaWeb.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                PrintAttributes at = new PrintAttributes.Builder()
                        .setMediaSize(yatay ? PrintAttributes.MediaSize.ISO_A4.asLandscape() : PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(new PrintAttributes.Margins(300, 300, 300, 300)).build();
                pm.print(ad, view.createPrintDocumentAdapter(ad), at);
            }
        });
        yazdirmaWeb.loadDataWithBaseURL(null, html.replace("@media screen{", "@media screen_devre_disi{"), "text/html", "utf-8", null);
    }

    // =========================================================== dosya işlemleri (Storage Access Framework)
    void kaydetSor(String ad, String mime, String metin) { kaydetSorBayt(ad, mime, metin.getBytes(StandardCharsets.UTF_8)); }

    void kaydetSorBayt(String ad, String mime, byte[] icerik) {
        bekleyenIcerik = icerik;
        bekleyenMime = mime;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, ad);
        try { startActivityForResult(i, RQ_KAYDET); } catch (Exception e) { toast("Dosya kaydetme ekranı açılamadı: " + e.getMessage()); }
    }

    void dosyaSec(int rq, boolean coklu) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        if (coklu) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, rq); } catch (Exception e) { toast("Dosya seçici açılamadı: " + e.getMessage()); }
    }

    @Override
    protected void onActivityResult(int rq, int sonuc, Intent veri) {
        super.onActivityResult(rq, sonuc, veri);
        if (sonuc != RESULT_OK || veri == null) return;
        try {
            if (rq == RQ_FOTO) {
                List<Uri> uriler = new ArrayList<Uri>();
                ClipData cd = veri.getClipData();
                if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) uriler.add(cd.getItemAt(i).getUri());
                else if (veri.getData() != null) uriler.add(veri.getData());
                int hata = 0;
                for (Uri u : uriler) {
                    try { if (fotoHedef != null) fotoHedef.add(fotoKopyala(u)); } catch (Exception e) { hata++; }
                }
                if (fotoYenile != null) fotoYenile.run();
                if (hata > 0) toast(hata + " fotoğraf okunamadı.");
                return;
            }
            if (rq == RQ_KAYDET) {
                final Uri u = veri.getData();
                OutputStream os = getContentResolver().openOutputStream(u, "wt");
                os.write(bekleyenIcerik);
                os.close();
                final String mime = bekleyenMime;
                new AlertDialog.Builder(this).setMessage("Dosya kaydedildi:\n" + dosyaAdiOku(u))
                        .setPositiveButton("Aç", (d, w) -> {
                            Intent v = new Intent(Intent.ACTION_VIEW);
                            v.setDataAndType(u, mime);
                            v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(v); } catch (Exception e) { toast("Bu dosyayı açacak uygulama bulunamadı (Word / Excel / tarayıcı)."); }
                        })
                        .setNeutralButton("Paylaş", (d, w) -> {
                            Intent s = new Intent(Intent.ACTION_SEND);
                            s.setType(mime);
                            s.putExtra(Intent.EXTRA_STREAM, u);
                            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(s, "Paylaş"));
                        })
                        .setNegativeButton("Tamam", null).show();
            } else {
                List<Uri> uriler = new ArrayList<Uri>();
                ClipData cd = veri.getClipData();
                if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) uriler.add(cd.getItemAt(i).getUri());
                else if (veri.getData() != null) uriler.add(veri.getData());
                if (rq == RQ_RAPOR_AC) raporuAc(uriler.get(0));
                else iceAktar(uriler);
            }
        } catch (Exception e) {
            bilgi("Hata", "İşlem yapılamadı:\n" + e.getMessage());
        }
    }

    String dosyaAdiOku(Uri u) {
        String ad = u.getLastPathSegment();
        try {
            Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null) {
                if (c.moveToFirst()) ad = c.getString(0);
                c.close();
            }
        } catch (Exception ignored) {}
        return ad == null ? "dosya" : ad;
    }

    String uriOku(Uri u) throws Exception {
        InputStream in = getContentResolver().openInputStream(u);
        try { return Depo.okuAkis(in); } finally { in.close(); }
    }

    void raporuAc(final Uri u) throws Exception {
        final Rapor r = Rapor.fromJson(uriOku(u));
        onayla("“" + dosyaAdiOku(u) + "” açılacak; şu an açık olan rapor kapanacak. Devam edilsin mi?", () -> {
            rapor = r;
            raporYukle();
            toast("Rapor açıldı: " + r.kalemler.size() + " risk");
        });
    }

    void iceAktar(List<Uri> uriler) throws Exception {
        int top = 0, ekl = 0;
        for (Uri u : uriler) {
            String ad = dosyaAdiOku(u);
            String t = uriOku(u);
            String kucuk = ad.toLowerCase(Locale.ROOT);
            List<Kayit> gelen = (kucuk.endsWith(".csv") || kucuk.endsWith(".txt")) ? Depo.csvOku(t) : Depo.listeOku(t);
            String kaynak = ad.contains(".") ? ad.substring(0, ad.lastIndexOf('.')) : ad;
            for (Kayit k : gelen) if (k.kaynak.isEmpty()) k.kaynak = kaynak;
            top += gelen.size();
            ekl += birlestir(gelen);
        }
        arsivKaydet();
        arsivYenileTam();
        bilgi("İçe aktarma tamamlandı", "Dosyalardaki risk: " + top + "\nArşive yeni eklenen: " + ekl + "\nZaten arşivde olduğu için atlanan: " + (top - ekl));
    }

    // =========================================================== rapor yönetimi
    Rapor sonRaporuYukle() {
        try {
            java.io.File f = Depo.sonRaporDosyasi();
            if (f.exists()) {
                Rapor r = Rapor.fromJson(Depo.oku(f));
                r.bilgi.remove("_dosya");
                return r;
            }
        } catch (Exception ignored) {}
        return Rapor.yeni();
    }

    void otomatikKaydet() {
        try { Depo.yaz(Depo.sonRaporDosyasi(), Json.write(rapor.toMap())); } catch (Exception ignored) {}
    }

    void degis() {
        otomatikKaydet();
        baslikGuncelle();
    }

    void yeniRapor() {
        onayla("Yeni rapor başlatılsın mı?\nŞu anki raporu saklamak istiyorsanız önce menüden “Raporu dosyaya kaydet”i kullanın.", () -> {
            Rapor eski = rapor;
            rapor = Rapor.yeni();
            for (String k : new String[]{"uzmanAd", "uzmanSinif", "uzmanBelgeNo", "uzmanBelgeTarih", "hekimAd"}) rapor.bilgi.put(k, eski.b(k));
            for (String[] e : rapor.ekip) {
                if (e[0].startsWith("İş Güvenliği")) e[1] = eski.ekipKisi("güvenliği uzmanı");
                if (e[0].startsWith("İşyeri Hekimi")) e[1] = eski.ekipKisi("hekim");
            }
            raporYukle();
            toast("Yeni rapor: önce birim bilgilerini girin, sonra arşivden riskleri seçin.");
        });
    }

    void raporYukle() {
        bilgiGorunum = null;
        degis();
        sekmeSec(0);
    }

    String dosyaAdi(String on) {
        String b = rapor.b("birim").trim();
        if (b.isEmpty()) b = "Birim";
        b = Depo.trAscii(b).replaceAll("[^A-Za-z0-9]+", "_").replaceAll("^_|_$", "");
        String t = rapor.b("tarih").replace(".", "");
        return on + "_" + b + (t.isEmpty() ? "" : "_" + t);
    }

    void yardim() {
        bilgi("Yardım",
                "1) Bilgiler: Birim adı, adres, tehlike sınıfı ve risk değerlendirmesi ekibini girin. Geçerlilik tarihi otomatik hesaplanır.\n\n"
              + "2) Risk Arşivi: Kurumun ortak risk havuzu. Arayın, filtreleyin; birime uyan risklerin kutusunu işaretleyip “Rapora ekle”ye basın. "
              + "Satıra dokunarak ayrıntıyı görür, düzenler veya silersiniz.\n\n"
              + "3) Rapor: Satıra dokunup mevcut durumu, termini, sorumluyu ve uygulama sonrası puanları girin. Basılı tutarak sıralayın veya çıkarın.\n\n"
              + "ÇIKTILAR (⋮ menüsü): Önizle / Yazdır ile PDF (rapor metni dikey, risk tablosu yatay iki ayrı PDF); Word'e aktar (.doc, Word'de açılır); Excel'e aktar.\n\n"
              + "DİĞER BİRİMLERİN RİSKLERİ: Claude'un hazırladığı JSON dosyasını veya Excel'den kaydedilmiş CSV'yi “Arşive içe aktar” ile ekleyin. Aynı faaliyet + tehlike ikinci kez eklenmez.\n\n"
              + "BİLGİSAYARLA ORTAK KULLANIM: Masaüstü (JAR) sürümüyle aynı dosya biçimi kullanılır. Arşivi “Arşivi dışa aktar” ile JSON olarak alıp bilgisayarda içe aktarabilirsiniz; .rdr rapor dosyaları her iki sürümde açılır.\n\n"
              + "DÖF FORMU: Rapor ekranında riske basılı tutun → “DÖF formu ve fotoğraflar”. Galeriden önce/sonra fotoğrafı ekleyin; PDF veya Word (.docx) olarak kaydedin. Toplu formlar için alttaki DÖF düğmesi.\n\n"
              + "FINE-KINNEY: R = Olasılık × Frekans × Şiddet\n≤20 Kabul edilebilir · 20–70 Olası · 70–200 Önemli · 200–400 Yüksek · 400–1800 Çok yüksek · >1800 Tolere edilemez\n\n"
              + "5×5 L MATRİS: R = Olasılık × Şiddet (1–5)\n1 Önemsiz · 2–6 Düşük · 8–12 Orta · 15–16 Yüksek · 20–25 Tolere edilemez\n"
              + "Yöntem Bilgiler sekmesinden seçilir. ≈ işareti, L değerinin Fine-Kinney'den yaklaşık hesaplandığını gösterir.");
    }
}
