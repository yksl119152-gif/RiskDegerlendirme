package rd;

import java.util.*;

/** Bir risk kaydı. Arşivde ve raporda aynı yapı kullanılır; rapora özgü alanlar arşivde boş kalır. */
public class Kayit {
    public String id = "", kategori = "", faaliyet = "", etkilenen = "Çalışanlar, 3. Şahıslar, İşyeri",
            tehlike = "", risk = "", onlem = "", mevzuat = "", kaynak = "";
    /** Rapora basılmayan açıklama (kaynak yöntem, dönüşüm notu vb.) */
    public String notlar = "";
    public double s = 15, o = 3, f = 3;
    // Rapora özgü
    public String mevcutDurum = "", termin = "", sorumlu = "";
    public Double s2, o2, f2; // uygulama sonrası (boş olabilir)
    // 5×5 L matris değerleri (1–5). Boşsa Fine-Kinney değerlerinden yaklaşık türetilir (bkz. Yontem).
    public Double lo, ls, lo2, ls2;
    // DÖF (düzeltici-önleyici faaliyet) formu – rapora özgü
    public String dofNo = "", dofTuru = "Düzeltici", dofKaynak = "Risk değerlendirmesi", tespitTarihi = "", kokNeden = "",
            dofYapilan = "", dofTamamlanma = "", dofDurum = "Açık", dofKontrolTarihi = "", dofYeniNo = "";
    /** Fotoğraf dosya adları (Depo.fotoKlasoru içinde): tespit (önce) ve uygulama sonrası (sonra) */
    public final List<String> fotoOnce = new ArrayList<String>(), fotoSonra = new ArrayList<String>();

    public boolean dofVar() {
        return !dofNo.isEmpty() || !kokNeden.isEmpty() || !dofYapilan.isEmpty() || !fotoOnce.isEmpty() || !fotoSonra.isEmpty()
                || !"Açık".equals(dofDurum) || !tespitTarihi.isEmpty();
    }

    public int fotoSayisi() { return fotoOnce.size() + fotoSonra.size(); }

    public double puan() { return s * o * f; }

    public Double puan2() {
        if (s2 == null || o2 == null || f2 == null) return null;
        return s2 * o2 * f2;
    }

    public Kayit kopya() {
        Kayit k = fromMap(toMap());
        return k;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("id", id); m.put("kategori", kategori); m.put("faaliyet", faaliyet);
        m.put("etkilenen", etkilenen); m.put("tehlike", tehlike); m.put("risk", risk);
        m.put("s", s); m.put("o", o); m.put("f", f);
        m.put("onlem", onlem); m.put("mevzuat", mevzuat); m.put("kaynak", kaynak);
        if (!notlar.isEmpty()) m.put("not", notlar);
        if (!mevcutDurum.isEmpty()) m.put("mevcutDurum", mevcutDurum);
        if (!termin.isEmpty()) m.put("termin", termin);
        if (!sorumlu.isEmpty()) m.put("sorumlu", sorumlu);
        if (s2 != null) m.put("s2", s2);
        if (o2 != null) m.put("o2", o2);
        if (f2 != null) m.put("f2", f2);
        if (lo != null) m.put("lo", lo);
        if (ls != null) m.put("ls", ls);
        if (lo2 != null) m.put("lo2", lo2);
        if (ls2 != null) m.put("ls2", ls2);
        if (dofVar()) {
            Map<String, Object> d = new LinkedHashMap<String, Object>();
            d.put("no", dofNo); d.put("tur", dofTuru); d.put("kaynak", dofKaynak); d.put("tespitTarihi", tespitTarihi);
            d.put("kokNeden", kokNeden); d.put("yapilan", dofYapilan); d.put("tamamlanma", dofTamamlanma);
            d.put("durum", dofDurum); d.put("kontrolTarihi", dofKontrolTarihi); d.put("yeniNo", dofYeniNo);
            d.put("fotoOnce", new ArrayList<Object>(fotoOnce)); d.put("fotoSonra", new ArrayList<Object>(fotoSonra));
            m.put("dof", d);
        }
        return m;
    }

    public static Kayit fromMap(Map<?, ?> m) {
        Kayit k = new Kayit();
        k.id = str(m, "id"); k.kategori = str(m, "kategori"); k.faaliyet = str(m, "faaliyet");
        String et = str(m, "etkilenen"); if (!et.isEmpty()) k.etkilenen = et;
        k.tehlike = str(m, "tehlike"); k.risk = str(m, "risk");
        k.s = num(m, "s", 15); k.o = num(m, "o", 3); k.f = num(m, "f", 3);
        k.onlem = str(m, "onlem"); k.mevzuat = str(m, "mevzuat"); k.kaynak = str(m, "kaynak");
        k.notlar = str(m, "not");
        k.mevcutDurum = str(m, "mevcutDurum"); k.termin = str(m, "termin"); k.sorumlu = str(m, "sorumlu");
        k.s2 = numN(m, "s2"); k.o2 = numN(m, "o2"); k.f2 = numN(m, "f2");
        k.lo = numN(m, "lo"); k.ls = numN(m, "ls"); k.lo2 = numN(m, "lo2"); k.ls2 = numN(m, "ls2");
        if (m.get("dof") instanceof Map) {
            Map<?, ?> d = (Map<?, ?>) m.get("dof");
            k.dofNo = str(d, "no");
            String t = str(d, "tur"); if (!t.isEmpty()) k.dofTuru = t;
            t = str(d, "kaynak"); if (!t.isEmpty()) k.dofKaynak = t;
            k.tespitTarihi = str(d, "tespitTarihi"); k.kokNeden = str(d, "kokNeden"); k.dofYapilan = str(d, "yapilan");
            k.dofTamamlanma = str(d, "tamamlanma");
            t = str(d, "durum"); if (!t.isEmpty()) k.dofDurum = t;
            k.dofKontrolTarihi = str(d, "kontrolTarihi"); k.dofYeniNo = str(d, "yeniNo");
            liste(d.get("fotoOnce"), k.fotoOnce);
            liste(d.get("fotoSonra"), k.fotoSonra);
        }
        return k;
    }

    static void liste(Object o, List<String> l) {
        if (o instanceof List) for (Object x : (List<?>) o) if (x != null) l.add(x.toString());
    }

    static String str(Map<?, ?> m, String k) {
        Object v = m.get(k);
        return v == null ? "" : v.toString();
    }

    static double num(Map<?, ?> m, String k, double d) {
        Double v = numN(m, k);
        return v == null ? d : v;
    }

    static Double numN(Map<?, ?> m, String k) {
        Object v = m.get(k);
        if (v instanceof Number) return ((Number) v).doubleValue();
        if (v instanceof String && !((String) v).trim().isEmpty()) {
            try { return Double.valueOf(((String) v).trim().replace(',', '.')); } catch (Exception e) { return null; }
        }
        return null;
    }

    /** Aynı riskin arşive iki kez girmesini önlemek için kullanılan anahtar. */
    public String anahtar() {
        return (norm(faaliyet) + "|" + norm(tehlike));
    }

    static String norm(String x) {
        return x.toLowerCase(new Locale("tr")).replaceAll("[^a-zçğıöşü0-9]", "");
    }
}
