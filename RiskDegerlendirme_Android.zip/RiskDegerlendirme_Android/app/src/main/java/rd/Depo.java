package rd;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

/** Arşiv ve rapor dosyalarının kaydedildiği yer: kullanıcı klasörü/Duzce_Risk_Degerlendirme */
public final class Depo {
    private Depo() {}

    /** Android: uygulamanın iç depolama klasörü (MainActivity atar). Masaüstünde boş kalır. */
    public static File kok;
    /** Android: assets içindeki başlangıç dosyalarının metni (MainActivity atar). Masaüstünde JAR kaynağından okunur. */
    public static String baslangicMetni, isyeriMetni;

    /** Başlangıç arşivinin sürümü. Arttırıldığında yeni riskler mevcut kullanıcı arşivine bir kez eklenir. */
    public static final int ARSIV_SURUM = 4;

    public static File klasor() {
        File d = kok != null ? kok : new File(System.getProperty("user.home"), "Duzce_Risk_Degerlendirme");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static File raporKlasoru() {
        File d = new File(klasor(), "Raporlar");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static File ciktiKlasoru() {
        File d = new File(klasor(), "Ciktilar");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static File arsivDosyasi() { return new File(klasor(), "risk_arsivi.json"); }
    public static File sonRaporDosyasi() { return new File(klasor(), "son_rapor.json"); }

    public static String oku(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try { return okuAkis(in); } finally { in.close(); }
    }

    public static String okuAkis(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        String t = new String(bo.toByteArray(), StandardCharsets.UTF_8);
        if (t.startsWith("﻿")) t = t.substring(1);
        return t;
    }

    public static void yaz(File f, String icerik) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8);
        try { w.write(icerik); } finally { w.close(); }
        if (f.exists() && !f.delete()) throw new IOException("Dosya güncellenemedi: " + f);
        if (!tmp.renameTo(f)) throw new IOException("Dosya yazılamadı: " + f);
    }

    // ---------------- Arşiv ----------------
    static String kaynak(String ad, String android) {
        if (android != null) return android;
        try {
            InputStream in = Depo.class.getResourceAsStream("/" + ad);
            if (in == null) return null;
            try { return okuAkis(in); } finally { in.close(); }
        } catch (Exception e) {
            return null;
        }
    }

    public static List<Kayit> baslangicArsivi() {
        try {
            String t = kaynak("arsiv_baslangic.json", baslangicMetni);
            return t == null ? new ArrayList<Kayit>() : listeOku(t);
        } catch (Exception e) {
            return new ArrayList<Kayit>();
        }
    }

    /** Son yüklemede başlangıç arşivinden eklenen yeni risk sayısı (bilgi mesajı için). */
    public static int sonEklenenBaslangic = 0;

    public static List<Kayit> arsivYukle() {
        File f = arsivDosyasi(), sf = new File(klasor(), "arsiv_surum.txt");
        if (f.exists()) {
            try {
                List<Kayit> l = listeOku(oku(f));
                int surum = 1;
                try { surum = Integer.parseInt(oku(sf).trim()); } catch (Exception ignored) {}
                if (surum < ARSIV_SURUM) {
                    List<Kayit> bas = baslangicArsivi();
                    lDegerleriniTamamla(l, bas);
                    sonEklenenBaslangic = birlestir(l, bas);
                    arsivKaydet(l);
                    yaz(sf, String.valueOf(ARSIV_SURUM));
                }
                return l;
            } catch (Exception e) {
                // bozuk dosyayı yedekle, başlangıç arşivine dön
                f.renameTo(new File(klasor(), "risk_arsivi_bozuk_" + System.currentTimeMillis() + ".json"));
            }
        }
        List<Kayit> l = baslangicArsivi();
        try { arsivKaydet(l); yaz(sf, String.valueOf(ARSIV_SURUM)); } catch (IOException ignored) {}
        return l;
    }

    /** Önceki sürümlerden kalan kayıtlara, başlangıç arşivindeki özgün 5×5 L matris değerlerini ve notunu aktarır. */
    static void lDegerleriniTamamla(List<Kayit> arsiv, List<Kayit> bas) {
        Map<String, Kayit> m = new HashMap<String, Kayit>();
        for (Kayit b : bas) if (b.lo != null) m.put(b.anahtar(), b);
        for (Kayit k : arsiv) {
            if (k.lo != null) continue;
            Kayit b = m.get(k.anahtar());
            if (b == null) continue;
            k.lo = b.lo; k.ls = b.ls;
            if (k.notlar.startsWith("Kaynak yöntem") || k.notlar.startsWith("İSG riski değildir")) k.notlar = b.notlar;
        }
    }

    /** Aynı faaliyet + tehlike arşivde yoksa ekler; eklenen sayısını döndürür. */
    public static int birlestir(List<Kayit> arsiv, List<Kayit> gelen) {
        Set<String> var = new HashSet<String>();
        for (Kayit k : arsiv) var.add(k.anahtar());
        int n = 0;
        for (Kayit k : gelen) {
            if (var.contains(k.anahtar())) continue;
            k.id = yeniId(arsiv);
            k.mevcutDurum = ""; k.termin = ""; k.sorumlu = ""; k.s2 = null; k.o2 = null; k.f2 = null; k.lo2 = null; k.ls2 = null;
            dofTemizle(k);
            arsiv.add(k);
            var.add(k.anahtar());
            n++;
        }
        return n;
    }

    /** Arşive giden kayıtlardan rapora özgü DÖF bilgilerini ve fotoğrafları çıkarır. */
    static void dofTemizle(Kayit c) {
        c.dofNo = ""; c.dofTuru = "Düzeltici"; c.dofKaynak = "Risk değerlendirmesi"; c.tespitTarihi = ""; c.kokNeden = "";
        c.dofYapilan = ""; c.dofTamamlanma = ""; c.dofDurum = "Açık"; c.dofKontrolTarihi = ""; c.dofYeniNo = "";
        c.fotoOnce.clear(); c.fotoSonra.clear();
    }

    // ---------------- Fotoğraflar ----------------
    public static File fotoKlasoru() {
        File d = new File(klasor(), "Fotograflar");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static File foto(String ad) { return new File(fotoKlasoru(), ad); }

    public static byte[] baytOku(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally { in.close(); }
    }

    public static void baytYaz(File f, byte[] b) throws IOException {
        OutputStream o = new FileOutputStream(f);
        try { o.write(b); } finally { o.close(); }
    }

    /** Yeni, çakışmayan bir fotoğraf dosya adı üretir. */
    public static String yeniFotoAdi() {
        return "F" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + "_" + Integer.toHexString((int) (Math.random() * 0xFFFFF)) + ".jpg";
    }

    // ---------------- İşyerleri ----------------
    public static File isyeriDosyasi() { return new File(klasor(), "isyerleri.json"); }

    static List<Isyeri> isyeriListesi(String t) {
        List<Isyeri> l = new ArrayList<Isyeri>();
        if (t == null) return l;
        try {
            Object o = Json.parse(t);
            if (o instanceof List) for (Object x : (List<?>) o) if (x instanceof Map) l.add(Isyeri.fromMap((Map<?, ?>) x));
        } catch (Exception ignored) {}
        return l;
    }

    /**
     * Kullanıcının işyeri listesini yükler ve programla gelen listeyle birleştirir:
     * yeni işyerleri eklenir; kullanıcının kaydında ekip/adres yoksa programdaki bilgi aktarılır.
     * Kullanıcının kendi girdiği bilgiler hiçbir zaman ezilmez.
     */
    public static List<Isyeri> isyerleriYukle() {
        File f = isyeriDosyasi();
        List<Isyeri> l = null;
        try { if (f.exists()) l = isyeriListesi(oku(f)); } catch (Exception ignored) {}
        List<Isyeri> paket = isyeriListesi(kaynak("isyerleri.json", isyeriMetni));
        if (l == null || l.isEmpty()) return paket;
        boolean degisti = false;
        for (Isyeri p : paket) {
            Isyeri u = Isyeri.bul(l, p.ad);
            if (u == null) { l.add(p); degisti = true; continue; }
            if (!u.ekipVar() && p.ekipVar()) {
                u.ekip.clear();
                for (String[] e : p.ekip) u.ekip.add(new String[]{e[0], e[1]});
                if (u.ekipYazisi.isEmpty()) u.ekipYazisi = p.ekipYazisi;
                degisti = true;
            }
            if (u.adres.isEmpty() && !p.adres.isEmpty()) { u.adres = p.adres; degisti = true; }
            if (u.telefon.isEmpty() && !p.telefon.isEmpty()) { u.telefon = p.telefon; degisti = true; }
            if (u.eposta.isEmpty() && !p.eposta.isEmpty()) { u.eposta = p.eposta; degisti = true; }
            if (u.detsis.isEmpty() && !p.detsis.isEmpty()) { u.detsis = p.detsis; degisti = true; }
        }
        if (degisti) {
            isyeriSirala(l);
            try { isyerleriKaydet(l); } catch (IOException ignored) {}
        }
        return l;
    }

    public static void isyerleriKaydet(List<Isyeri> l) throws IOException {
        List<Object> o = new ArrayList<Object>();
        for (Isyeri i : l) o.add(i.toMap());
        yaz(isyeriDosyasi(), Json.write(o));
    }

    /** Türkçe alfabetik sıralama. */
    public static void isyeriSirala(List<Isyeri> l) {
        final java.text.Collator c = java.text.Collator.getInstance(new Locale("tr"));
        Collections.sort(l, new Comparator<Isyeri>() { public int compare(Isyeri a, Isyeri b) { return c.compare(a.ad, b.ad); } });
    }

    public static void arsivKaydet(List<Kayit> l) throws IOException {
        List<Object> o = new ArrayList<Object>();
        for (Kayit k : l) o.add(arsivMap(k));
        yaz(arsivDosyasi(), Json.write(o));
    }

    /** Arşivde rapora özgü alanlar tutulmaz. */
    static Map<String, Object> arsivMap(Kayit k) {
        Kayit c = k.kopya();
        c.mevcutDurum = ""; c.termin = ""; c.sorumlu = ""; c.s2 = null; c.o2 = null; c.f2 = null; c.lo2 = null; c.ls2 = null;
        dofTemizle(c);
        return c.toMap();
    }

    public static List<Kayit> listeOku(String json) {
        Object o = Json.parse(json);
        List<Kayit> l = new ArrayList<Kayit>();
        if (o instanceof Map && ((Map<?, ?>) o).get("riskler") instanceof List) o = ((Map<?, ?>) o).get("riskler");
        if (o instanceof Map && ((Map<?, ?>) o).get("kalemler") instanceof List) o = ((Map<?, ?>) o).get("kalemler");
        if (!(o instanceof List)) throw new RuntimeException("Dosyada risk listesi bulunamadı.");
        for (Object x : (List<?>) o) if (x instanceof Map) l.add(Kayit.fromMap((Map<?, ?>) x));
        return l;
    }

    public static String yeniId(List<Kayit> arsiv) {
        int max = 0;
        for (Kayit k : arsiv) {
            if (k.id != null && k.id.length() > 1) {
                try { max = Math.max(max, Integer.parseInt(k.id.replaceAll("[^0-9]", ""))); } catch (Exception ignored) {}
            }
        }
        return String.format("R%04d", max + 1);
    }

    // ---------------- CSV (Excel'den) ----------------
    public static final String[] CSV_BASLIK = {"Kategori", "Faaliyet", "Etkilenen", "Tehlike", "Risk",
            "Siddet", "Olasilik", "Frekans", "Onlem", "Mevzuat", "Kaynak"};

    public static List<Kayit> csvOku(String text) {
        List<List<String>> satirlar = csvAyristir(text);
        List<Kayit> l = new ArrayList<Kayit>();
        if (satirlar.isEmpty()) return l;
        // Başlık satırından sütun eşleme
        List<String> bas = satirlar.get(0);
        Map<String, Integer> idx = new HashMap<String, Integer>();
        for (int i = 0; i < bas.size(); i++) idx.put(Kayit.norm(trAscii(bas.get(i))), i);
        boolean basliksiz = !idx.containsKey("tehlike");
        int start = basliksiz ? 0 : 1;
        for (int r = start; r < satirlar.size(); r++) {
            List<String> s = satirlar.get(r);
            if (s.size() < 3) continue;
            Kayit k = new Kayit();
            k.kategori = hucre(s, idx, "kategori", 0, basliksiz);
            k.faaliyet = hucre(s, idx, "faaliyet", 1, basliksiz);
            String et = hucre(s, idx, "etkilenen", 2, basliksiz);
            if (!et.isEmpty()) k.etkilenen = et;
            k.tehlike = hucre(s, idx, "tehlike", 3, basliksiz);
            k.risk = hucre(s, idx, "risk", 4, basliksiz);
            k.s = sayi(hucre(s, idx, "siddet", 5, basliksiz), 15);
            k.o = sayi(hucre(s, idx, "olasilik", 6, basliksiz), 3);
            k.f = sayi(hucre(s, idx, "frekans", 7, basliksiz), 3);
            k.onlem = hucre(s, idx, "onlem", 8, basliksiz);
            k.mevzuat = hucre(s, idx, "mevzuat", 9, basliksiz);
            k.kaynak = hucre(s, idx, "kaynak", 10, basliksiz);
            if (k.tehlike.isEmpty() && k.faaliyet.isEmpty()) continue;
            l.add(k);
        }
        return l;
    }

    static String trAscii(String x) {
        return x.replace('Ş', 'S').replace('ş', 's').replace('İ', 'I').replace('ı', 'i').replace('Ö', 'O').replace('ö', 'o')
                .replace('Ü', 'U').replace('ü', 'u').replace('Ç', 'C').replace('ç', 'c').replace('Ğ', 'G').replace('ğ', 'g');
    }

    static String hucre(List<String> s, Map<String, Integer> idx, String ad, int vars, boolean basliksiz) {
        Integer i = basliksiz ? Integer.valueOf(vars) : idx.get(ad);
        if (i == null || i >= s.size()) return "";
        return s.get(i).trim();
    }

    static double sayi(String t, double d) {
        try { return Double.parseDouble(t.trim().replace(',', '.')); } catch (Exception e) { return d; }
    }

    static List<List<String>> csvAyristir(String text) {
        char ayr = ';';
        String ilk = text.split("\n", 2)[0];
        if (count(ilk, '\t') > count(ilk, ';')) ayr = '\t';
        else if (count(ilk, ',') > count(ilk, ';')) ayr = ',';
        List<List<String>> out = new ArrayList<List<String>>();
        List<String> satir = new ArrayList<String>();
        StringBuilder h = new StringBuilder();
        boolean tirnak = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (tirnak) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') { h.append('"'); i++; }
                    else tirnak = false;
                } else h.append(c);
            } else if (c == '"') tirnak = true;
            else if (c == ayr) { satir.add(h.toString()); h.setLength(0); }
            else if (c == '\n') { satir.add(h.toString()); h.setLength(0); out.add(satir); satir = new ArrayList<String>(); }
            else if (c != '\r') h.append(c);
        }
        if (h.length() > 0 || !satir.isEmpty()) { satir.add(h.toString()); out.add(satir); }
        return out;
    }

    static int count(String s, char c) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) n++;
        return n;
    }

    public static String csvSablon() {
        StringBuilder b = new StringBuilder("﻿");
        for (int i = 0; i < CSV_BASLIK.length; i++) { if (i > 0) b.append(';'); b.append(CSV_BASLIK[i]); }
        b.append("\r\nElektrik;Elektrik Panosu;Çalışanlar, 3. Şahıslar, İşyeri;Pano kapağının açık olması;Elektrik çarpması;40;6;2;")
                .append("Pano kapakları kilitli tutulmalıdır.;Elektrik İç Tesisleri Yönetmeliği;Örnek Birim RD (2026)\r\n");
        return b.toString();
    }

    public static String bugun() {
        return new SimpleDateFormat("dd.MM.yyyy").format(new Date());
    }
}
