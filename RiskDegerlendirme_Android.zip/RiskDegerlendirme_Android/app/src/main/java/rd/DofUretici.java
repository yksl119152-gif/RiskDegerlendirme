package rd;

import java.util.*;

/**
 * Fotoğraflı Düzeltici-Önleyici Faaliyet (DÖF) formu.
 * html(): tarayıcı / Android WebView için (fotoğraflar data URI olarak gömülü) – yazdırılıp PDF'e kaydedilir.
 * Word çıktısı için bkz. DocxDof (gerçek .docx, fotoğraflar gömülü).
 */
public final class DofUretici {
    private DofUretici() {}

    public static final String[] TURLER = {"Düzeltici", "Önleyici"};
    public static final String[] KAYNAKLAR = {"Risk değerlendirmesi", "Saha denetimi / gözetim", "İş kazası / ramak kala", "Çalışan bildirimi", "Diğer"};
    public static final String[] DURUMLAR = {"Açık", "Etkin – DÖF kapatıldı", "Etkin değil – yeni DÖF açıldı"};

    static String e(String t) { return RaporUretici.e(t); }

    static String kutu(boolean sec) { return sec ? "&#9746;" : "&#9744;"; }

    /** Fotoğraf kaynağı: word=true ise MHTML içi konum, değilse data URI. */
    static String src(String ad, boolean word) {
        if (word) return "file:///C:/dof_dosyalari/" + ad;
        try {
            return "data:image/jpeg;base64," + B64.kodla(Depo.baytOku(Depo.foto(ad)));
        } catch (Exception ex) {
            return "";
        }
    }

    static String hucre(String ad, boolean word, int no) {
        if (ad == null) return "<td class='fh'></td>";
        int[] wh = boyut(ad);
        return "<td class='fh'><img src='" + src(ad, word) + "' width='" + wh[0] + "' height='" + wh[1] + "' style='width:" + wh[0] + "px;height:"
                + wh[1] + "px'><br><span class='fno'>Fotoğraf " + no + "</span></td>";
    }

    static List<String> mevcut(List<String> l) {
        List<String> m = new ArrayList<String>();
        for (String ad : l) if (Depo.foto(ad).exists()) m.add(ad);
        return m;
    }

    static String karsilastir(Kayit k, boolean word) {
        List<String> a = mevcut(k.fotoOnce), b = mevcut(k.fotoSonra);
        StringBuilder h = new StringBuilder("<table style='margin-top:4pt'><thead><tr><td colspan='2' class='bol'>EK – FOTOĞRAFLAR</td></tr>")
                .append("<tr><th style='width:50%;background:#fbe4e4'>Tespit (önce)</th><th style='width:50%;background:#e3f3e6'>Uygulama sonrası (sonra)</th></tr></thead><tbody>");
        int n = Math.max(1, Math.max(a.size(), b.size()));
        for (int i = 0; i < n; i++) {
            h.append("<tr>");
            if (i < a.size()) h.append(hucre(a.get(i), word, i + 1));
            else h.append(i == 0 ? "<td class='fh'><div class='bosfoto'>Tespit fotoğrafı eklenmedi</div></td>" : "<td class='fh'></td>");
            if (i < b.size()) h.append(hucre(b.get(i), word, i + 1));
            else h.append(i == 0 ? "<td class='fh'><div class='bosfoto'>Uygulama sonrası fotoğraf eklenmedi</div></td>" : "<td class='fh'></td>");
            h.append("</tr>");
        }
        return h.append("</tbody></table>").toString();
    }

    static String fotolar(List<String> l, boolean word, String bos) {
        if (l.isEmpty()) return "<div class='bosfoto'>" + e(bos) + "</div>";
        StringBuilder h = new StringBuilder("<table class='foto'><tr>");
        int n = 0;
        for (String ad : l) {
            if (!Depo.foto(ad).exists()) continue;
            if (n > 0 && n % 2 == 0) h.append("</tr><tr>");
            int[] wh = boyut(ad);
            h.append("<td><img src='").append(src(ad, word)).append("' width='").append(wh[0]).append("' height='").append(wh[1])
             .append("' style='width:").append(wh[0]).append("px;height:").append(wh[1]).append("px'><br>")
             .append("<span class='fno'>Fotoğraf ").append(++n).append("</span></td>");
        }
        if (n % 2 == 1) h.append("<td></td>");
        h.append("</tr></table>");
        return n == 0 ? "<div class='bosfoto'>" + e(bos) + "</div>" : h.toString();
    }

    /** Fotoğrafı 7 cm × 4,6 cm kutuya sığdıran piksel ölçüsü (96 dpi). */
    static int[] boyut(String ad) {
        int mw = 220, mh = 132;
        int[] d = null;
        try { d = jpegBoyut(Depo.baytOku(Depo.foto(ad))); } catch (Exception ignored) {}
        if (d == null || d[0] <= 0 || d[1] <= 0) return new int[]{mw, mh};
        double o = Math.min(mw / (double) d[0], mh / (double) d[1]);
        return new int[]{(int) Math.round(d[0] * o), (int) Math.round(d[1] * o)};
    }

    /** JPEG başlığından genişlik/yükseklik (SOF işaretçisi). */
    static int[] jpegBoyut(byte[] b) {
        int i = 2;
        while (i + 9 < b.length) {
            if ((b[i] & 0xff) != 0xFF) { i++; continue; }
            int m = b[i + 1] & 0xff;
            if (m >= 0xC0 && m <= 0xCF && m != 0xC4 && m != 0xC8 && m != 0xCC)
                return new int[]{(b[i + 7] & 0xff) << 8 | (b[i + 8] & 0xff), (b[i + 5] & 0xff) << 8 | (b[i + 6] & 0xff)};
            int uz = (b[i + 2] & 0xff) << 8 | (b[i + 3] & 0xff);
            i += 2 + uz;
        }
        return null;
    }

    static String yaz(String t, int satir) {
        if (t != null && !t.trim().isEmpty()) return e(t);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < satir; i++) b.append("<br>");
        return b.toString();
    }

    public static String html(Rapor r, List<Kayit> liste, boolean word) {
        String y = r.yontem();
        boolean L = Yontem.lm(y);
        String kurum = r.b("kurum").isEmpty() ? "DÜZCE ÜNİVERSİTESİ" : r.b("kurum");
        StringBuilder h = new StringBuilder();
        h.append("<html");
        if (word) h.append(" xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'");
        h.append("><head><meta charset='utf-8'><title>DÖF Formu</title>");
        if (word) h.append("<!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom></w:WordDocument></xml><![endif]-->");
        h.append("<style>")
         .append("@page{size:A4;margin:1.2cm 1.3cm 1.2cm 1.3cm;} @page WordSection1{size:595.3pt 841.9pt;margin:34pt 37pt 34pt 37pt;} div.WordSection1{page:WordSection1;}")
         .append("body{font-family:Calibri,'Segoe UI',Arial,sans-serif;font-size:9.5pt;color:#111;}")
         .append("table{border-collapse:collapse;width:100%;} td,th{border:0.75pt solid #444;padding:2pt 4pt;vertical-align:top;}")
         .append("table.ust td{vertical-align:middle;} .kurum{font-weight:bold;color:#0b3a6f;font-size:11pt;text-align:center;}")
         .append(".baslik{font-size:14pt;font-weight:bold;color:#0b3a6f;text-align:center;} .k{background:#eef3f9;font-weight:bold;width:24%;}")
         .append(".bol{background:#0b3a6f;color:#fff;font-weight:bold;font-size:9.5pt;padding:2pt 6pt;}")
         .append("table.foto td{border:none;text-align:center;width:50%;padding:2pt;} .fno{font-size:7.5pt;color:#555;}")
         .append("td.fh{text-align:center;vertical-align:middle;padding:2pt;} thead{display:table-header-group;} tr{page-break-inside:avoid;}")
         .append(".bosfoto{border:0.75pt dashed #999;color:#888;text-align:center;padding:18pt 4pt;font-size:9pt;}")
         .append("table.imza td{text-align:center;height:40pt;width:33%;} table.imza th{background:#eef3f9;font-size:9pt;}")
         .append(".sev{font-weight:bold;padding:1pt 6pt;} .form{page-break-after:always;} .form.son{page-break-after:auto;}")
         .append("@media screen{body{background:#e9edf2;} .form{background:#fff;max-width:800px;margin:16px auto;padding:22px;box-shadow:0 1px 6px rgba(0,0,0,.2);}}")
         .append("</style></head><body><div class='WordSection1'>");

        int i = 0;
        for (Kayit k : liste) {
            i++;
            String sev = Yontem.seviye(k, y);
            Double p2 = Yontem.puan2(k, y);
            String sev2 = p2 == null ? null : Yontem.seviye(y, p2);
            String no = k.dofNo.isEmpty() ? r.dofNoOner(k) : k.dofNo;
            String puan = L ? "O " + Kinney.fmt(Yontem.lo(k)) + " × Ş " + Kinney.fmt(Yontem.ls(k)) + " = " + Kinney.fmt(Yontem.puan(k, y))
                            : "Ş " + Kinney.fmt(k.s) + " × O " + Kinney.fmt(k.o) + " × F " + Kinney.fmt(k.f) + " = " + Kinney.fmt(k.puan());
            String puan2 = p2 == null ? "" : (L ? "O " + Kinney.fmt(Yontem.lo2(k)) + " × Ş " + Kinney.fmt(Yontem.ls2(k)) + " = " + Kinney.fmt(p2)
                                                : "Ş " + Kinney.fmt(k.s2) + " × O " + Kinney.fmt(k.o2) + " × F " + Kinney.fmt(k.f2) + " = " + Kinney.fmt(p2));
            String tespitEden = r.b("uzmanAd").isEmpty() ? r.ekipKisi("güvenliği uzmanı") : r.b("uzmanAd");
            String amir = r.ekipKisi("işveren");

            if (i > 1 && word) h.append("<br clear=all style='page-break-before:always'>");
            h.append("<div class='form").append(i == liste.size() ? " son" : "").append("'>");
            // Başlık
            h.append("<table class='ust'><tr><td style='width:26%' class='kurum'>T.C.<br>").append(e(kurum))
             .append("<br><span style='font-weight:normal;font-size:8.5pt'>İş Sağlığı ve Güvenliği Koordinatörlüğü</span></td>")
             .append("<td class='baslik'>DÜZELTİCİ – ÖNLEYİCİ FAALİYET<br>(DÖF) FORMU</td>")
             .append("<td style='width:26%;font-size:8.5pt'><b>DÖF No:</b> ").append(e(no)).append("<br><b>Form tarihi:</b> ")
             .append(e(r.b("tarih"))).append("<br><b>Form:</b> ").append(i).append(" / ").append(liste.size()).append("</td></tr></table>");

            // 1. Genel bilgiler
            h.append("<table style='margin-top:4pt'><tr><td colspan='4' class='bol'>1. GENEL BİLGİLER</td></tr>")
             .append("<tr><td class='k'>Birim</td><td colspan='3'>").append(e(r.b("birim"))).append("</td></tr>")
             .append("<tr><td class='k'>Tespit tarihi</td><td>").append(e(k.tespitTarihi.isEmpty() ? r.b("tarih") : k.tespitTarihi))
             .append("</td><td class='k'>Tespit eden</td><td>").append(e(tespitEden)).append("</td></tr>")
             .append("<tr><td class='k'>Faaliyet türü</td><td colspan='3'>");
            for (String t : TURLER) h.append(kutu(t.equals(k.dofTuru))).append(" ").append(t).append(" &nbsp;&nbsp; ");
            h.append("</td></tr><tr><td class='k'>DÖF kaynağı</td><td colspan='3'>");
            for (String t : KAYNAKLAR) h.append(kutu(t.equals(k.dofKaynak))).append(" ").append(e(t)).append(" &nbsp; ");
            h.append("</td></tr></table>");

            // 2. Uygunsuzluk
            h.append("<table style='margin-top:4pt'><tr><td colspan='4' class='bol'>2. UYGUNSUZLUĞUN / TEHLİKENİN TANIMI</td></tr>")
             .append("<tr><td class='k'>Faaliyet / bölüm</td><td colspan='3'>").append(e(k.faaliyet)).append("</td></tr>")
             .append("<tr><td class='k'>Tehlike</td><td colspan='3'>").append(e(k.tehlike)).append("</td></tr>")
             .append("<tr><td class='k'>Risk / olası etkiler</td><td colspan='3'>").append(e(k.risk)).append("</td></tr>")
             .append("<tr><td class='k'>Mevcut durum</td><td colspan='3'>").append(yaz(k.mevcutDurum, 1)).append("</td></tr>")
             .append("<tr><td class='k'>Risk puanı (").append(e(y)).append(")</td><td>").append(e(puan)).append("</td><td class='k'>Risk seviyesi</td>")
             .append("<td><span class='sev' style='background:").append(Yontem.hex(y, sev)).append("'>").append(sev).append("</span></td></tr></table>");

            // 3. Kök neden ve planlanan faaliyet
            h.append("<table style='margin-top:4pt'><tr><td colspan='4' class='bol'>3. KÖK NEDEN VE PLANLANAN FAALİYET</td></tr>")
             .append("<tr><td class='k'>Kök neden</td><td colspan='3'>").append(yaz(k.kokNeden, 2)).append("</td></tr>")
             .append("<tr><td class='k'>Düzeltici – önleyici faaliyet</td><td colspan='3'>").append(yaz(k.onlem, 2)).append("</td></tr>")
             .append("<tr><td class='k'>Sorumlu</td><td>").append(yaz(k.sorumlu, 1)).append("</td><td class='k'>Termin</td><td>")
             .append(yaz(k.termin.isEmpty() ? Yontem.termin(y, sev) : k.termin, 1)).append("</td></tr>")
             .append("<tr><td class='k'>İlgili mevzuat</td><td colspan='3'>").append(yaz(k.mevzuat, 1)).append("</td></tr></table>");

            // 4. Uygulama ve doğrulama
            h.append("<table style='margin-top:4pt'><tr><td colspan='4' class='bol'>4. UYGULAMA VE ETKİNLİK KONTROLÜ</td></tr>")
             .append("<tr><td class='k'>Yapılan faaliyet</td><td colspan='3'>").append(yaz(k.dofYapilan, 2)).append("</td></tr>")
             .append("<tr><td class='k'>Tamamlanma tarihi</td><td>").append(yaz(k.dofTamamlanma, 1)).append("</td><td class='k'>Kalıntı risk</td><td>");
            if (p2 == null) h.append("<br>");
            else h.append(e(puan2)).append(" <span class='sev' style='background:").append(Yontem.hex(y, sev2)).append("'>").append(sev2).append("</span>");
            h.append("</td></tr><tr><td class='k'>Etkinlik sonucu</td><td colspan='3'>")
             .append(kutu(DURUMLAR[1].equals(k.dofDurum))).append(" Etkin – DÖF kapatıldı &nbsp;&nbsp; ")
             .append(kutu(DURUMLAR[2].equals(k.dofDurum))).append(" Etkin değil – yeni DÖF açıldı")
             .append(k.dofYeniNo.isEmpty() ? " (No: ..................)" : " (No: " + e(k.dofYeniNo) + ")")
             .append("<br><b>Kontrol tarihi:</b> ").append(k.dofKontrolTarihi.isEmpty() ? "....../....../.........." : e(k.dofKontrolTarihi)).append("</td></tr></table>");

            // 5. İmzalar
            h.append("<table class='imza' style='margin-top:4pt'><tr><th>Tespit Eden<br>(İş Güvenliği Uzmanı)</th><th>Faaliyetten Sorumlu</th><th>Onaylayan<br>(İşveren Vekili)</th></tr>")
             .append("<tr><td>").append(e(tespitEden)).append("<br><br><span style='color:#888'>İmza</span></td><td>").append(e(k.sorumlu))
             .append("<br><br><span style='color:#888'>İmza</span></td><td>").append(e(amir)).append("<br><br><span style='color:#888'>İmza</span></td></tr></table>");
            // Ek: Fotoğraflar (önce / sonra yan yana)
            h.append(karsilastir(k, word));

            h.append("</div>");
        }
        h.append("</div></body></html>");
        return h.toString();
    }
}
