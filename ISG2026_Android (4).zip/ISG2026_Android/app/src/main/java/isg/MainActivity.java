package isg;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import android.content.SharedPreferences;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * İSG 2026 tablet sürümü: programın sayfalarını uygulamanın içinden (assets/web) açar.
 * Kayıtlar tablette kalıcı olarak saklanır; Word/Excel çıktıları İndirilenler/İSG 2026 klasörüne kaydedilir.
 */
public class MainActivity extends Activity {
    static final String HOST = "isg2026.yerel";
    static final String BASE = "https://" + HOST + "/";
    static final int DOSYA_SEC = 7;

    WebView w;
    ValueCallback<Uri[]> dosyaCb;
    Uri kameraUri;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        w.addJavascriptInterface(new Kopru(), "AndroidKopru");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String yol = u.getPath() == null ? "/" : u.getPath();
                if (yol.equals("/") || yol.isEmpty()) yol = "/index.html";
                Map<String, String> h = new HashMap<>();
                h.put("Cache-Control", "no-cache");
                if (yol.startsWith("/api/") || yol.contains("..")) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
                }
                try {
                    InputStream in = getAssets().open("web" + yol);
                    String mime = mime(yol);
                    return new WebResourceResponse(mime, mime.startsWith("text/") || mime.contains("javascript") ? "UTF-8" : null, 200, "OK", h, in);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (dosyaCb != null) dosyaCb.onReceiveValue(null);
                dosyaCb = cb;
                kameraUri = null;
                String[] kabul = p.getAcceptTypes();
                List<String> mimeler = new ArrayList<>();
                boolean resim = false, hepsiMime = true;
                if (kabul != null) for (String a : kabul) {
                    for (String t : a.split(",")) {
                        t = t.trim();
                        if (t.isEmpty()) continue;
                        if (t.startsWith("image")) resim = true;
                        if (t.contains("/")) mimeler.add(t); else hepsiMime = false;
                    }
                }
                Intent sec = new Intent(Intent.ACTION_GET_CONTENT);
                sec.addCategory(Intent.CATEGORY_OPENABLE);
                sec.setType("*/*");
                if (hepsiMime && !mimeler.isEmpty()) sec.putExtra(Intent.EXTRA_MIME_TYPES, mimeler.toArray(new String[0]));
                if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) sec.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                Intent secici = Intent.createChooser(sec, "Dosya seçin");
                if (resim && Build.VERSION.SDK_INT >= 29) {
                    try {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "ISG_" + System.currentTimeMillis() + ".jpg");
                        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/İSG 2026");
                        kameraUri = getContentResolver().insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), cv);
                        if (kameraUri != null) {
                            Intent kam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            kam.putExtra(MediaStore.EXTRA_OUTPUT, kameraUri);
                            kam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            secici.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{kam});
                        }
                    } catch (Exception ignored) { kameraUri = null; }
                }
                try {
                    startActivityForResult(secici, DOSYA_SEC);
                } catch (ActivityNotFoundException e) {
                    dosyaCb.onReceiveValue(null);
                    dosyaCb = null;
                    return false;
                }
                return true;
            }
        });
        if (b != null) w.restoreState(b);
        else w.loadUrl(BASE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != DOSYA_SEC || dosyaCb == null) return;
        Uri[] sonuc = null;
        if (res == RESULT_OK) {
            List<Uri> l = new ArrayList<>();
            if (data != null) {
                if (data.getClipData() != null) {
                    for (int i = 0; i < data.getClipData().getItemCount(); i++) l.add(data.getClipData().getItemAt(i).getUri());
                } else if (data.getData() != null) l.add(data.getData());
            }
            if (l.isEmpty() && kameraUri != null) l.add(kameraUri);
            else if (kameraUri != null) bosKameraSil();
            if (!l.isEmpty()) sonuc = l.toArray(new Uri[0]);
        } else if (kameraUri != null) bosKameraSil();
        dosyaCb.onReceiveValue(sonuc);
        dosyaCb = null;
        kameraUri = null;
    }

    void bosKameraSil() {
        try { getContentResolver().delete(kameraUri, null, null); } catch (Exception ignored) { }
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        w.saveState(o);
    }

    @Override
    public void onBackPressed() {
        if (w.canGoBack()) w.goBack();
        else super.onBackPressed();
    }

    static String mime(String yol) {
        String a = yol.toLowerCase();
        if (a.endsWith(".html")) return "text/html";
        if (a.endsWith(".js")) return "application/javascript";
        if (a.endsWith(".css")) return "text/css";
        if (a.endsWith(".json")) return "application/json";
        if (a.endsWith(".pdf")) return "application/pdf";
        if (a.endsWith(".png")) return "image/png";
        if (a.endsWith(".jpg") || a.endsWith(".jpeg")) return "image/jpeg";
        if (a.endsWith(".svg")) return "image/svg+xml";
        if (a.endsWith(".webp")) return "image/webp";
        String uz = MimeTypeMap.getFileExtensionFromUrl(yol);
        String m = uz == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(uz);
        return m == null ? "application/octet-stream" : m;
    }

    /* ---------------- Yandex Disk (REST API) ---------------- */
    static final String YD_API = "https://cloud-api.yandex.net/v1/disk";
    static final String YD_KLASOR = "disk:/İSG 2026";
    static final String YD_DOSYA = YD_KLASOR + "/veri.json";

    SharedPreferences ayar() { return getSharedPreferences("isg2026", MODE_PRIVATE); }
    String ydToken() { return ayar().getString("ydToken", ""); }

    static byte[] hepsi(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] t = new byte[65536]; int n;
        while ((n = in.read(t)) > 0) bo.write(t, 0, n);
        in.close();
        return bo.toByteArray();
    }

    /** [kod, gövde] */
    Object[] http(String yontem, String adres, byte[] govde, boolean yetki) throws IOException {
        Map<String, String> h = new HashMap<>();
        if (yetki) h.put("Authorization", "OAuth " + ydToken());
        return istek(yontem, adres, govde, h);
    }
    static Object[] istek(String yontem, String adres, byte[] govde, Map<String, String> basliklar) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(adres).openConnection();
        c.setRequestMethod(yontem);
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        for (Map.Entry<String, String> e : basliklar.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
        if (govde != null) {
            c.setDoOutput(true);
            c.setFixedLengthStreamingMode(govde.length);
            OutputStream o = c.getOutputStream(); o.write(govde); o.close();
        }
        int kod = c.getResponseCode();
        InputStream in = kod >= 400 ? c.getErrorStream() : c.getInputStream();
        String metin = in == null ? "" : new String(hepsi(in), "UTF-8");
        c.disconnect();
        return new Object[]{kod, metin};
    }
    static long isoZaman(String s) {
        if (s == null || s.length() < 19) return 0;
        try { SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US); f.setTimeZone(TimeZone.getTimeZone("UTC")); return f.parse(s.substring(0, 19)).getTime(); }
        catch (Exception e) { return 0; }
    }
    /** bulut dosya bilgisini ortak biçime çevirir: {"sig":..., "zaman":...} */
    static Object[] normal(Object[] r, String sigAlani, String sigAlani2, String zamanAlani) {
        if ((Integer) r[0] >= 300) return r;
        try {
            JSONObject j = new JSONObject((String) r[1]), o = new JSONObject();
            String sig = j.optString(sigAlani, "");
            if (sig.isEmpty() && sigAlani2 != null) sig = j.optString(sigAlani2, "");
            o.put("sig", sig);
            o.put("zaman", isoZaman(j.optString(zamanAlani, "")));
            return new Object[]{200, o.toString()};
        } catch (Exception e) { return new Object[]{200, "{}"}; }
    }

    static String yolParam(String yol) throws IOException { return URLEncoder.encode(yol, "UTF-8").replace("+", "%20"); }

    Object[] ydIslem(String islem, String govde) throws Exception {
        if (ydToken().isEmpty()) return new Object[]{401, "Yandex Disk bağlı değil"};
        if (islem.equals("disk")) return http("GET", YD_API + "?fields=user,total_space,used_space", null, true);
        if (islem.equals("bilgi")) return normal(http("GET", YD_API + "/resources?path=" + yolParam(YD_DOSYA) + "&fields=modified,md5,size", null, true), "md5", null, "modified");
        if (islem.equals("oku")) {
            Object[] r = http("GET", YD_API + "/resources/download?path=" + yolParam(YD_DOSYA), null, true);
            if ((Integer) r[0] != 200) return r;
            String href = new JSONObject((String) r[1]).getString("href");
            return http("GET", href, null, false);
        }
        if (islem.equals("yaz")) {
            http("PUT", YD_API + "/resources?path=" + yolParam(YD_KLASOR), new byte[0], true); // klasör varsa 409 döner, sorun değil
            Object[] r = http("GET", YD_API + "/resources/upload?path=" + yolParam(YD_DOSYA) + "&overwrite=true", null, true);
            if ((Integer) r[0] != 200) return r;
            String href = new JSONObject((String) r[1]).getString("href");
            Object[] y = http("PUT", href, govde.getBytes("UTF-8"), false);
            int k = (Integer) y[0];
            if (k != 201 && k != 202 && k != 200) return y;
            return normal(http("GET", YD_API + "/resources?path=" + yolParam(YD_DOSYA) + "&fields=modified,md5,size", null, true), "md5", null, "modified");
        }
        return new Object[]{400, "bilinmeyen işlem"};
    }

    /* ---------------- OneDrive (Microsoft Graph, cihaz kodu ile giriş) ---------------- */
    static final String GRAPH = "https://graph.microsoft.com/v1.0";
    static final String OD_KAPSAM = "Files.ReadWrite offline_access";

    static String form(String... kv) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i + 1 < kv.length; i += 2) { if (sb.length() > 0) sb.append('&'); sb.append(kv[i]).append('=').append(URLEncoder.encode(kv[i + 1], "UTF-8")); }
        return sb.toString();
    }
    Object[] tokenIstek(String govde) throws IOException {
        Map<String, String> h = new HashMap<>();
        h.put("Content-Type", "application/x-www-form-urlencoded");
        return istek("POST", "https://login.microsoftonline.com/" + ayar().getString("odTenant", "consumers") + "/oauth2/v2.0/token", govde.getBytes("UTF-8"), h);
    }
    void tokenSakla(String json) throws Exception {
        JSONObject j = new JSONObject(json);
        SharedPreferences.Editor e = ayar().edit();
        e.putString("odAccess", j.getString("access_token"));
        if (j.has("refresh_token")) e.putString("odRefresh", j.getString("refresh_token"));
        e.putLong("odExp", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L);
        e.apply();
    }
    synchronized String odErisim() throws Exception {
        SharedPreferences a = ayar();
        if (a.getString("odRefresh", "").isEmpty()) return null;
        if (System.currentTimeMillis() < a.getLong("odExp", 0) - 120000) return a.getString("odAccess", "");
        Object[] r = tokenIstek(form("grant_type", "refresh_token", "client_id", a.getString("odClient", ""), "refresh_token", a.getString("odRefresh", ""), "scope", OD_KAPSAM));
        if ((Integer) r[0] != 200) return null;
        tokenSakla((String) r[1]);
        return ayar().getString("odAccess", "");
    }
    static String odYol() throws IOException {
        return GRAPH + "/me/drive/root:/" + URLEncoder.encode("İSG 2026", "UTF-8").replace("+", "%20") + "/veri.json";
    }
    Object[] odIslem(String islem, String govde) throws Exception {
        String t = odErisim();
        if (t == null) return new Object[]{401, "OneDrive bağlı değil ya da oturum süresi doldu"};
        Map<String, String> h = new HashMap<>();
        h.put("Authorization", "Bearer " + t);
        if (islem.equals("disk")) return istek("GET", GRAPH + "/me/drive?$select=owner,quota", null, h);
        if (islem.equals("bilgi")) return normal(istek("GET", odYol() + "?$select=cTag,eTag,lastModifiedDateTime,size", null, h), "cTag", "eTag", "lastModifiedDateTime");
        if (islem.equals("oku")) return istek("GET", odYol() + ":/content", null, h);
        if (islem.equals("yaz")) {
            byte[] b = govde.getBytes("UTF-8");
            Object[] r;
            h.put("Content-Type", "application/json");
            if (b.length < 3500000) {
                r = istek("PUT", odYol() + ":/content", b, h);
            } else {
                Object[] s = istek("POST", odYol() + ":/createUploadSession", "{\"item\":{\"@microsoft.graph.conflictBehavior\":\"replace\"}}".getBytes("UTF-8"), h);
                if ((Integer) s[0] != 200) return s;
                String up = new JSONObject((String) s[1]).getString("uploadUrl");
                Map<String, String> h2 = new HashMap<>();
                h2.put("Content-Range", "bytes 0-" + (b.length - 1) + "/" + b.length);
                r = istek("PUT", up, b, h2);
            }
            int k = (Integer) r[0];
            if (k != 200 && k != 201) return r;
            return normal(r, "cTag", "eTag", "lastModifiedDateTime");
        }
        return new Object[]{400, "bilinmeyen işlem"};
    }
    void jsCagir(final String js) { runOnUiThread(new Runnable() { public void run() { w.evaluateJavascript(js, null); } }); }

    /** Sayfalardan çağrılan köprü: window.AndroidKopru.kaydet(dosyaAdı, mime, base64) */
    class Kopru {
        @JavascriptInterface
        public String ydVar() { return ydToken().isEmpty() ? "" : "1"; }

        @JavascriptInterface
        public void ydTokenAyarla(String t) { ayar().edit().putString("ydToken", t == null ? "" : t.trim()).apply(); }

        @JavascriptInterface
        public void ydIstek(final String id, final String islem, final String govde) {
            new Thread(new Runnable() {
                public void run() {
                    int kod; String metin;
                    try { Object[] r = ydIslem(islem, govde); kod = (Integer) r[0]; metin = (String) r[1]; }
                    catch (Exception e) { kod = 0; metin = String.valueOf(e.getMessage()); }
                    final String js = "window.__ydCb&&window.__ydCb(" + JSONObject.quote(id) + "," + kod + "," + JSONObject.quote(metin) + ")";
                    runOnUiThread(new Runnable() { public void run() { w.evaluateJavascript(js, null); } });
                }
            }).start();
        }

        @JavascriptInterface
        public String odVar() { return ayar().getString("odRefresh", "").isEmpty() ? "" : "1"; }

        @JavascriptInterface
        public void odKes() { ayar().edit().remove("odRefresh").remove("odAccess").remove("odExp").apply(); }

        @JavascriptInterface
        public void odIstek(final String id, final String islem, final String govde) {
            new Thread(new Runnable() {
                public void run() {
                    int kod; String metin;
                    try { Object[] r = odIslem(islem, govde); kod = (Integer) r[0]; metin = (String) r[1]; }
                    catch (Exception e) { kod = 0; metin = String.valueOf(e.getMessage()); }
                    jsCagir("window.__ydCb&&window.__ydCb(" + JSONObject.quote(id) + "," + kod + "," + JSONObject.quote(metin) + ")");
                }
            }).start();
        }

        /** Cihaz kodu ile Microsoft girişi: kod hazır olunca window.__odKod(json), sonuçta window.__odSonuc(tamam, mesaj) */
        @JavascriptInterface
        public void odGiris(final String clientId, final String tenant) {
            ayar().edit().putString("odClient", clientId.trim()).putString("odTenant", tenant).apply();
            new Thread(new Runnable() {
                public void run() {
                    try {
                        Map<String, String> h = new HashMap<>();
                        h.put("Content-Type", "application/x-www-form-urlencoded");
                        Object[] r = istek("POST", "https://login.microsoftonline.com/" + tenant + "/oauth2/v2.0/devicecode",
                                form("client_id", clientId.trim(), "scope", OD_KAPSAM).getBytes("UTF-8"), h);
                        if ((Integer) r[0] != 200) {
                            String m = (String) r[1];
                            try { m = new JSONObject(m).optString("error_description", m); } catch (Exception ignored) { }
                            jsCagir("window.__odSonuc&&window.__odSonuc(false," + JSONObject.quote(m) + ")");
                            return;
                        }
                        JSONObject d = new JSONObject((String) r[1]);
                        jsCagir("window.__odKod&&window.__odKod(" + JSONObject.quote(d.toString()) + ")");
                        long bitis = System.currentTimeMillis() + d.optLong("expires_in", 900) * 1000L;
                        long aralik = Math.max(3, d.optLong("interval", 5));
                        while (System.currentTimeMillis() < bitis) {
                            Thread.sleep(aralik * 1000L);
                            Object[] t = tokenIstek(form("grant_type", "urn:ietf:params:oauth:grant-type:device_code", "client_id", clientId.trim(), "device_code", d.getString("device_code")));
                            if ((Integer) t[0] == 200) { tokenSakla((String) t[1]); jsCagir("window.__odSonuc&&window.__odSonuc(true,\"\")"); return; }
                            String hata = "";
                            try { hata = new JSONObject((String) t[1]).optString("error", ""); } catch (Exception ignored) { }
                            if (hata.equals("authorization_pending")) continue;
                            if (hata.equals("slow_down")) { aralik += 5; continue; }
                            String m = (String) t[1];
                            try { m = new JSONObject(m).optString("error_description", hata); } catch (Exception ignored) { }
                            jsCagir("window.__odSonuc&&window.__odSonuc(false," + JSONObject.quote(m) + ")");
                            return;
                        }
                        jsCagir("window.__odSonuc&&window.__odSonuc(false,\"Kodun süresi doldu; yeniden deneyin.\")");
                    } catch (Exception e) {
                        jsCagir("window.__odSonuc&&window.__odSonuc(false," + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void disAc(String adres) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(adres)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public String kaydet(String ad, String mime, String b64) {
            try {
                String temiz = ad.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (mime == null || mime.isEmpty() || mime.equals("application/octet-stream")) mime = mime(temiz);
                byte[] veri = Base64.decode(b64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, temiz);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/İSG 2026");
                    final Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) throw new IOException("dosya oluşturulamadı");
                    OutputStream o = getContentResolver().openOutputStream(uri);
                    if (o == null) throw new IOException("dosya yazılamadı");
                    o.write(veri);
                    o.close();
                    final String m = mime;
                    if (!m.contains("json")) runOnUiThread(new Runnable() {
                        public void run() {
                            Intent ac = new Intent(Intent.ACTION_VIEW);
                            ac.setDataAndType(uri, m);
                            ac.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(Intent.createChooser(ac, "Dosyayı aç")); } catch (Exception ignored) { }
                        }
                    });
                    return "Kaydedildi: İndirilenler / İSG 2026 / " + temiz;
                } else {
                    File d = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "İSG 2026");
                    if (!d.exists()) d.mkdirs();
                    File f = new File(d, temiz);
                    FileOutputStream o = new FileOutputStream(f);
                    o.write(veri);
                    o.close();
                    return "Kaydedildi: " + f.getAbsolutePath();
                }
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    public void run() { Toast.makeText(MainActivity.this, "Kaydedilemedi: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
                });
                return "Kaydedilemedi: " + e.getMessage();
            }
        }
    }
}
