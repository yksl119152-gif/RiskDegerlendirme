# İSG 2026 – Tablet (Android) sürümü

Bilgisayardaki İSG 2026 programının tablet sürümü: İSG Mevzuat, İSG Takip, Risk Değerlendirme,
Saha Kontrol, Kök Neden Analizi, Evrak Deposu ve Puantaj aynı uygulamada.

## APK'yı GitHub'da derleme (RiskDegerlendirme deposu)

1. github.com → **RiskDegerlendirme** deposunu açın.
2. **Add file / Dosya ekle → Upload files / Dosyaları yükle** → bu `ISG2026_Android.zip` dosyasını
   (açmadan, zip olarak) sürükleyin → **Commit changes / Değişiklikleri işle**.
3. Üstteki **Actions / Eylemler** sekmesinde "APK Derle" kendiliğinden başlar (3–5 dakika).
   Derleme her zaman depoya en son yüklenen zip'i kullanır.
4. Yeşil ✓ olunca sağdaki **Releases / Sürümler** bölümünden en üstteki sürümü açın ve
   `Duzce_Risk_Degerlendirme.apk` dosyasını tablete indirip kurun.
   Dosya adı eski kalır ama kurulan uygulamanın adı **İSG 2026**'dır; Risk Değerlendirme uygulamasının
   yerine geçmez, yanına ayrıca kurulur.

Kırmızı ✗ çıkarsa çalışmaya dokunun → "APK oluştur" adımını açın → hata metnini Claude'a gönderin.

## Kayıtlar ve bilgisayarla aktarım

- Kayıtlar tablette saklanır. Word/Excel çıktıları **İndirilenler / İSG 2026** klasörüne kaydedilir.
- Bilgisayara aktarmak için üst şeritteki **Yedek al** → oluşan dosyayı Yandex Disk uygulamasıyla
  Yandex Disk'teki **İSG 2026** klasörüne yükleyin → bilgisayarda İSG 2026'da **Yedek yükle**.
  Bilgisayardan tablete de aynı şekilde aktarılır.
