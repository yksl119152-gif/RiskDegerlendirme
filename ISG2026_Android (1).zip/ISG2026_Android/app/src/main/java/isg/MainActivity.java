package isg;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * İSG 2026 tablet sürümü: programın sayfalarını uygulamanın içinden (assets/web) açar.
 * Kayıtlar tablette kalıcı olarak saklanır; Word/Excel çıktıları İndirilenler/İSG 2026 klasörüne kaydedilir.
 */
public class MainActivity extends Activity {
    static final String HOST = "isg2026.yerel";
    static final String BASE = "https://" + HOST + "/";
    static final int DOSYA_SEC = 7;

    WebView w;
    ValueCallback<Uri[]> dosyaCb;
    Uri kameraUri;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        w.addJavascriptInterface(new Kopru(), "AndroidKopru");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String yol = u.getPath() == null ? "/" : u.getPath();
                if (yol.equals("/") || yol.isEmpty()) yol = "/index.html";
                Map<String, String> h = new HashMap<>();
                h.put("Cache-Control", "no-cache");
                if (yol.startsWith("/api/") || yol.contains("..")) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
                }
                try {
                    InputStream in = getAssets().open("web" + yol);
                    String mime = mime(yol);
                    return new WebResourceResponse(mime, mime.startsWith("text/") || mime.contains("javascript") ? "UTF-8" : null, 200, "OK", h, in);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (dosyaCb != null) dosyaCb.onReceiveValue(null);
                dosyaCb = cb;
                kameraUri = null;
                String[] kabul = p.getAcceptTypes();
                List<String> mimeler = new ArrayList<>();
                boolean resim = false, hepsiMime = true;
                if (kabul != null) for (String a : kabul) {
                    for (String t : a.split(",")) {
                        t = t.trim();
                        if (t.isEmpty()) continue;
                        if (t.startsWith("image")) resim = true;
                        if (t.contains("/")) mimeler.add(t); else hepsiMime = false;
                    }
                }
                Intent sec = new Intent(Intent.ACTION_GET_CONTENT);
                sec.addCategory(Intent.CATEGORY_OPENABLE);
                sec.setType("*/*");
                if (hepsiMime && !mimeler.isEmpty()) sec.putExtra(Intent.EXTRA_MIME_TYPES, mimeler.toArray(new String[0]));
                if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) sec.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                Intent secici = Intent.createChooser(sec, "Dosya seçin");
                if (resim && Build.VERSION.SDK_INT >= 29) {
                    try {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "ISG_" + System.currentTimeMillis() + ".jpg");
                        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/İSG 2026");
                        kameraUri = getContentResolver().insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), cv);
                        if (kameraUri != null) {
                            Intent kam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            kam.putExtra(MediaStore.EXTRA_OUTPUT, kameraUri);
                            kam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            secici.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{kam});
                        }
                    } catch (Exception ignored) { kameraUri = null; }
                }
                try {
                    startActivityForResult(secici, DOSYA_SEC);
                } catch (ActivityNotFoundException e) {
                    dosyaCb.onReceiveValue(null);
                    dosyaCb = null;
                    return false;
                }
                return true;
            }
        });
        if (b != null) w.restoreState(b);
        else w.loadUrl(BASE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != DOSYA_SEC || dosyaCb == null) return;
        Uri[] sonuc = null;
        if (res == RESULT_OK) {
            List<Uri> l = new ArrayList<>();
            if (data != null) {
                if (data.getClipData() != null) {
                    for (int i = 0; i < data.getClipData().getItemCount(); i++) l.add(data.getClipData().getItemAt(i).getUri());
                } else if (data.getData() != null) l.add(data.getData());
            }
            if (l.isEmpty() && kameraUri != null) l.add(kameraUri);
            else if (kameraUri != null) bosKameraSil();
            if (!l.isEmpty()) sonuc = l.toArray(new Uri[0]);
        } else if (kameraUri != null) bosKameraSil();
        dosyaCb.onReceiveValue(sonuc);
        dosyaCb = null;
        kameraUri = null;
    }

    void bosKameraSil() {
        try { getContentResolver().delete(kameraUri, null, null); } catch (Exception ignored) { }
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        w.saveState(o);
    }

    @Override
    public void onBackPressed() {
        if (w.canGoBack()) w.goBack();
        else super.onBackPressed();
    }

    static String mime(String yol) {
        String a = yol.toLowerCase();
        if (a.endsWith(".html")) return "text/html";
        if (a.endsWith(".js")) return "application/javascript";
        if (a.endsWith(".css")) return "text/css";
        if (a.endsWith(".json")) return "application/json";
        if (a.endsWith(".pdf")) return "application/pdf";
        if (a.endsWith(".png")) return "image/png";
        if (a.endsWith(".jpg") || a.endsWith(".jpeg")) return "image/jpeg";
        if (a.endsWith(".svg")) return "image/svg+xml";
        if (a.endsWith(".webp")) return "image/webp";
        String uz = MimeTypeMap.getFileExtensionFromUrl(yol);
        String m = uz == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(uz);
        return m == null ? "application/octet-stream" : m;
    }

    /** Sayfalardan çağrılan köprü: window.AndroidKopru.kaydet(dosyaAdı, mime, base64) */
    class Kopru {
        @JavascriptInterface
        public String kaydet(String ad, String mime, String b64) {
            try {
                String temiz = ad.replaceAll("[\\\\/:*?\"<>|]", "_");
                if (mime == null || mime.isEmpty() || mime.equals("application/octet-stream")) mime = mime(temiz);
                byte[] veri = Base64.decode(b64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, temiz);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/İSG 2026");
                    final Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) throw new IOException("dosya oluşturulamadı");
                    OutputStream o = getContentResolver().openOutputStream(uri);
                    if (o == null) throw new IOException("dosya yazılamadı");
                    o.write(veri);
                    o.close();
                    final String m = mime;
                    if (!m.contains("json")) runOnUiThread(new Runnable() {
                        public void run() {
                            Intent ac = new Intent(Intent.ACTION_VIEW);
                            ac.setDataAndType(uri, m);
                            ac.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(Intent.createChooser(ac, "Dosyayı aç")); } catch (Exception ignored) { }
                        }
                    });
                    return "Kaydedildi: İndirilenler / İSG 2026 / " + temiz;
                } else {
                    File d = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "İSG 2026");
                    if (!d.exists()) d.mkdirs();
                    File f = new File(d, temiz);
                    FileOutputStream o = new FileOutputStream(f);
                    o.write(veri);
                    o.close();
                    return "Kaydedildi: " + f.getAbsolutePath();
                }
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    public void run() { Toast.makeText(MainActivity.this, "Kaydedilemedi: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
                });
                return "Kaydedilemedi: " + e.getMessage();
            }
        }
    }
}
