package tr.edu.duzce.isg;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.provider.OpenableColumns;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Programın tamamı uygulamanın içindeki assets/web klasöründen çalışır (internet gerekmez).
 * Sayfalar https://appassets.androidplatform.net/assets/web/ adresinden yüklenir; böylece
 * kayıtlar (localStorage, IndexedDB) uygulama silinmedikçe kalıcıdır.
 */
public class MainActivity extends Activity {
    static final String ANA = "https://appassets.androidplatform.net/assets/web/index.html";
    static final String KOK = "appassets.androidplatform.net";
    static final int DOSYA_SEC = 41, DRIVE_AC = 42, DRIVE_OLUSTUR = 43;
    final ExecutorService is = Executors.newSingleThreadExecutor();
    SharedPreferences ayar;

    WebView w;
    WebView yaziciGorunum;
    WebViewAssetLoader yukleyici;
    ValueCallback<Uri[]> dosyaGeri;
    Uri kameraUri;

    // Sayfalardaki "Yazdır" komutunu Android yazdırma ekranına (PDF olarak kaydet dahil) yönlendirir
    static final String YAZDIR_JS = "(function(){try{window.print=function(){try{AndroidKopru.yazdir('<!doctype html>'+document.documentElement.outerHTML,document.title||'Belge');}catch(e){}};}catch(e){}})();";

    @Override
    protected void onCreate(Bundle kayit) {
        super.onCreate(kayit);
        ayar = getSharedPreferences("ayar", MODE_PRIVATE);
        yonUygula(ayar.getString("yon", "otomatik"));
        Window pen = getWindow();
        pen.setStatusBarColor(Color.parseColor("#0f172a"));
        w = new WebView(this);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(w);

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        yukleyici = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        w.setWebViewClient(new Istemci());
        w.setWebChromeClient(new Krom());
        w.addJavascriptInterface(new Kopru(), "AndroidKopru");
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(w, YAZDIR_JS, Collections.singleton("*"));
        }
        if (kayit != null) w.restoreState(kayit);
        else w.loadUrl(ANA);
    }

    @Override
    protected void onSaveInstanceState(Bundle d) { super.onSaveInstanceState(d); w.saveState(d); }

    @Override
    public void onBackPressed() {
        if (w.canGoBack()) w.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() { super.onPause(); android.webkit.CookieManager.getInstance().flush(); }

    /* ---------------- sayfa yükleme ---------------- */
    class Istemci extends WebViewClientCompat {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            return yukleyici.shouldInterceptRequest(r.getUrl());
        }
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (KOK.equals(u.getHost())) return false;
            String sc = u.getScheme();
            if ("blob".equals(sc) || "data".equals(sc) || "about".equals(sc)) return false;
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { /* yok say */ }
            return true;
        }
    }

    /* ---------------- dosya seçme (fotoğraf: kamera veya galeri) ---------------- */
    class Krom extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> geri, FileChooserParams p) {
            if (dosyaGeri != null) dosyaGeri.onReceiveValue(null);
            dosyaGeri = geri;
            boolean resim = true;
            String[] turler = p.getAcceptTypes();
            if (turler == null || turler.length == 0) resim = false;
            else for (String t : turler) { if (t == null || !t.trim().startsWith("image")) { resim = false; break; } }

            Intent sec = new Intent(Intent.ACTION_GET_CONTENT);
            sec.addCategory(Intent.CATEGORY_OPENABLE);
            sec.setType(resim ? "image/*" : "*/*");
            if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) sec.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            Intent secici = Intent.createChooser(sec, resim ? "Fotoğraf seçin veya çekin" : "Dosya seçin");
            kameraUri = null;
            if (resim) {
                try {
                    File kl = new File(getCacheDir(), "kamera");
                    kl.mkdirs();
                    File f = new File(kl, "foto_" + System.currentTimeMillis() + ".jpg");
                    kameraUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".dosya", f);
                    Intent kam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    kam.putExtra(MediaStore.EXTRA_OUTPUT, kameraUri);
                    kam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    secici.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{kam});
                } catch (Exception e) { kameraUri = null; }
            }
            try { startActivityForResult(secici, DOSYA_SEC); }
            catch (ActivityNotFoundException e) { dosyaGeri.onReceiveValue(null); dosyaGeri = null; return false; }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int istek, int sonuc, Intent veri) {
        super.onActivityResult(istek, sonuc, veri);
        if (istek == DRIVE_AC || istek == DRIVE_OLUSTUR) { driveSecildi(sonuc, veri); return; }
        if (istek != DOSYA_SEC || dosyaGeri == null) return;
        Uri[] secilen = null;
        if (sonuc == RESULT_OK) {
            List<Uri> l = new ArrayList<>();
            if (veri != null && veri.getClipData() != null) {
                for (int i = 0; i < veri.getClipData().getItemCount(); i++) l.add(veri.getClipData().getItemAt(i).getUri());
            } else if (veri != null && veri.getData() != null) {
                l.add(veri.getData());
            } else if (kameraUri != null) {
                l.add(kameraUri);
            }
            if (!l.isEmpty()) secilen = l.toArray(new Uri[0]);
        }
        dosyaGeri.onReceiveValue(secilen);
        dosyaGeri = null;
    }

    /* ---------------- sayfa → Android köprüsü ---------------- */
    class Kopru {
        @JavascriptInterface
        public void kaydet(final String ad, final String tur, final String b64) {
            runOnUiThread(() -> dosyaKaydet(ad, tur, b64));
        }
        @JavascriptInterface
        public void yon(final String y) {
            runOnUiThread(() -> { ayar.edit().putString("yon", y).apply(); yonUygula(y); });
        }
        @JavascriptInterface
        public String driveDurum() {
            Uri u = driveUri();
            try {
                JSONObject o = new JSONObject();
                o.put("bagli", u != null);
                o.put("ad", u == null ? "" : "Google Drive / " + dosyaAdi(u));
                return o.toString();
            } catch (Exception e) { return "{\"bagli\":false}"; }
        }
        @JavascriptInterface
        public void driveSec() { runOnUiThread(MainActivity.this::driveSecPenceresi); }
        @JavascriptInterface
        public void driveOku(final String id) {
            final Uri u = driveUri();
            is.execute(() -> {
                if (u == null) { jsCevap(id, null, "Drive eşitlemesi kurulmadı"); return; }
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] t = new byte[65536]; int n;
                    while ((n = in.read(t)) > 0) b.write(t, 0, n);
                    jsCevap(id, new String(b.toByteArray(), StandardCharsets.UTF_8), null);
                } catch (SecurityException e) {
                    jsCevap(id, null, "Drive dosyasına erişim izni kalktı; Drive düğmesinden dosyayı yeniden seçin");
                } catch (Exception e) { jsCevap(id, null, "Drive dosyası okunamadı (" + e.getMessage() + ")"); }
            });
        }
        @JavascriptInterface
        public void driveYaz(final String id, final String metin) {
            final Uri u = driveUri();
            is.execute(() -> {
                if (u == null) { jsCevap(id, null, "Drive eşitlemesi kurulmadı"); return; }
                byte[] b = metin.getBytes(StandardCharsets.UTF_8);
                try {
                    OutputStream o;
                    try { o = getContentResolver().openOutputStream(u, "wt"); } catch (Exception e) { o = getContentResolver().openOutputStream(u, "w"); }
                    try (OutputStream oo = o) { oo.write(b); oo.flush(); }
                    jsCevap(id, "ok", null);
                } catch (Exception e) { jsCevap(id, null, "Drive dosyasına yazılamadı (" + e.getMessage() + ")"); }
            });
        }
        @JavascriptInterface
        public void yazdir(final String html, final String baslik) {
            runOnUiThread(() -> yazdirHtml(html, baslik));
        }
    }

    /* ekran yönü: yatay / dikey / otomatik (sayfadaki "Ekran" seçiminden) */
    void yonUygula(String y) {
        if ("yatay".equals(y)) setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        else if ("dikey".equals(y)) setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        else setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    /* ---------------- Google Drive eşitleme dosyası (sistem dosya seçicisiyle) ---------------- */
    Uri driveUri() { String s = ayar.getString("drive", null); return s == null ? null : Uri.parse(s); }

    String dosyaAdi(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        return getString(R.string.esitleme_dosyasi);
    }

    void jsCevap(String id, String metin, String hata) {
        final String js = "window.__driveCevap&&window.__driveCevap(" + JSONObject.quote(id) + "," + (metin == null ? "null" : JSONObject.quote(metin)) + "," + (hata == null ? "null" : JSONObject.quote(hata)) + ")";
        runOnUiThread(() -> w.evaluateJavascript(js, null));
    }

    void driveSecPenceresi() {
        String dosya = getString(R.string.esitleme_dosyasi);
        Uri u = driveUri();
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Bulut eşitlemesi (Google Drive / Yandex Disk)")
                .setMessage("Kayıtlar buluttaki tek bir dosyada birleşir; bilgisayardaki program da aynı dosyayı kullanır.\n\n"
                        + "Bilgisayarda Drive'ı bağladıysanız: “Dosyayı seç” deyip dosya seçicide Google Drive (Drive'ım) veya Yandex Disk → " + getString(R.string.klasor) + " → " + dosya + " dosyasını seçin.\n\n"
                        + "Henüz bilgisayarda kurulmadıysa: “Yeni oluştur” ile dosyayı Drive'da oluşturun."
                        + (u != null ? "\n\nŞu an bağlı: " + dosyaAdi(u) : ""))
                .setPositiveButton("Dosyayı seç", (d, i) -> {
                    Intent in = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    in.addCategory(Intent.CATEGORY_OPENABLE);
                    in.setType("*/*");
                    in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    try { startActivityForResult(in, DRIVE_AC); } catch (Exception e) { Toast.makeText(this, "Dosya seçici açılamadı", Toast.LENGTH_LONG).show(); }
                })
                .setNeutralButton("Yeni oluştur", (d, i) -> {
                    Intent in = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    in.addCategory(Intent.CATEGORY_OPENABLE);
                    in.setType("application/json");
                    in.putExtra(Intent.EXTRA_TITLE, dosya);
                    in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    try { startActivityForResult(in, DRIVE_OLUSTUR); } catch (Exception e) { Toast.makeText(this, "Dosya seçici açılamadı", Toast.LENGTH_LONG).show(); }
                });
        if (u != null) b.setNegativeButton("Eşitlemeyi kapat", (d, i) -> {
            try { getContentResolver().releasePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception ignored) {}
            ayar.edit().remove("drive").apply();
            w.evaluateJavascript("window.__driveSecildi&&window.__driveSecildi()", null);
        });
        b.show();
    }

    void driveSecildi(int sonuc, Intent veri) {
        if (sonuc != RESULT_OK || veri == null || veri.getData() == null) return;
        Uri u = veri.getData();
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }
        catch (Exception e) { Toast.makeText(this, "Dosyaya kalıcı erişim izni alınamadı; Drive uygulamasında dosyayı yeniden seçin.", Toast.LENGTH_LONG).show(); }
        ayar.edit().putString("drive", u.toString()).apply();
        Toast.makeText(this, "Drive eşitlemesi bağlandı: " + dosyaAdi(u), Toast.LENGTH_LONG).show();
        w.evaluateJavascript("window.__driveSecildi&&window.__driveSecildi()", null);
    }

    void dosyaKaydet(String ad, String tur, String b64) {
        try {
            byte[] b = Base64.decode(b64, Base64.DEFAULT);
            String guvenli = ad.replaceAll("[\\\\/:*?\"<>|]", "_");
            if (tur == null || tur.isEmpty()) tur = "application/octet-stream";
            Uri uri;
            String klasor = getString(R.string.app_name);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, guvenli);
                cv.put(MediaStore.Downloads.MIME_TYPE, tur);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + klasor);
                uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new Exception("İndirilenler klasörüne yazılamadı");
                try (OutputStream o = getContentResolver().openOutputStream(uri)) { o.write(b); }
            } else {
                File kl = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "");
                kl.mkdirs();
                File f = new File(kl, guvenli);
                try (OutputStream o = new FileOutputStream(f)) { o.write(b); }
                uri = FileProvider.getUriForFile(this, getPackageName() + ".dosya", f);
            }
            final Uri u = uri;
            final String t = tur;
            new AlertDialog.Builder(this)
                    .setTitle("Dosya kaydedildi")
                    .setMessage(guvenli + "\n\nKonum: İndirilenler / " + klasor)
                    .setPositiveButton("Aç", (d, i) -> ac(u, t, false))
                    .setNeutralButton("Paylaş", (d, i) -> ac(u, t, true))
                    .setNegativeButton("Tamam", null)
                    .show();
        } catch (Exception e) {
            Toast.makeText(this, "Dosya kaydedilemedi: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    void ac(Uri u, String tur, boolean paylas) {
        try {
            Intent i;
            if (paylas) { i = new Intent(Intent.ACTION_SEND); i.setType(tur); i.putExtra(Intent.EXTRA_STREAM, u); }
            else { i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(u, tur); }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, paylas ? "Paylaş" : "Aç"));
        } catch (Exception e) {
            Toast.makeText(this, "Bu dosyayı açacak uygulama bulunamadı (Word, Excel veya WPS Office gerekebilir).", Toast.LENGTH_LONG).show();
        }
    }

    void yazdirHtml(String html, final String baslik) {
        yaziciGorunum = new WebView(this);
        yaziciGorunum.getSettings().setJavaScriptEnabled(false);
        yaziciGorunum.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return yukleyici.shouldInterceptRequest(r.getUrl()); }
            @Override
            public void onPageFinished(WebView v, String url) {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                String ad = (baslik == null || baslik.trim().isEmpty()) ? getString(R.string.app_name) : baslik.trim();
                PrintDocumentAdapter ad2 = v.createPrintDocumentAdapter(ad);
                pm.print(ad, ad2, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
            }
        });
        yaziciGorunum.loadDataWithBaseURL("https://" + KOK + "/assets/web/app/", html, "text/html", "UTF-8", null);
    }
}
